package HHHTHHHHTtT;

import android.app.Activity;
import android.text.TextUtils;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentPayload;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import com.gpc.tsh.pay.utils.HHHTHHHHHtH;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: PaymentTransactionScheduler */
public class HHHTHHHHTHt implements PaymentTransactionStateListener {

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public static final String f192HHHTHHHHTt = "TranscationSchedule";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public AtomicBoolean f193HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public LinkedBlockingDeque<GPCPaymentClientPurchase> f194HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public Timer f195HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public GPCPaymentClientPurchase f196HHHTHHHHHtH = null;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public TimerTask f197HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public PaymentTransactionStateListener f198HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public HHHTHHHHHtH f199HHHTHHHHTHt;

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public HHHTHHHHHtH f200HHHTHHHHTTt;

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public AtomicBoolean f201HHHTHHHHTtH = new AtomicBoolean(false);

    /* compiled from: PaymentTransactionScheduler */
    public class HHHTHHHHHTt extends TimerTask {
        public HHHTHHHHHTt() {
        }

        public final void HHHHTHHHHHHt() {
            while (HHHTHHHHTHt.this.f194HHHTHHHHHTt.size() > 0) {
                LogUtils.i(HHHTHHHHTHt.f192HHHTHHHHTt, "toBeConsumePurchases.size() > 0");
                if (!HHHTHHHHTHt.this.f193HHHHTHHHHHHt.get()) {
                    LogUtils.i(HHHTHHHHTHt.f192HHHTHHHHTt, "!isConsumeing.get()");
                    try {
                        HHHTHHHHTHt.this.HHHTHHHHHTt();
                        GPCPaymentClientPurchase gPCPaymentClientPurchase = (GPCPaymentClientPurchase) HHHTHHHHTHt.this.f194HHHTHHHHHTt.pop();
                        GPCPaymentClientPurchase unused = HHHTHHHHTHt.this.f196HHHTHHHHHtH = gPCPaymentClientPurchase;
                        HHHTHHHHTHt.this.HHHTHHHHHtH(gPCPaymentClientPurchase);
                    } catch (Exception e) {
                        HHHTHHHHTHt.this.HHHHTHHHHHHt();
                        LogUtils.e(HHHTHHHHTHt.f192HHHTHHHHTt, "getBeConsumePurchases!", e);
                    }
                } else {
                    LogUtils.i(HHHTHHHHTHt.f192HHHTHHHHTt, "isConsumeing.get()");
                    HHHTHHHHHTt();
                }
            }
        }

        public final void HHHTHHHHHTt() {
            try {
                Thread.sleep(SimpleExoPlayer.DEFAULT_DETACH_SURFACE_TIMEOUT_MS);
            } catch (Exception e) {
                LogUtils.e(HHHTHHHHTHt.f192HHHTHHHHTt, "getBeConsumePurchases!", e);
            }
        }

        public void run() {
            LogUtils.i(HHHTHHHHTHt.f192HHHTHHHHTt, "ConsumePurchaseTask Run.");
            HHHHTHHHHHHt();
            HHHTHHHHTHt.this.HHHHTHHHHHHt(15000);
        }
    }

    public HHHTHHHHTHt(Activity activity, PaymentType paymentType, String str, String str2) {
        this.f199HHHTHHHHTHt = new HHHTHHHHHtH(activity);
        this.f200HHHTHHHHTTt = new HHHTHHHHHtH(activity, paymentType, str, str2);
    }

    public void HHHTHHHHHtT() {
        this.f201HHHTHHHHTtH.set(true);
        this.f194HHHTHHHHHTt.clear();
        if (this.f195HHHTHHHHHt != null) {
            this.f197HHHTHHHHHtT.cancel();
            this.f195HHHTHHHHHt.cancel();
            this.f197HHHTHHHHHtT = null;
            this.f195HHHTHHHHHt = null;
        }
        this.f200HHHTHHHHTTt.HHHHTHHHHHHt();
    }

    public void onCommitGatewayFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (this.f198HHHTHHHHHtt != null && !this.f201HHHTHHHHTtH.get()) {
            this.f198HHHTHHHHHtt.onCommitGatewayFail(PaymentTransactionHandleType.Scheduler, gPCPaymentClientPurchase);
        }
        HHHHTHHHHHHt();
    }

    public void onCommitGatewaySuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState) {
        if (this.f198HHHTHHHHHtt != null && !this.f201HHHTHHHHTtH.get()) {
            this.f198HHHTHHHHHtt.onCommitGatewaySuccess(PaymentTransactionHandleType.Scheduler, gPCPaymentClientPurchase, str, paymentDeliveryState);
        }
        if (TextUtils.equals(gPCPaymentClientPurchase.getItemType(), "subs")) {
            HHHHTHHHHHHt();
        }
    }

    public void onConsumeFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (this.f198HHHTHHHHHtt != null && !this.f201HHHTHHHHTtH.get()) {
            this.f198HHHTHHHHHtt.onConsumeFail(PaymentTransactionHandleType.Scheduler, gPCPaymentClientPurchase);
        }
        HHHHTHHHHHHt();
    }

    public void onConsumeSuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        HHHHTHHHHHHt();
    }

    public void onReceivedQueryInventoryTaskInterval(int i) {
        if (this.f198HHHTHHHHHtt != null && !this.f201HHHTHHHHTtH.get()) {
            this.f198HHHTHHHHHtt.onReceivedQueryInventoryTaskInterval(i);
        }
    }

    public void onSubItemHasCommited() {
        HHHHTHHHHHHt();
    }

    public void HHHTHHHHHt() {
        if (this.f201HHHTHHHHTtH.get()) {
            LogUtils.w(f192HHHTHHHHTt, "PaymentTransactionScheduler is stop!!! not schedule again.");
            return;
        }
        this.f193HHHHTHHHHHHt = new AtomicBoolean(false);
        LinkedBlockingDeque<GPCPaymentClientPurchase> linkedBlockingDeque = new LinkedBlockingDeque<>();
        this.f194HHHTHHHHHTt = linkedBlockingDeque;
        linkedBlockingDeque.clear();
        this.f195HHHTHHHHHt = new Timer();
        HHHHTHHHHHHt(0);
    }

    public final void HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase) throws Exception {
        if (gPCPaymentClientPurchase == null || (TextUtils.equals(gPCPaymentClientPurchase.getItemType(), "subs") && this.f199HHHTHHHHTHt.HHHTHHHHHt(gPCPaymentClientPurchase.getOrderId()))) {
            HHHHTHHHHHHt();
            return;
        }
        LogUtils.d(f192HHHTHHHHTt, gPCPaymentClientPurchase.getSku() + " committing gateway!");
        this.f200HHHTHHHHTTt.HHHTHHHHHTt(gPCPaymentClientPurchase, (PaymentTransactionStateListener) this);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x003c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void HHHTHHHHHTt(com.gpc.tsh.pay.bean.GPCPaymentClientPurchase r4) {
        /*
            r3 = this;
            monitor-enter(r3)
            java.lang.String r0 = r4.getOrderId()     // Catch:{ all -> 0x0072 }
            com.gpc.tsh.pay.bean.GPCPaymentClientPurchase r1 = r3.f196HHHTHHHHHtH     // Catch:{ all -> 0x0072 }
            if (r1 == 0) goto L_0x0030
            java.lang.String r1 = r1.getOrderId()     // Catch:{ all -> 0x0072 }
            boolean r1 = android.text.TextUtils.equals(r1, r0)     // Catch:{ all -> 0x0072 }
            if (r1 == 0) goto L_0x0030
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0072 }
            r4.<init>()     // Catch:{ all -> 0x0072 }
            java.lang.String r1 = "isConsumeing purchase "
            r4.append(r1)     // Catch:{ all -> 0x0072 }
            r4.append(r0)     // Catch:{ all -> 0x0072 }
            java.lang.String r0 = ", not add."
            r4.append(r0)     // Catch:{ all -> 0x0072 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0072 }
            java.lang.String r0 = "TranscationSchedule"
            com.gpc.operations.utils.LogUtils.i(r0, r4)     // Catch:{ all -> 0x0072 }
            monitor-exit(r3)
            return
        L_0x0030:
            java.util.concurrent.LinkedBlockingDeque<com.gpc.tsh.pay.bean.GPCPaymentClientPurchase> r1 = r3.f194HHHTHHHHHTt     // Catch:{ all -> 0x0072 }
            java.util.Iterator r1 = r1.iterator()     // Catch:{ all -> 0x0072 }
        L_0x0036:
            boolean r2 = r1.hasNext()     // Catch:{ all -> 0x0072 }
            if (r2 == 0) goto L_0x006b
            java.lang.Object r2 = r1.next()     // Catch:{ all -> 0x0072 }
            com.gpc.tsh.pay.bean.GPCPaymentClientPurchase r2 = (com.gpc.tsh.pay.bean.GPCPaymentClientPurchase) r2     // Catch:{ all -> 0x0072 }
            if (r2 == r4) goto L_0x004e
            java.lang.String r2 = r2.getOrderId()     // Catch:{ all -> 0x0072 }
            boolean r2 = android.text.TextUtils.equals(r2, r0)     // Catch:{ all -> 0x0072 }
            if (r2 == 0) goto L_0x0036
        L_0x004e:
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x0072 }
            r4.<init>()     // Catch:{ all -> 0x0072 }
            java.lang.String r1 = "has add purchase "
            r4.append(r1)     // Catch:{ all -> 0x0072 }
            r4.append(r0)     // Catch:{ all -> 0x0072 }
            java.lang.String r0 = ", not add."
            r4.append(r0)     // Catch:{ all -> 0x0072 }
            java.lang.String r4 = r4.toString()     // Catch:{ all -> 0x0072 }
            java.lang.String r0 = "TranscationSchedule"
            com.gpc.operations.utils.LogUtils.i(r0, r4)     // Catch:{ all -> 0x0072 }
            monitor-exit(r3)
            return
        L_0x006b:
            java.util.concurrent.LinkedBlockingDeque<com.gpc.tsh.pay.bean.GPCPaymentClientPurchase> r0 = r3.f194HHHTHHHHHTt     // Catch:{ all -> 0x0072 }
            r0.add(r4)     // Catch:{ all -> 0x0072 }
            monitor-exit(r3)
            return
        L_0x0072:
            r4 = move-exception
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: HHHTHHHHTtT.HHHTHHHHTHt.HHHTHHHHHTt(com.gpc.tsh.pay.bean.GPCPaymentClientPurchase):void");
    }

    public void HHHHTHHHHHHt(GPCPaymentPayload gPCPaymentPayload) {
        this.f200HHHTHHHHTTt.HHHHTHHHHHHt(gPCPaymentPayload);
    }

    public void HHHHTHHHHHHt(PaymentTransactionStateListener paymentTransactionStateListener) {
        this.f198HHHTHHHHHtt = paymentTransactionStateListener;
    }

    public void HHHHTHHHHHHt(List<GPCPaymentClientPurchase> list) {
        if (list != null && list.size() > 0) {
            for (GPCPaymentClientPurchase HHHTHHHHHt2 : list) {
                HHHTHHHHHt(HHHTHHHHHt2);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0027 A[EDGE_INSN: B:12:0x0027->B:8:0x0027 ?: BREAK  , SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:3:0x000c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void HHHHTHHHHHHt(com.gpc.tsh.pay.bean.GPCPaymentClientPurchase r5) {
        /*
            r4 = this;
            java.util.concurrent.LinkedBlockingDeque<com.gpc.tsh.pay.bean.GPCPaymentClientPurchase> r0 = r4.f194HHHTHHHHHTt
            java.util.Iterator r0 = r0.iterator()
        L_0x0006:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0027
            java.lang.Object r1 = r0.next()
            com.gpc.tsh.pay.bean.GPCPaymentClientPurchase r1 = (com.gpc.tsh.pay.bean.GPCPaymentClientPurchase) r1
            if (r1 == r5) goto L_0x0022
            java.lang.String r2 = r1.getOrderId()
            java.lang.String r3 = r5.getOrderId()
            boolean r2 = android.text.TextUtils.equals(r2, r3)
            if (r2 == 0) goto L_0x0006
        L_0x0022:
            java.util.concurrent.LinkedBlockingDeque<com.gpc.tsh.pay.bean.GPCPaymentClientPurchase> r0 = r4.f194HHHTHHHHHTt
            r0.remove(r1)
        L_0x0027:
            java.util.concurrent.LinkedBlockingDeque<com.gpc.tsh.pay.bean.GPCPaymentClientPurchase> r0 = r4.f194HHHTHHHHHTt
            r0.addFirst(r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: HHHTHHHHTtT.HHHTHHHHTHt.HHHHTHHHHHHt(com.gpc.tsh.pay.bean.GPCPaymentClientPurchase):void");
    }

    public List<GPCPaymentClientPurchase> HHHTHHHHHtH() {
        ArrayList arrayList = new ArrayList();
        Iterator<GPCPaymentClientPurchase> it = this.f194HHHTHHHHHTt.iterator();
        while (it.hasNext()) {
            try {
                arrayList.add(new GPCPaymentClientPurchase(it.next()));
            } catch (Exception e) {
                LogUtils.e(f192HHHTHHHHTt, "getBeConsumePurchases!", e);
            }
        }
        return arrayList;
    }

    public void HHHTHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (gPCPaymentClientPurchase != null) {
            HHHTHHHHHTt(gPCPaymentClientPurchase);
        }
    }

    public final void HHHHTHHHHHHt() {
        this.f196HHHTHHHHHtH = null;
        this.f193HHHHTHHHHHHt.set(false);
    }

    public final void HHHTHHHHHTt() {
        this.f193HHHHTHHHHHHt.set(true);
    }

    public final void HHHHTHHHHHHt(long j) {
        if (this.f195HHHTHHHHHt != null) {
            HHHTHHHHHTt hHHTHHHHHTt = new HHHTHHHHHTt();
            this.f197HHHTHHHHHtT = hHHTHHHHHTt;
            this.f195HHHTHHHHHt.schedule(hHHTHHHHHTt, j);
        }
    }
}
