package HHHTHHHHTTt;

import android.text.TextUtils;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.GameItemPriceSource;
import com.gpc.tsh.pay.bean.GPCGameItem;
import com.gpc.tsh.pay.bean.GPCGameItemDetails;
import com.gpc.tsh.pay.bean.GPCPaymentClientSkuDetails;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.cache.ITEMS_SOURCE;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* compiled from: PaymentItemsCacheManager */
public class HHHTHHHHHTt {

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public static final String f116HHHTHHHHHt = "GameSubsItems";

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public static final String f117HHHTHHHHHtH = "PaymentItemsCacheManager";

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public static final String f118HHHTHHHHHtT = "GameSubsItemsMap";

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public static final String f119HHHTHHHHHtt = "GameItems";

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public static final String f120HHHTHHHHTHt = "GameItemsMap";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public ITEMS_SOURCE f121HHHHTHHHHHHt = ITEMS_SOURCE.NONE;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public PaymentType f122HHHTHHHHHTt;

    public HHHTHHHHHTt(PaymentType paymentType) {
        this.f122HHHTHHHHHTt = paymentType;
    }

    public GPCGameItem HHHHTHHHHHHt(String str) {
        if (ModulesManager.dataCenterModule() == null || TextUtils.isEmpty(str)) {
            return null;
        }
        Map map = (Map) ModulesManager.dataCenterModule().get(HHHTHHHHHt());
        if (map == null || map.size() == 0) {
            LogUtils.i(f117HHHTHHHHHtH, "load gameInAppItems warning:list of item is null");
            return null;
        } else if (map.containsKey(str)) {
            return (GPCGameItem) map.get(str);
        } else {
            return null;
        }
    }

    public GPCGameItem HHHTHHHHHTt(String str) {
        if (ModulesManager.dataCenterModule() == null || TextUtils.isEmpty(str)) {
            return null;
        }
        Map map = (Map) ModulesManager.dataCenterModule().get(HHHTHHHHTTt());
        if (map == null || map.size() == 0) {
            LogUtils.i(f117HHHTHHHHHtH, "load gameSubsItems warning:list of item is null");
            return null;
        } else if (map.containsKey(str)) {
            return (GPCGameItem) map.get(str);
        } else {
            return null;
        }
    }

    public String HHHTHHHHHt() {
        return "GameItemsMap_" + this.f122HHHTHHHHHTt.getName();
    }

    public String HHHTHHHHHtH() {
        return "GameItems_" + this.f122HHHTHHHHHTt.getName();
    }

    public List<GPCGameItem> HHHTHHHHHtT() {
        if (ModulesManager.dataCenterModule() == null) {
            return null;
        }
        List<GPCGameItem> list = (List) ModulesManager.dataCenterModule().get(HHHTHHHHTHt());
        if (list == null || list.size() == 0) {
            LogUtils.i(f117HHHTHHHHHtH, "load gameSubsItems warning:list of item is null");
        }
        return list;
    }

    public List<String> HHHTHHHHHtt() {
        if (ModulesManager.dataCenterModule() == null) {
            return null;
        }
        Map map = (Map) ModulesManager.dataCenterModule().get(HHHTHHHHTTt());
        if (map != null && map.size() != 0) {
            return new ArrayList(map.keySet());
        }
        LogUtils.i(f117HHHTHHHHHtH, "load gameSubsItems warning:list of item is null");
        return null;
    }

    public String HHHTHHHHTHt() {
        return "GameSubsItems_" + this.f122HHHTHHHHHTt.getName();
    }

    public String HHHTHHHHTTt() {
        return "GameSubsItemsMap_" + this.f122HHHTHHHHHTt.getName();
    }

    public List<GPCGameItem> HHHTHHHHTt() {
        ArrayList arrayList = new ArrayList();
        if (ModulesManager.dataCenterModule() == null) {
            return arrayList;
        }
        List<GPCGameItem> HHHTHHHHHtT2 = HHHTHHHHHtT();
        List<GPCGameItem> HHHHTHHHHHHt2 = HHHHTHHHHHHt();
        if (HHHTHHHHHtT2 != null && HHHTHHHHHtT2.size() > 0) {
            arrayList.addAll(HHHTHHHHHtT2);
        }
        if (HHHHTHHHHHHt2 != null && HHHHTHHHHHHt2.size() > 0) {
            arrayList.addAll(HHHHTHHHHHHt2);
        }
        return arrayList;
    }

    public ITEMS_SOURCE HHHTHHHHTtH() {
        return this.f121HHHHTHHHHHHt;
    }

    public boolean HHHTHHHHTtT() {
        if (ModulesManager.dataCenterModule() == null) {
            return false;
        }
        List<GPCGameItem> HHHTHHHHHtT2 = HHHTHHHHHtT();
        List<GPCGameItem> HHHHTHHHHHHt2 = HHHHTHHHHHHt();
        if ((HHHHTHHHHHHt2 == null || HHHHTHHHHHHt2.size() <= 0) && (HHHTHHHHHtT2 == null || HHHTHHHHHtT2.size() <= 0)) {
            return false;
        }
        return true;
    }

    public List<GPCGameItem> HHHHTHHHHHHt() {
        if (ModulesManager.dataCenterModule() == null) {
            return null;
        }
        List<GPCGameItem> list = (List) ModulesManager.dataCenterModule().get(HHHTHHHHHtH());
        if (list == null || list.size() == 0) {
            LogUtils.i(f117HHHTHHHHHtH, "load gameInAppItems warning:list of item is null");
        }
        return list;
    }

    public List<String> HHHTHHHHHTt() {
        if (ModulesManager.dataCenterModule() == null) {
            return null;
        }
        Map map = (Map) ModulesManager.dataCenterModule().get(HHHTHHHHHt());
        if (map != null && map.size() != 0) {
            return new ArrayList(map.keySet());
        }
        LogUtils.i(f117HHHTHHHHHtH, "load gameInAppItems warning:list of item is null");
        return null;
    }

    public void HHHHTHHHHHHt(ITEMS_SOURCE items_source) {
        LogUtils.d(f117HHHTHHHHHtH, "upateItemsSource:" + items_source.name());
        this.f121HHHHTHHHHHHt = items_source;
    }

    public void HHHHTHHHHHHt(List<GPCGameItem> list, List<GPCGameItem> list2) {
        if (ModulesManager.dataCenterModule() != null) {
            if (!(list == null || list.size() == 0)) {
                LogUtils.d(f117HHHTHHHHHtH, "save gameInAppItems:list of item is not null");
                ModulesManager.dataCenterModule().put(HHHTHHHHHtH(), list);
                HashMap hashMap = new HashMap();
                for (GPCGameItem next : list) {
                    hashMap.put(next.getId() + "", next);
                }
                ModulesManager.dataCenterModule().put(HHHTHHHHHt(), hashMap);
            }
            if (list2 != null && list2.size() != 0) {
                LogUtils.d(f117HHHTHHHHHtH, "save gameSubsItems:list of item is not null");
                ModulesManager.dataCenterModule().put(HHHTHHHHTHt(), list2);
                HashMap hashMap2 = new HashMap();
                for (GPCGameItem next2 : list2) {
                    hashMap2.put(next2.getId() + "", next2);
                }
                ModulesManager.dataCenterModule().put(HHHTHHHHTTt(), hashMap2);
            }
        }
    }

    public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, boolean z) {
        LogUtils.d(f117HHHTHHHHHtH, "updateThirdPlatformPrice");
        if (ModulesManager.dataCenterModule() != null) {
            if (list == null) {
                LogUtils.w(f117HHHTHHHHHtH, "skuDetailsList is null");
                return;
            }
            for (GPCPaymentClientSkuDetails next : list) {
                GPCGameItem HHHHTHHHHHHt2 = HHHHTHHHHHHt(next.getSku());
                if (HHHHTHHHHHHt2 == null) {
                    HHHHTHHHHHHt2 = HHHTHHHHHTt(next.getSku());
                }
                if (HHHHTHHHHHHt2 != null) {
                    HHHHTHHHHHHt(next, HHHHTHHHHHHt2, z);
                }
            }
        }
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientSkuDetails gPCPaymentClientSkuDetails, GPCGameItem gPCGameItem, boolean z) {
        GameItemPriceSource gameItemPriceSource;
        try {
            if (gPCGameItem.getPurchase() != null) {
                gPCGameItem.getPurchase().setGooglePlayPriceAmountMicros(gPCPaymentClientSkuDetails.getPriceAmountMicros());
                gPCGameItem.getPurchase().setThirdPlatformCurrencyPrice(gPCPaymentClientSkuDetails.getPrice());
                gPCGameItem.getPurchase().setThirdPlatformPriceCurrencyCode(gPCPaymentClientSkuDetails.getPriceCurrencyCode());
                gPCGameItem.getPurchase().setThirdPlatformOriginalCurrencyPrice(gPCPaymentClientSkuDetails.getOriginalPrice());
            }
            if (gPCGameItem.getPricing() != null) {
                if (z) {
                    gameItemPriceSource = GameItemPriceSource.GPCGameItemPriceSourceRealTime;
                } else {
                    gameItemPriceSource = GameItemPriceSource.GPCGameItemPriceSourceCache;
                }
                gPCGameItem.getPricing().createInStorePrice(gPCPaymentClientSkuDetails, gameItemPriceSource);
            }
            GPCGameItemDetails gPCGameItemDetails = new GPCGameItemDetails();
            gPCGameItemDetails.setExtendFields(gPCPaymentClientSkuDetails.getExtendFields());
            gPCGameItemDetails.setJson(gPCPaymentClientSkuDetails.getJson());
            gPCGameItem.setDetails(gPCGameItemDetails);
        } catch (Exception e) {
            LogUtils.e(f117HHHTHHHHHtH, "fillThirdPlatformPrice", e);
        }
    }
}
