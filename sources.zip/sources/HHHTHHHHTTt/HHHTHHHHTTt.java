package HHHTHHHHTtT;

import android.app.Activity;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentPayload;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumeFinishListener;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import java.util.ArrayList;
import java.util.List;

/* compiled from: PaymentTransactionsManager */
public class HHHTHHHHTTt implements PaymentTransactionStateListener {

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public static final String f203HHHTHHHHHtT = "TranscationsManager";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public HHHTHHHHHt f204HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public HHHTHHHHTHt f205HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public GPCPaymentClientPurchase f206HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public PaymentTransactionStateListener f207HHHTHHHHHtH;

    /* compiled from: PaymentTransactionsManager */
    public class HHHHTHHHHHHt implements PaymentClientConsumeFinishListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientConsumeFinishListener f208HHHHTHHHHHHt;

        public HHHHTHHHHHHt(PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
            this.f208HHHHTHHHHHHt = paymentClientConsumeFinishListener;
        }

        public void onFinish(GPCException gPCException, boolean z) {
            GPCPaymentClientPurchase unused = HHHTHHHHTTt.this.f206HHHTHHHHHt = null;
            this.f208HHHHTHHHHHHt.onFinish(gPCException, z);
        }
    }

    public HHHTHHHHTTt(Activity activity, PaymentType paymentType, String str, String str2) {
        this.f204HHHHTHHHHHHt = new HHHTHHHHHt(activity, paymentType, str, str2);
        this.f205HHHTHHHHHTt = new HHHTHHHHTHt(activity, paymentType, str, str2);
    }

    public void HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (HHHHTHHHHHHt(gPCPaymentClientPurchase)) {
            this.f205HHHTHHHHHTt.HHHTHHHHHt(gPCPaymentClientPurchase);
        }
    }

    public void HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        this.f206HHHTHHHHHt = gPCPaymentClientPurchase;
        this.f204HHHHTHHHHHHt.HHHTHHHHHTt(gPCPaymentClientPurchase);
    }

    public void onCommitGatewayFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        this.f206HHHTHHHHHt = null;
        PaymentTransactionStateListener paymentTransactionStateListener = this.f207HHHTHHHHHtH;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onCommitGatewayFail(paymentTransactionHandleType, gPCPaymentClientPurchase);
        }
        if (paymentTransactionHandleType == PaymentTransactionHandleType.Processor) {
            HHHTHHHHHTt(gPCPaymentClientPurchase);
        }
    }

    public void onCommitGatewaySuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f207HHHTHHHHHtH;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onCommitGatewaySuccess(paymentTransactionHandleType, gPCPaymentClientPurchase, str, paymentDeliveryState);
        }
    }

    public void onConsumeFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        this.f206HHHTHHHHHt = null;
        PaymentTransactionStateListener paymentTransactionStateListener = this.f207HHHTHHHHHtH;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onConsumeFail(paymentTransactionHandleType, gPCPaymentClientPurchase);
        }
        if (paymentTransactionHandleType == PaymentTransactionHandleType.Processor) {
            HHHTHHHHHTt(gPCPaymentClientPurchase);
        }
    }

    public void onConsumeSuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        this.f206HHHTHHHHHt = null;
    }

    public void onReceivedQueryInventoryTaskInterval(int i) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f207HHHTHHHHHtH;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onReceivedQueryInventoryTaskInterval(i);
        }
    }

    public void onSubItemHasCommited() {
        this.f206HHHTHHHHHt = null;
    }

    public void HHHHTHHHHHHt(PaymentTransactionStateListener paymentTransactionStateListener) {
        this.f204HHHHTHHHHHHt.HHHHTHHHHHHt((PaymentTransactionStateListener) this);
        this.f205HHHTHHHHHTt.HHHHTHHHHHHt((PaymentTransactionStateListener) this);
        this.f207HHHTHHHHHtH = paymentTransactionStateListener;
        this.f205HHHTHHHHHTt.HHHTHHHHHt();
    }

    public List<GPCPaymentClientPurchase> HHHTHHHHHTt() {
        return this.f205HHHTHHHHHTt.HHHTHHHHHtH();
    }

    public void HHHHTHHHHHHt(GPCPaymentPayload gPCPaymentPayload) {
        HHHTHHHHHt hHHTHHHHHt = this.f204HHHHTHHHHHHt;
        if (hHHTHHHHHt != null) {
            hHHTHHHHHt.HHHHTHHHHHHt(gPCPaymentPayload);
        }
        HHHTHHHHTHt hHHTHHHHTHt = this.f205HHHTHHHHHTt;
        if (hHHTHHHHTHt != null) {
            hHHTHHHHTHt.HHHHTHHHHHHt(gPCPaymentPayload);
        }
    }

    public void HHHHTHHHHHHt(List<GPCPaymentClientPurchase> list) {
        if (this.f206HHHTHHHHHt == null || list == null) {
            this.f205HHHTHHHHHTt.HHHHTHHHHHHt(list);
            return;
        }
        ArrayList arrayList = new ArrayList();
        for (GPCPaymentClientPurchase next : list) {
            if (HHHHTHHHHHHt(next)) {
                arrayList.add(next);
            }
        }
        this.f205HHHTHHHHHTt.HHHHTHHHHHHt((List<GPCPaymentClientPurchase>) arrayList);
    }

    public final boolean HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        return gPCPaymentClientPurchase.getOrderId() == null || this.f206HHHTHHHHHt == null || !gPCPaymentClientPurchase.getOrderId().equals(this.f206HHHTHHHHHt.getOrderId());
    }

    public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        LogUtils.d(f203HHHTHHHHHtT, "processTransactionImmediately");
        this.f206HHHTHHHHHt = gPCPaymentClientPurchase;
        this.f204HHHHTHHHHHHt.HHHTHHHHHTt(gPCPaymentClientPurchase, new HHHHTHHHHHHt(paymentClientConsumeFinishListener));
    }

    public void HHHHTHHHHHHt() {
        this.f204HHHHTHHHHHHt.HHHHTHHHHHHt();
        this.f205HHHTHHHHHTt.HHHTHHHHHtT();
        this.f206HHHTHHHHHt = null;
    }
}
