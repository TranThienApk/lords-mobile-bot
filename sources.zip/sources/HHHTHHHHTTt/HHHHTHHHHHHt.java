package HHHTHHHHTTt;

import com.gpc.operations.OperationsSDKApplication;
import com.gpc.operations.migrate.utils.LocalStorage;
import com.gpc.operations.migrate.utils.common.Constant;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCGameItem;
import java.util.Arrays;
import java.util.List;

/* compiled from: FruadIdsCacherManager */
public class HHHHTHHHHHHt {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f114HHHHTHHHHHHt = "FruadCacherManager";

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public static final String f115HHHTHHHHHTt = "fraud_ids";

    public static void HHHHTHHHHHHt(List<GPCGameItem> list) {
        if (list == null || list.isEmpty()) {
            LogUtils.i(f114HHHHTHHHHHHt, "cacheFruadIds: items is empty");
            return;
        }
        LocalStorage localStorage = new LocalStorage(OperationsSDKApplication.sApplication, Constant.PERSISTENCE_FILE_NAME.OPS_PAYMENT_MESSAGE);
        StringBuilder sb = new StringBuilder();
        for (GPCGameItem next : list) {
            if (next.getCategory() == 11) {
                sb.append(next.getId());
                sb.append(",");
            }
        }
        String sb2 = sb.toString();
        LogUtils.i(f114HHHHTHHHHHHt, "cacheFruadIds: " + sb2);
        localStorage.writeString(f115HHHTHHHHHTt, sb2);
    }

    public static List<String> HHHHTHHHHHHt() {
        String readString = new LocalStorage(OperationsSDKApplication.sApplication, Constant.PERSISTENCE_FILE_NAME.OPS_PAYMENT_MESSAGE).readString(f115HHHTHHHHHTt);
        LogUtils.i(f114HHHHTHHHHHHt, "readFruadIdsFromCache: " + readString);
        return Arrays.asList(readString.split(","));
    }
}
