package HHHTHHHHTtT;

import android.app.Activity;
import android.text.TextUtils;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.utils.SDKTask;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCGatewayPayload;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentPayload;
import com.gpc.tsh.pay.bean.OrderType;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumeFinishListener;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.flow.purchase.PurchaseAcknowledgement;
import com.gpc.tsh.pay.flow.purchase.PurchaseConsumer;
import com.gpc.tsh.pay.flow.purchase.TransactionQuerier;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import com.gpc.tsh.pay.service.PurchaseService;
import com.gpc.tsh.pay.service.listener.SubmittalFinishedListener;
import com.gpc.tsh.pay.utils.HHHTHHHHHtH;
import java.util.List;

/* compiled from: PaymentPurchaseProcessTask */
public class HHHTHHHHHtH {

    /* renamed from: HHHTHHHHTtT  reason: collision with root package name */
    public static final String f156HHHTHHHHTtT = "PurchaseProcessTask";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public PaymentType f157HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public String f158HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public PurchaseConsumer f159HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public String f160HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public PurchaseAcknowledgement f161HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public PurchaseService f162HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public com.gpc.tsh.pay.utils.HHHTHHHHHtH f163HHHTHHHHTHt;

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public TransactionQuerier f164HHHTHHHHTTt;

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public SDKTask f165HHHTHHHHTt = new SDKTask();

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public GPCPaymentPayload f166HHHTHHHHTtH;

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHHTHHHHHHt implements SubmittalFinishedListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentTransactionStateListener f167HHHHTHHHHHHt;

        public HHHHTHHHHHHt(PaymentTransactionStateListener paymentTransactionStateListener) {
            this.f167HHHHTHHHHHHt = paymentTransactionStateListener;
        }

        public void onPurchaseSubmittalFinished(boolean z, PaymentDeliveryState paymentDeliveryState, GPCPaymentClientPurchase gPCPaymentClientPurchase, int i) {
            if (i != 0) {
                this.f167HHHHTHHHHHHt.onReceivedQueryInventoryTaskInterval(i);
            }
            if (z) {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " commit gateway successfully!");
                this.f167HHHHTHHHHHHt.onCommitGatewaySuccess(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase, (String) null, paymentDeliveryState);
                HHHTHHHHHtH.this.HHHHTHHHHHHt(gPCPaymentClientPurchase, this.f167HHHHTHHHHHHt);
                return;
            }
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " commit gateway fail!");
            this.f167HHHHTHHHHHHt.onCommitGatewayFail(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase);
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHHTt implements PurchaseConsumer.GPCConsumePurchaseListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentTransactionStateListener f169HHHHTHHHHHHt;

        public HHHTHHHHHTt(PaymentTransactionStateListener paymentTransactionStateListener) {
            this.f169HHHHTHHHHHHt = paymentTransactionStateListener;
        }

        public void onConsumeFinished(GPCPaymentClientPurchase gPCPaymentClientPurchase, boolean z) {
            if (z) {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " Consume successfully!");
                this.f169HHHHTHHHHHHt.onConsumeSuccess(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase);
                return;
            }
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " Consume fail!");
            this.f169HHHHTHHHHHHt.onConsumeFail(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase);
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHHt implements SDKTask.SDKTaskResultListener<Object> {
        public HHHTHHHHHt() {
        }

        public void onResult(GPCException gPCException, Object obj) {
        }
    }

    /* renamed from: HHHTHHHHTtT.HHHTHHHHHtH$HHHTHHHHHtH  reason: collision with other inner class name */
    /* compiled from: PaymentPurchaseProcessTask */
    public class C0008HHHTHHHHHtH implements SDKTask.SDKTaskRunnable<Object> {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f172HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ PaymentTransactionStateListener f173HHHTHHHHHTt;

        public C0008HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentTransactionStateListener paymentTransactionStateListener) {
            this.f172HHHHTHHHHHHt = gPCPaymentClientPurchase;
            this.f173HHHTHHHHHTt = paymentTransactionStateListener;
        }

        public Object run() throws Exception {
            HHHTHHHHHtH.this.HHHTHHHHHt(this.f172HHHHTHHHHHHt, this.f173HHHTHHHHHTt);
            return null;
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHTHt implements SDKTask.SDKTaskRunnable<Object> {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f175HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientConsumeFinishListener f176HHHTHHHHHTt;

        public HHHTHHHHTHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
            this.f175HHHHTHHHHHHt = gPCPaymentClientPurchase;
            this.f176HHHTHHHHHTt = paymentClientConsumeFinishListener;
        }

        public Object run() throws Exception {
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, "excute purchase getItemType:" + this.f175HHHHTHHHHHHt.getItemType());
            HHHTHHHHHtH.this.HHHTHHHHHt(this.f175HHHHTHHHHHHt, this.f176HHHTHHHHHTt);
            return null;
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHTTt implements SDKTask.SDKTaskResultListener<Object> {
        public HHHTHHHHTTt() {
        }

        public void onResult(GPCException gPCException, Object obj) {
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHTtH implements PurchaseAcknowledgement.GPCAcknowledgePurchaseListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f182HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ HHTHHHHtHT f183HHHTHHHHHTt;

        /* compiled from: PaymentPurchaseProcessTask */
        public class HHHHTHHHHHHt implements TransactionQuerier.GPCQueryTransactionListener {
            public HHHHTHHHHHHt() {
            }

            public void onQueriedFinish(GPCException gPCException, List<GPCPaymentClientPurchase> list) {
                if (list != null) {
                    for (GPCPaymentClientPurchase next : list) {
                        if (TextUtils.equals(next.getOrderId(), HHHTHHHHTtH.this.f182HHHHTHHHHHHt.getOrderId()) && !next.isAcknowledged()) {
                            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, " process find orderId:" + next.getOrderId() + ", but not Acknowledged");
                        }
                        if (TextUtils.equals(next.getOrderId(), HHHTHHHHTtH.this.f182HHHHTHHHHHHt.getOrderId()) && next.isAcknowledged()) {
                            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, "process  paymentClientPurchase:" + next.getOriginalJson());
                            HHHTHHHHTtH.this.f183HHHTHHHHHTt.HHHHTHHHHHHt(next);
                            return;
                        }
                    }
                }
                LogUtils.e(HHHTHHHHHtH.f156HHHTHHHHTtT, "purchases is null.");
                HHHTHHHHTtH.this.f183HHHTHHHHHTt.HHHHTHHHHHHt();
            }
        }

        public HHHTHHHHTtH(GPCPaymentClientPurchase gPCPaymentClientPurchase, HHTHHHHtHT hHTHHHHtHT) {
            this.f182HHHHTHHHHHHt = gPCPaymentClientPurchase;
            this.f183HHHTHHHHHTt = hHTHHHHtHT;
        }

        public void onAcknowledgeFinished(boolean z) {
            if (z) {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, this.f182HHHHTHHHHHHt.getSku() + " acknowledge successfully!");
            } else {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, this.f182HHHHTHHHHHHt.getSku() + " acknowledge fail!");
            }
            HHHTHHHHHtH.this.f164HHHTHHHHTTt.HHHHTHHHHHHt(new HHHHTHHHHHHt());
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHTHHHHtH implements PurchaseConsumer.GPCConsumePurchaseListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientConsumeFinishListener f188HHHHTHHHHHHt;

        public HHTHHHHtH(PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
            this.f188HHHHTHHHHHHt = paymentClientConsumeFinishListener;
        }

        public void onConsumeFinished(GPCPaymentClientPurchase gPCPaymentClientPurchase, boolean z) {
            if (z) {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " Consume successfully!");
                this.f188HHHHTHHHHHHt.onFinish(GPCException.noneException(), true);
                return;
            }
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " Consume fail!");
            this.f188HHHHTHHHHHHt.onFinish(GPCException.noneException(), false);
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHTHHHHtHH implements SubmittalFinishedListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientConsumeFinishListener f190HHHHTHHHHHHt;

        public HHTHHHHtHH(PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
            this.f190HHHHTHHHHHHt = paymentClientConsumeFinishListener;
        }

        public void onPurchaseSubmittalFinished(boolean z, PaymentDeliveryState paymentDeliveryState, GPCPaymentClientPurchase gPCPaymentClientPurchase, int i) {
            if (z) {
                LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " commit gateway successfully!");
                HHHTHHHHHtH.this.HHHHTHHHHHHt(gPCPaymentClientPurchase, this.f190HHHHTHHHHHHt);
                return;
            }
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, gPCPaymentClientPurchase.getSku() + " commit gateway fail!");
            this.f190HHHHTHHHHHHt.onFinish(GPCException.noneException(), false);
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public interface HHTHHHHtHT {
        void HHHHTHHHHHHt();

        void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase);
    }

    public HHHTHHHHHtH(Activity activity, PaymentType paymentType, String str, String str2) {
        this.f157HHHHTHHHHHHt = paymentType;
        this.f158HHHTHHHHHTt = str;
        this.f160HHHTHHHHHtH = str2;
        this.f159HHHTHHHHHt = new PurchaseConsumer(activity, paymentType);
        this.f161HHHTHHHHHtT = new PurchaseAcknowledgement(activity, paymentType);
        this.f162HHHTHHHHHtt = com.gpc.tsh.pay.utils.HHHTHHHHHTt.HHHTHHHHHTt();
        this.f163HHHTHHHHTHt = new com.gpc.tsh.pay.utils.HHHTHHHHHtH(activity);
        this.f164HHHTHHHHTTt = new TransactionQuerier(activity, paymentType);
    }

    public final void HHHTHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentTransactionStateListener paymentTransactionStateListener) {
        HHHHTHHHHHHt(gPCPaymentClientPurchase, (HHTHHHHtHT) new HHHTHHHHTt(paymentTransactionStateListener, gPCPaymentClientPurchase));
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHHTHHHHTt implements HHTHHHHtHT {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentTransactionStateListener f179HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f180HHHTHHHHHTt;

        public HHHTHHHHTt(PaymentTransactionStateListener paymentTransactionStateListener, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
            this.f179HHHHTHHHHHHt = paymentTransactionStateListener;
            this.f180HHHTHHHHHTt = gPCPaymentClientPurchase;
        }

        public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
            LogUtils.i(HHHTHHHHHtH.f156HHHTHHHHTtT, "notifyInAppItem:" + gPCPaymentClientPurchase);
            HHHTHHHHHtH.this.HHHTHHHHHtH(gPCPaymentClientPurchase, this.f179HHHHTHHHHHHt);
        }

        public void HHHHTHHHHHHt() {
            this.f179HHHHTHHHHHHt.onCommitGatewayFail(PaymentTransactionHandleType.Unspecified, this.f180HHHTHHHHHTt);
        }
    }

    /* compiled from: PaymentPurchaseProcessTask */
    public class HHTHHHHTtt implements HHTHHHHtHT {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientConsumeFinishListener f186HHHHTHHHHHHt;

        public HHTHHHHTtt(PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
            this.f186HHHHTHHHHHHt = paymentClientConsumeFinishListener;
        }

        public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
            LogUtils.d(HHHTHHHHHtH.f156HHHTHHHHTtT, "submitInAppItem onSuccess:" + gPCPaymentClientPurchase.toString());
            HHHTHHHHHtH.this.HHHTHHHHHtH(gPCPaymentClientPurchase, this.f186HHHHTHHHHHHt);
        }

        public void HHHHTHHHHHHt() {
            this.f186HHHHTHHHHHHt.onFinish(GPCException.noneException(), false);
        }
    }

    public final void HHHTHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        HHHHTHHHHHHt(gPCPaymentClientPurchase, (HHTHHHHtHT) new HHTHHHHTtt(paymentClientConsumeFinishListener));
    }

    public void HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentTransactionStateListener paymentTransactionStateListener) {
        this.f165HHHTHHHHTt.excuteForTimeConsuming(new C0008HHHTHHHHHtH(gPCPaymentClientPurchase, paymentTransactionStateListener), new HHHTHHHHHt());
    }

    public final void HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        if (gPCPaymentClientPurchase.isPending()) {
            paymentClientConsumeFinishListener.onFinish(GPCException.noneException(), false);
            return;
        }
        String str = this.f160HHHTHHHHHtH;
        String str2 = this.f158HHHTHHHHHTt;
        HHHTHHHHHtH.HHHHTHHHHHHt HHHTHHHHHtH2 = this.f163HHHTHHHHTHt.HHHTHHHHHtH(gPCPaymentClientPurchase.getOrderId());
        if (HHHTHHHHHtH2 != null) {
            if (!TextUtils.isEmpty(HHHTHHHHHtH2.f830HHHTHHHHHTt)) {
                str = HHHTHHHHHtH2.f830HHHTHHHHHTt;
                LogUtils.d(f156HHHTHHHHTtT, "get postUserID from cache:" + str);
            }
            if (!TextUtils.isEmpty(HHHTHHHHHtH2.f832HHHTHHHHHtH)) {
                str2 = HHHTHHHHHtH2.f832HHHTHHHHHtH;
                LogUtils.d(f156HHHTHHHHTtT, "get gameid from cache:" + str2);
            }
        }
        String str3 = str;
        LogUtils.d(f156HHHTHHHHTtT, "paymentGateway submit:" + gPCPaymentClientPurchase.getSku());
        GPCPaymentClientPurchase gPCPaymentClientPurchase2 = gPCPaymentClientPurchase;
        this.f162HHHTHHHHHtt.submit(this.f157HHHHTHHHHHHt, gPCPaymentClientPurchase2, str2, str3, GPCGatewayPayload.generateInAppItemPayload(str3, OrderType.NORMAL, "", this.f166HHHTHHHHTtH), new HHTHHHHtHH(paymentClientConsumeFinishListener));
    }

    public void HHHHTHHHHHHt(GPCPaymentPayload gPCPaymentPayload) {
        this.f166HHHTHHHHTtH = gPCPaymentPayload;
    }

    public void HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        LogUtils.d(f156HHHTHHHHTtT, "excute onFinish");
        this.f165HHHTHHHHTt.excuteForTimeConsuming(new HHHTHHHHTHt(gPCPaymentClientPurchase, paymentClientConsumeFinishListener), new HHHTHHHHTTt());
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, HHTHHHHtHT hHTHHHHtHT) {
        try {
            this.f161HHHTHHHHHtT.HHHHTHHHHHHt(gPCPaymentClientPurchase, HHHTHHHHHTt(gPCPaymentClientPurchase), new HHHTHHHHTtH(gPCPaymentClientPurchase, hHTHHHHtHT));
        } catch (Exception e) {
            LogUtils.e(f156HHHTHHHHTtT, "acknowledge!", e);
            hHTHHHHtHT.HHHHTHHHHHHt();
        }
    }

    public final String HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (TextUtils.equals(gPCPaymentClientPurchase.getItemType(), "subs")) {
            return GPCGatewayPayload.generateSubItemPayload(this.f160HHHTHHHHHtH, this.f158HHHTHHHHHTt, this.f166HHHTHHHHTtH);
        }
        return GPCGatewayPayload.generateInAppItemPayload(this.f160HHHTHHHHHtH, OrderType.NORMAL, "", this.f166HHHTHHHHTtH);
    }

    public final void HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentTransactionStateListener paymentTransactionStateListener) {
        if (gPCPaymentClientPurchase.isPending()) {
            paymentTransactionStateListener.onCommitGatewaySuccess(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase, (String) null, PaymentDeliveryState.PENDING_DELIVER);
            return;
        }
        String str = this.f160HHHTHHHHHtH;
        String str2 = this.f158HHHTHHHHHTt;
        HHHTHHHHHtH.HHHHTHHHHHHt HHHTHHHHHtH2 = this.f163HHHTHHHHTHt.HHHTHHHHHtH(gPCPaymentClientPurchase.getOrderId());
        if (HHHTHHHHHtH2 != null) {
            if (!TextUtils.isEmpty(HHHTHHHHHtH2.f830HHHTHHHHHTt)) {
                str = HHHTHHHHHtH2.f830HHHTHHHHHTt;
                LogUtils.d(f156HHHTHHHHTtT, "get postUserID from cache:" + str);
            }
            if (!TextUtils.isEmpty(HHHTHHHHHtH2.f832HHHTHHHHHtH)) {
                str2 = HHHTHHHHHtH2.f832HHHTHHHHHtH;
                LogUtils.d(f156HHHTHHHHTtT, "get gameid from cache:" + str2);
            }
        }
        String str3 = str;
        this.f162HHHTHHHHHtt.submit(this.f157HHHHTHHHHHHt, gPCPaymentClientPurchase, str2, str3, GPCGatewayPayload.generateInAppItemPayload(str3, OrderType.NORMAL, "", this.f166HHHTHHHHTtH), new HHHHTHHHHHHt(paymentTransactionStateListener));
    }

    public final String HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        String generateInAppItemPayload = GPCGatewayPayload.generateInAppItemPayload(this.f160HHHTHHHHHtH, OrderType.NORMAL, "", this.f166HHHTHHHHTtH);
        HHHTHHHHHtH.HHHHTHHHHHHt HHHTHHHHHtH2 = this.f163HHHTHHHHTHt.HHHTHHHHHtH(gPCPaymentClientPurchase.getOrderId());
        return (HHHTHHHHHtH2 == null || TextUtils.isEmpty(HHHTHHHHHtH2.f831HHHTHHHHHt)) ? generateInAppItemPayload : HHHTHHHHHtH2.f831HHHTHHHHHt;
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        try {
            this.f159HHHTHHHHHt.HHHHTHHHHHHt(gPCPaymentClientPurchase, "", new HHTHHHHtH(paymentClientConsumeFinishListener));
        } catch (Exception e) {
            LogUtils.e(f156HHHTHHHHTtT, "consumePurchase!", e);
            paymentClientConsumeFinishListener.onFinish(GPCException.noneException(), false);
        }
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentTransactionStateListener paymentTransactionStateListener) {
        try {
            this.f159HHHTHHHHHt.HHHHTHHHHHHt(gPCPaymentClientPurchase, "", new HHHTHHHHHTt(paymentTransactionStateListener));
        } catch (Exception e) {
            LogUtils.e(f156HHHTHHHHTtT, "consumePurchase!", e);
            paymentTransactionStateListener.onConsumeFail(PaymentTransactionHandleType.Unspecified, gPCPaymentClientPurchase);
        }
    }

    public void HHHHTHHHHHHt() {
        this.f159HHHTHHHHHt.HHHHTHHHHHHt();
        this.f161HHHTHHHHHtT.HHHHTHHHHHHt();
        this.f164HHHTHHHHTTt.HHHHTHHHHHHt();
    }
}
