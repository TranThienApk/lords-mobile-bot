package HHHTHHHHTtT;

import android.app.Activity;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentPayload;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumeFinishListener;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.service.PaymentDeliveryState;

/* compiled from: PaymentTransactionProcessor */
public class HHHTHHHHHt implements PaymentTransactionStateListener {

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public static final String f153HHHTHHHHHtH = "TransactionProcessor";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public PaymentTransactionStateListener f154HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public HHHTHHHHHtH f155HHHTHHHHHTt;

    public HHHTHHHHHt(Activity activity, PaymentType paymentType, String str, String str2) {
        this.f155HHHTHHHHHTt = new HHHTHHHHHtH(activity, paymentType, str, str2);
    }

    public void HHHHTHHHHHHt(GPCPaymentPayload gPCPaymentPayload) {
        this.f155HHHTHHHHHTt.HHHHTHHHHHHt(gPCPaymentPayload);
    }

    public void HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        HHHHTHHHHHHt(gPCPaymentClientPurchase);
    }

    public void onCommitGatewayFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onCommitGatewayFail(PaymentTransactionHandleType.Processor, gPCPaymentClientPurchase);
        }
    }

    public void onCommitGatewaySuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onCommitGatewaySuccess(PaymentTransactionHandleType.Processor, gPCPaymentClientPurchase, str, paymentDeliveryState);
        }
    }

    public void onConsumeFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onConsumeFail(PaymentTransactionHandleType.Processor, gPCPaymentClientPurchase);
        }
    }

    public void onConsumeSuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onConsumeSuccess(paymentTransactionHandleType, gPCPaymentClientPurchase);
        }
    }

    public void onReceivedQueryInventoryTaskInterval(int i) {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onReceivedQueryInventoryTaskInterval(i);
        }
    }

    public void onSubItemHasCommited() {
        PaymentTransactionStateListener paymentTransactionStateListener = this.f154HHHHTHHHHHHt;
        if (paymentTransactionStateListener != null) {
            paymentTransactionStateListener.onSubItemHasCommited();
        }
    }

    public void HHHHTHHHHHHt(PaymentTransactionStateListener paymentTransactionStateListener) {
        this.f154HHHHTHHHHHHt = paymentTransactionStateListener;
    }

    public void HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        LogUtils.d(f153HHHTHHHHHtH, "processTransactionImmediately");
        HHHHTHHHHHHt(gPCPaymentClientPurchase, paymentClientConsumeFinishListener);
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        if (gPCPaymentClientPurchase != null) {
            try {
                this.f155HHHTHHHHHTt.HHHTHHHHHTt(gPCPaymentClientPurchase, (PaymentTransactionStateListener) this);
            } catch (Exception e) {
                LogUtils.e(f153HHHTHHHHHtH, "commitPurchaseToGateway(Processor)", e);
            }
        } else {
            LogUtils.d(f153HHHTHHHHHtH, "commit gateway purchase is null!");
            onCommitGatewayFail(PaymentTransactionHandleType.Processor, gPCPaymentClientPurchase);
        }
    }

    public final void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientConsumeFinishListener paymentClientConsumeFinishListener) {
        if (gPCPaymentClientPurchase != null) {
            try {
                LogUtils.d(f153HHHTHHHHHtH, "purchaseProcessTask.excute commit gateway purchase");
                this.f155HHHTHHHHHTt.HHHTHHHHHTt(gPCPaymentClientPurchase, paymentClientConsumeFinishListener);
            } catch (Exception e) {
                LogUtils.e(f153HHHTHHHHHtH, "commitPurchaseToGateway(Processor)", e);
            }
        } else {
            LogUtils.d(f153HHHTHHHHHtH, "commit gateway purchase is null!");
            paymentClientConsumeFinishListener.onFinish(GPCException.noneException(), false);
        }
    }

    public void HHHHTHHHHHHt() {
        this.f155HHHTHHHHHTt.HHHHTHHHHHHt();
    }
}
