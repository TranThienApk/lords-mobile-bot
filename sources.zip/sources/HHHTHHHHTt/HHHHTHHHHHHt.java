package HHHTHHHHTt;

import android.app.Activity;
import android.content.Intent;
import com.android.billingclient.api.AcknowledgePurchaseResponseListener;
import com.android.billingclient.api.BillingResult;
import com.facebook.appevents.iap.InAppPurchaseConstants;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.error.utils.ExceptionUtils;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentClientSkuDetails;
import com.gpc.tsh.pay.bean.GPCPurchaseFailureType;
import com.gpc.tsh.pay.error.PaymentErrorCode;
import com.gpc.tsh.pay.flow.client.IGPCPaymentClient;
import com.gpc.tsh.pay.flow.client.google.billing.BillingManager;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientAcknowledgePurchaseListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumePurchaseListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientInitializeListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientPurchasedListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientQueryPurchasesListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientQuerySkuDetailsResponseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/* compiled from: GoogleBillingPaymentClient */
public class HHHHTHHHHHHt implements IGPCPaymentClient, BillingManager.BillingUpdatesListener {

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public static final String f123HHHTHHHHTt = "GBPaymentClient";

    /* renamed from: HHHTHHHHTtT  reason: collision with root package name */
    public static final List<String> f124HHHTHHHHTtT = new ArrayList();

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public Activity f125HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public BillingManager f126HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public PaymentClientPurchasedListener f127HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public PaymentClientInitializeListener f128HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public ConcurrentHashMap<String, GPCPaymentClientPurchase> f129HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public ConcurrentHashMap<String, PaymentClientConsumePurchaseListener> f130HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public int f131HHHTHHHHTHt = 1;

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public int f132HHHTHHHHTTt = 5;

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public String f133HHHTHHHHTtH = "inapp";

    /* renamed from: HHHTHHHHTt.HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
    /* compiled from: GoogleBillingPaymentClient */
    public class C0006HHHHTHHHHHHt implements BillingManager.QueryPurchasesListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientQueryPurchasesListener f134HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHTt.HHHHTHHHHHHt$HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
        /* compiled from: GoogleBillingPaymentClient */
        public class C0007HHHHTHHHHHHt implements BillingManager.QueryPurchasesListener {

            /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
            public final /* synthetic */ List f136HHHHTHHHHHHt;

            public C0007HHHHTHHHHHHt(List list) {
                this.f136HHHHTHHHHHHt = list;
            }

            public void onQueryPurchasesFinished(List<GPCPaymentClientPurchase> list) {
                if (list != null) {
                    LogUtils.d(HHHHTHHHHHHt.f123HHHTHHHHTt, "onQueryPurchasesFinished SUBS size:" + list.size());
                    this.f136HHHHTHHHHHHt.addAll(list);
                }
                C0006HHHHTHHHHHHt.this.f134HHHHTHHHHHHt.onQueryPurchasesFinished(GPCException.noneException(), this.f136HHHHTHHHHHHt);
            }
        }

        public C0006HHHHTHHHHHHt(PaymentClientQueryPurchasesListener paymentClientQueryPurchasesListener) {
            this.f134HHHHTHHHHHHt = paymentClientQueryPurchasesListener;
        }

        public void onQueryPurchasesFinished(List<GPCPaymentClientPurchase> list) {
            LogUtils.d(HHHHTHHHHHHt.f123HHHTHHHHTt, "onQueryPurchasesFinished");
            ArrayList arrayList = new ArrayList();
            if (list != null) {
                LogUtils.d(HHHHTHHHHHHt.f123HHHTHHHHTt, "onQueryPurchasesFinished size:" + list.size());
                arrayList.addAll(list);
            }
            if (HHHHTHHHHHHt.this.f126HHHTHHHHHTt.HHHHTHHHHHHt()) {
                LogUtils.d(HHHHTHHHHHHt.f123HHHTHHHHTt, "query SUBS queryPurchases");
                HHHHTHHHHHHt.this.f126HHHTHHHHHTt.HHHHTHHHHHHt("subs", (BillingManager.QueryPurchasesListener) new C0007HHHHTHHHHHHt(arrayList));
                return;
            }
            LogUtils.d(HHHHTHHHHHHt.f123HHHTHHHHTt, "areSubscriptionsSupported falase");
            this.f134HHHHTHHHHHHt.onQueryPurchasesFinished(GPCException.noneException(), arrayList);
        }
    }

    /* compiled from: GoogleBillingPaymentClient */
    public class HHHTHHHHHTt implements AcknowledgePurchaseResponseListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f138HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientAcknowledgePurchaseListener f139HHHTHHHHHTt;

        public HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase, PaymentClientAcknowledgePurchaseListener paymentClientAcknowledgePurchaseListener) {
            this.f138HHHHTHHHHHHt = gPCPaymentClientPurchase;
            this.f139HHHTHHHHHTt = paymentClientAcknowledgePurchaseListener;
        }

        public void onAcknowledgePurchaseResponse(BillingResult billingResult) {
            if (billingResult.getResponseCode() == 0) {
                HHHHTHHHHHHt.f124HHHTHHHHTtT.add(this.f138HHHHTHHHHHHt.getOrderId());
                this.f139HHHTHHHHHTt.onAcknowledgeFinished(GPCException.noneException());
                return;
            }
            LogUtils.e(HHHHTHHHHHHt.f123HHHTHHHHTt, "onAcknowledgePurchaseResponse error code:" + billingResult.getResponseCode() + ", msg:" + billingResult.getDebugMessage());
            PaymentClientAcknowledgePurchaseListener paymentClientAcknowledgePurchaseListener = this.f139HHHTHHHHHTt;
            StringBuilder sb = new StringBuilder();
            sb.append(billingResult.getResponseCode());
            sb.append("");
            paymentClientAcknowledgePurchaseListener.onAcknowledgeFinished(GPCException.exception("-1", sb.toString()));
        }
    }

    /* compiled from: GoogleBillingPaymentClient */
    public class HHHTHHHHTHt implements BillingManager.ProductsDetailsResponseListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ HHHTHHHHTTt f148HHHHTHHHHHHt;

        public HHHTHHHHTHt(HHHTHHHHTTt hHHTHHHHTTt) {
            this.f148HHHHTHHHHHHt = hHHTHHHHTTt;
        }

        public void onProductsResponse(BillingResult billingResult, List<GPCPaymentClientSkuDetails> list) {
            if (billingResult.getResponseCode() != 0) {
                LogUtils.e(HHHHTHHHHHHt.f123HHHTHHHHTt, "onSkuDetailsResponse error code:" + billingResult.getResponseCode() + ", msg:" + billingResult.getDebugMessage());
            }
            HHHTHHHHTTt hHHTHHHHTTt = this.f148HHHHTHHHHHHt;
            if (hHHTHHHHTTt != null) {
                hHHTHHHHTTt.HHHHTHHHHHHt(list, billingResult);
            }
        }
    }

    /* compiled from: GoogleBillingPaymentClient */
    public abstract class HHHTHHHHTTt {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public GPCException f150HHHHTHHHHHHt;

        public HHHTHHHHTTt() {
        }

        public abstract void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, BillingResult billingResult);

        public abstract void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, Exception exc);

        public /* synthetic */ HHHTHHHHTTt(HHHHTHHHHHHt hHHHTHHHHHHt, C0006HHHHTHHHHHHt hHHHTHHHHHHt2) {
            this();
        }
    }

    public HHHHTHHHHHHt(Activity activity) {
        LogUtils.i(f123HHHTHHHHTt, "Google Billing V3 Payment");
        this.f125HHHHTHHHHHHt = activity;
        this.f129HHHTHHHHHtT = new ConcurrentHashMap<>();
        this.f130HHHTHHHHHtt = new ConcurrentHashMap<>();
    }

    public void acknowledgePurchase(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentClientAcknowledgePurchaseListener paymentClientAcknowledgePurchaseListener) {
        if (gPCPaymentClientPurchase.isAcknowledged() || f124HHHTHHHHTtT.contains(gPCPaymentClientPurchase.getOrderId())) {
            LogUtils.d(f123HHHTHHHHTt, "acknowledge Purchase of isAcknowledged!!");
            paymentClientAcknowledgePurchaseListener.onAcknowledgeFinished(GPCException.noneException());
            return;
        }
        try {
            this.f126HHHTHHHHHTt.HHHHTHHHHHHt(gPCPaymentClientPurchase.getToken(), str, (AcknowledgePurchaseResponseListener) new HHHTHHHHHTt(gPCPaymentClientPurchase, paymentClientAcknowledgePurchaseListener));
        } catch (Exception e) {
            LogUtils.e(f123HHHTHHHHTt, "acknowledgePurchase!!", e);
            paymentClientAcknowledgePurchaseListener.onAcknowledgeFinished(GPCException.exception("-1"));
        }
    }

    public synchronized void consume(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentClientConsumePurchaseListener paymentClientConsumePurchaseListener) {
        String token = gPCPaymentClientPurchase.getToken();
        if (!this.f129HHHTHHHHHtT.contains(token)) {
            this.f129HHHTHHHHHtT.put(token, gPCPaymentClientPurchase);
            this.f130HHHTHHHHHtt.put(token, paymentClientConsumePurchaseListener);
            try {
                this.f126HHHTHHHHHTt.HHHHTHHHHHHt(gPCPaymentClientPurchase.getToken(), str);
            } catch (Exception e) {
                LogUtils.e(f123HHHTHHHHTt, "consumeAsync!!", e);
                onConsumeFinished(token, 6);
            }
        } else {
            return;
        }
    }

    public void destroy() {
        this.f126HHHTHHHHHTt.HHHTHHHHHTt();
    }

    public synchronized void init(PaymentClientInitializeListener paymentClientInitializeListener) {
        int i = this.f131HHHTHHHHTHt;
        if (i != 3) {
            if (i != 2) {
                this.f131HHHTHHHHTHt = 2;
                this.f128HHHTHHHHHtH = paymentClientInitializeListener;
                try {
                    this.f126HHHTHHHHHTt = new BillingManager(this.f125HHHHTHHHHHHt, this);
                } catch (Exception e) {
                    LogUtils.e(f123HHHTHHHHTt, "init error!", e);
                    this.f131HHHTHHHHTHt = -1;
                    HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PAYMENT_NOT_AVAILABLE, "10", GPCPurchaseFailureType.IAB_SETUP.ordinal()));
                }
            }
        }
        LogUtils.w(f123HHHTHHHHTt, "Developer Error!");
        return;
        return;
    }

    public boolean isAvailable(String str, boolean z) {
        return false;
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        return false;
    }

    public void onBillingClientSetupFail() {
        this.f131HHHTHHHHTHt = -1;
        HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PAYMENT_NOT_AVAILABLE, "10", GPCPurchaseFailureType.IAB_SETUP.ordinal()));
    }

    public void onBillingClientSetupFinished() {
        this.f131HHHTHHHHTHt = 3;
        HHHHTHHHHHHt(GPCException.noneException());
    }

    public void onConsumeFinished(String str, int i) {
        PaymentClientConsumePurchaseListener remove = this.f130HHHTHHHHHtt.remove(str);
        if (remove != null) {
            GPCPaymentClientPurchase remove2 = this.f129HHHTHHHHHtT.remove(str);
            if (i == 0) {
                remove.onConsumeFinished(GPCException.noneException(), remove2);
                return;
            }
            remove.onConsumeFinished(GPCException.exception(i + ""), remove2);
        }
    }

    public void onPurchasesUpdated(int i, String str, List<GPCPaymentClientPurchase> list) {
        if (list != null) {
            for (GPCPaymentClientPurchase isAcknowledged : list) {
                LogUtils.d(f123HHHTHHHHTt, "Purchase isAcknowledged:" + isAcknowledged.isAcknowledged());
            }
        }
        if (i == 0 && list != null && list.size() > 0) {
            LogUtils.d(f123HHHTHHHHTt, "Purchase successful try to post to platform");
            HHHHTHHHHHHt(GPCException.noneException(), list);
        } else if (i == 1) {
            HHHHTHHHHHHt(GPCException.exception("-3", "USER_CANCELED"), (List<GPCPaymentClientPurchase>) null);
        } else {
            HHHHTHHHHHHt(GPCException.exception(i + "", str), (List<GPCPaymentClientPurchase>) null);
        }
        this.f132HHHTHHHHTTt = 5;
    }

    public synchronized void purchaseFlow(String str, String str2, String str3, String str4, PaymentClientPurchasedListener paymentClientPurchasedListener) {
        if (this.f132HHHTHHHHTTt == 4) {
            paymentClientPurchasedListener.onPurchased(GPCException.exception("-2"), (List<GPCPaymentClientPurchase>) null);
            return;
        }
        this.f132HHHTHHHHTTt = 4;
        this.f133HHHTHHHHTtH = str2;
        this.f127HHHTHHHHHt = paymentClientPurchasedListener;
        try {
            this.f126HHHTHHHHHTt.HHHHTHHHHHHt(str, str2, str3, str4);
        } catch (Exception e) {
            LogUtils.e(f123HHHTHHHHTt, "purchaseFlow", e);
            this.f132HHHTHHHHTTt = -2;
            HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PURCHASEFLOW_EXCEPTION, "10"), (List<GPCPaymentClientPurchase>) null);
        }
        return;
    }

    public void queryPurchases(PaymentClientQueryPurchasesListener paymentClientQueryPurchasesListener) {
        try {
            LogUtils.d(f123HHHTHHHHTt, InAppPurchaseConstants.METHOD_QUERY_PURCHASES);
            this.f126HHHTHHHHHTt.HHHHTHHHHHHt("inapp", (BillingManager.QueryPurchasesListener) new C0006HHHHTHHHHHHt(paymentClientQueryPurchasesListener));
        } catch (Exception e) {
            LogUtils.e(f123HHHTHHHHTt, "queryPurchases!", e);
            paymentClientQueryPurchasesListener.onQueryPurchasesFinished(GPCException.noneException(), (List<GPCPaymentClientPurchase>) null);
        }
    }

    public void querySkuDetails(List<String> list, List<String> list2, PaymentClientQuerySkuDetailsResponseListener paymentClientQuerySkuDetailsResponseListener) {
        ArrayList arrayList = new ArrayList();
        HHHHTHHHHHHt("inapp", list, new HHHTHHHHHt(new HHHTHHHHHtH(arrayList, paymentClientQuerySkuDetailsResponseListener), arrayList, list2));
    }

    public final void HHHHTHHHHHHt(String str, List<String> list, HHHTHHHHTTt hHHTHHHHTTt) {
        try {
            this.f126HHHTHHHHHTt.HHHHTHHHHHHt(str, list, (BillingManager.ProductsDetailsResponseListener) new HHHTHHHHTHt(hHHTHHHHTTt));
        } catch (Exception e) {
            LogUtils.e(f123HHHTHHHHTt, "querySkuDetailsAsync ", e);
            if (hHHTHHHHTTt != null) {
                hHHTHHHHTTt.HHHHTHHHHHHt((List<GPCPaymentClientSkuDetails>) null, e);
            }
        }
    }

    /* compiled from: GoogleBillingPaymentClient */
    public class HHHTHHHHHt extends HHHTHHHHTTt {

        /* renamed from: HHHTHHHHHt  reason: collision with root package name */
        public final /* synthetic */ List f141HHHTHHHHHt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ HHHTHHHHTTt f142HHHTHHHHHtH;

        /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
        public final /* synthetic */ List f143HHHTHHHHHtT;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public HHHTHHHHHt(HHHTHHHHTTt hHHTHHHHTTt, List list, List list2) {
            super(HHHHTHHHHHHt.this, (C0006HHHHTHHHHHHt) null);
            this.f142HHHTHHHHHtH = hHHTHHHHTTt;
            this.f141HHHTHHHHHt = list;
            this.f143HHHTHHHHHtT = list2;
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, BillingResult billingResult) {
            if (billingResult.getResponseCode() != 0) {
                HHHTHHHHTTt hHHTHHHHTTt = this.f142HHHTHHHHHtH;
                GPCException exception = GPCException.exception(PaymentErrorCode.PAYMENT_ERROR_FOR_QUERY_ITEM);
                hHHTHHHHTTt.f150HHHHTHHHHHHt = exception.underlyingException(GPCException.exception(billingResult.getResponseCode() + "", billingResult.getDebugMessage()));
            } else {
                this.f142HHHTHHHHHtH.f150HHHHTHHHHHHt = GPCException.noneException();
            }
            HHHHTHHHHHHt(list);
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, Exception exc) {
            this.f142HHHTHHHHHtH.f150HHHHTHHHHHHt = GPCException.exception(PaymentErrorCode.PAYMENT_ERROR_FOR_QUERY_ITEM, exc.getMessage());
            HHHHTHHHHHHt(list);
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list) {
            if (list != null) {
                this.f141HHHTHHHHHt.addAll(list);
            }
            HHHHTHHHHHHt.this.HHHHTHHHHHHt("subs", this.f143HHHTHHHHHtT, this.f142HHHTHHHHHtH);
        }
    }

    /* compiled from: GoogleBillingPaymentClient */
    public class HHHTHHHHHtH extends HHHTHHHHTTt {

        /* renamed from: HHHTHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentClientQuerySkuDetailsResponseListener f145HHHTHHHHHt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ List f146HHHTHHHHHtH;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public HHHTHHHHHtH(List list, PaymentClientQuerySkuDetailsResponseListener paymentClientQuerySkuDetailsResponseListener) {
            super(HHHHTHHHHHHt.this, (C0006HHHHTHHHHHHt) null);
            this.f146HHHTHHHHHtH = list;
            this.f145HHHTHHHHHt = paymentClientQuerySkuDetailsResponseListener;
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, BillingResult billingResult) {
            if (this.f150HHHHTHHHHHHt.isNone()) {
                if (billingResult.getResponseCode() != 0) {
                    GPCException exception = GPCException.exception(PaymentErrorCode.PAYMENT_ERROR_FOR_QUERY_ITEM);
                    this.f150HHHHTHHHHHHt = exception.underlyingException(GPCException.exception(billingResult.getResponseCode() + "", billingResult.getDebugMessage()));
                } else {
                    this.f150HHHHTHHHHHHt = GPCException.noneException();
                }
            }
            HHHHTHHHHHHt(list);
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list, Exception exc) {
            if (this.f150HHHHTHHHHHHt.isNone()) {
                this.f150HHHHTHHHHHHt = GPCException.exception(PaymentErrorCode.PAYMENT_ERROR_FOR_QUERY_ITEM, exc.getMessage());
            }
            HHHHTHHHHHHt(list);
        }

        public void HHHHTHHHHHHt(List<GPCPaymentClientSkuDetails> list) {
            if (list != null) {
                this.f146HHHTHHHHHtH.addAll(list);
            }
            this.f145HHHTHHHHHt.onSkuDetailsResponse(this.f150HHHHTHHHHHHt, this.f146HHHTHHHHHtH);
        }
    }

    public final void HHHHTHHHHHHt(GPCException gPCException) {
        PaymentClientInitializeListener paymentClientInitializeListener = this.f128HHHTHHHHHtH;
        if (paymentClientInitializeListener != null) {
            paymentClientInitializeListener.onInitialized(gPCException);
        }
    }

    public final void HHHHTHHHHHHt(GPCException gPCException, List<GPCPaymentClientPurchase> list) {
        PaymentClientPurchasedListener paymentClientPurchasedListener = this.f127HHHTHHHHHt;
        if (paymentClientPurchasedListener != null) {
            paymentClientPurchasedListener.onPurchased(gPCException, list);
        }
    }
}
