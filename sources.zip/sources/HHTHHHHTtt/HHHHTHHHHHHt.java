package HHTHHHHTtt;

import android.text.TextUtils;
import com.gpc.operations.base.CompatProxyManager;
import com.gpc.operations.migrate.bean.GeneralResponse;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.service.network.http.request.HTTPRequestHeadersDelegate;
import com.gpc.operations.migrate.service.request.general.ILegacyServiceClient;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCGameItem;
import com.gpc.tsh.pay.bean.GPCPaymentPurchaseLimitation;
import com.gpc.tsh.pay.flow.listener.PaymentItemsAndUserLimitListener;
import com.gpc.tsh.pay.listener.PaymentItemsListener;
import com.gpc.tsh.pay.service.PaymentService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: PaymentServiceAGImpl */
public class HHHHTHHHHHHt implements PaymentService {

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public static String f210HHHTHHHHHTt = "PaymentServiceAGImpl";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public ILegacyServiceClient f211HHHHTHHHHHHt = ModulesManager.serviceFactory().getService();

    /* renamed from: HHTHHHHTtt.HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
    /* compiled from: PaymentServiceAGImpl */
    public class C0009HHHHTHHHHHHt implements ILegacyServiceClient.GeneralRequestListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ PaymentItemsListener f212HHHHTHHHHHHt;

        public C0009HHHHTHHHHHHt(PaymentItemsListener paymentItemsListener) {
            this.f212HHHHTHHHHHHt = paymentItemsListener;
        }

        public void onGeneralRequestFinished(GPCException gPCException, Integer num, String str) {
            if (this.f212HHHHTHHHHHHt == null) {
                return;
            }
            if (gPCException.isOccurred()) {
                LogUtils.e(HHHHTHHHHHHt.f210HHHTHHHHHTt, "", gPCException);
                this.f212HHHHTHHHHHHt.onComplete(gPCException, (List<GPCGameItem>) null, (List<GPCGameItem>) null);
                return;
            }
            String HHHHTHHHHHHt2 = HHHHTHHHHHHt.f210HHHTHHHHHTt;
            LogUtils.d(HHHHTHHHHHHt2, "responseString:" + str);
            try {
                GeneralResponse generator = GeneralResponse.generator(str);
                if (generator.isSuccess()) {
                    JSONObject jSONObject = new JSONObject(generator.getData());
                    this.f212HHHHTHHHHHHt.onComplete(gPCException, HHHHTHHHHHHt.this.HHHHTHHHHHHt(jSONObject, true), HHHHTHHHHHHt.this.HHHTHHHHHTt(jSONObject, true));
                    return;
                }
                this.f212HHHHTHHHHHHt.onComplete(GPCException.exception("5000"), (List<GPCGameItem>) null, (List<GPCGameItem>) null);
            } catch (JSONException e) {
                LogUtils.e(HHHHTHHHHHHt.f210HHHTHHHHHTt, "", e);
                this.f212HHHHTHHHHHHt.onComplete(GPCException.exception("5001"), (List<GPCGameItem>) null, (List<GPCGameItem>) null);
            }
        }
    }

    public List<GPCGameItem> HHHTHHHHHTt(JSONObject jSONObject, boolean z) throws JSONException {
        if (jSONObject.isNull("sub_card_list")) {
            return new ArrayList();
        }
        return HHHHTHHHHHHt(jSONObject.getString("sub_card_list"), z);
    }

    public void loadItems(String str, String str2, String str3, boolean z, PaymentItemsAndUserLimitListener paymentItemsAndUserLimitListener) {
        HHHHTHHHHHHt(str, str2, str3, z, new PaymentItemsListener() {
            public final void onComplete(GPCException gPCException, List list, List list2) {
                HHHHTHHHHHHt.HHHHTHHHHHHt(PaymentItemsAndUserLimitListener.this, gPCException, list, list2);
            }
        });
    }

    public void HHHHTHHHHHHt(String str, String str2, String str3, boolean z, PaymentItemsListener paymentItemsListener) {
        String gameId = CompatProxyManager.sharedInstance().getProxy().getGameId();
        HashMap hashMap = new HashMap();
        hashMap.put("game_id", gameId);
        hashMap.put("pay_method", str2);
        hashMap.put("user_id", str);
        if (!TextUtils.isEmpty(str3)) {
            hashMap.put("labels", str3);
        }
        this.f211HHHHTHHHHHHt.getRequest("/pay/hub/get_card_list", hashMap, 15000, 15000, z, (HTTPRequestHeadersDelegate) null, new C0009HHHHTHHHHHHt(paymentItemsListener));
    }

    public List<GPCGameItem> HHHHTHHHHHHt(JSONObject jSONObject, boolean z) throws JSONException {
        if (jSONObject.isNull("card_list")) {
            return new ArrayList();
        }
        return HHHHTHHHHHHt(jSONObject.getString("card_list"), z);
    }

    public List<GPCGameItem> HHHHTHHHHHHt(String str, boolean z) throws JSONException {
        JSONArray jSONArray = new JSONArray(str);
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < jSONArray.length(); i++) {
            arrayList.add(GPCGameItem.createFromJsonV2(jSONArray.getJSONObject(i), z));
        }
        return arrayList;
    }

    public static /* synthetic */ void HHHHTHHHHHHt(PaymentItemsAndUserLimitListener paymentItemsAndUserLimitListener, GPCException gPCException, List list, List list2) {
        if (gPCException.isOccurred()) {
            paymentItemsAndUserLimitListener.onPaymentItemsLoadFinished(gPCException, (HHTHHHHtHH.HHHHTHHHHHHt) null);
        } else {
            paymentItemsAndUserLimitListener.onPaymentItemsLoadFinished(gPCException, new HHTHHHHtHH.HHHHTHHHHHHt(list2, list, GPCPaymentPurchaseLimitation.GPCPaymentPurchaseLimitationNone.getValue()));
        }
    }
}
