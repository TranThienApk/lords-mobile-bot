package HHTHHHHTtt;

import com.google.firebase.analytics.FirebaseAnalytics;
import com.gpc.operations.migrate.bean.GeneralResponse;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.service.request.cgi.ServiceRequest;
import com.gpc.operations.migrate.service.request.cgi.builder.ServiceRequestAGBuilder;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import com.gpc.tsh.pay.service.PurchaseService;
import com.gpc.tsh.pay.service.listener.SubmittalFinishedListener;
import java.util.HashMap;

/* compiled from: PurchaseGatewayServiceAGImpl */
public class HHHTHHHHHTt implements PurchaseService {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f214HHHHTHHHHHHt = "PurchaseGatewayServiceAGImpl";

    /* compiled from: PurchaseGatewayServiceAGImpl */
    public class HHHHTHHHHHHt implements ServiceRequest.ServiceRequestFinishListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ SubmittalFinishedListener f215HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ GPCPaymentClientPurchase f216HHHTHHHHHTt;

        public HHHHTHHHHHHt(SubmittalFinishedListener submittalFinishedListener, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
            this.f215HHHHTHHHHHHt = submittalFinishedListener;
            this.f216HHHTHHHHHTt = gPCPaymentClientPurchase;
        }

        public void onFinished(GPCException gPCException, String str) {
            if (gPCException.isOccurred() || str == null || "".equals(str)) {
                this.f215HHHHTHHHHHHt.onPurchaseSubmittalFinished(false, (PaymentDeliveryState) null, this.f216HHHTHHHHHTt, 30);
                return;
            }
            try {
                if (GeneralResponse.generator(str).isSuccess()) {
                    this.f215HHHHTHHHHHHt.onPurchaseSubmittalFinished(true, PaymentDeliveryState.REQUEST_ACK, this.f216HHHTHHHHHTt, 30);
                } else {
                    this.f215HHHHTHHHHHHt.onPurchaseSubmittalFinished(false, (PaymentDeliveryState) null, this.f216HHHTHHHHHTt, 30);
                }
            } catch (Exception e) {
                LogUtils.e(HHHTHHHHHTt.f214HHHHTHHHHHHt, "", e);
                this.f215HHHHTHHHHHHt.onPurchaseSubmittalFinished(false, (PaymentDeliveryState) null, this.f216HHHTHHHHHTt, 30);
            }
        }
    }

    public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, String str2, String str3, SubmittalFinishedListener submittalFinishedListener) {
        HashMap hashMap = new HashMap();
        hashMap.put("user_id", str2);
        hashMap.put("game_id", str);
        hashMap.put(FirebaseAnalytics.Param.PAYMENT_TYPE, "google_play");
        HashMap hashMap2 = new HashMap();
        hashMap2.put("signature", gPCPaymentClientPurchase.getSignature());
        hashMap2.put("signed_data", gPCPaymentClientPurchase.getOriginalJson());
        hashMap2.put("payload", str3);
        HHHHTHHHHHHt("/pay/gateway/android/app/notify", (HashMap<String, String>) hashMap, (HashMap<String, String>) hashMap2, gPCPaymentClientPurchase, submittalFinishedListener);
    }

    public void submit(PaymentType paymentType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, String str2, String str3, SubmittalFinishedListener submittalFinishedListener) {
        if (PaymentType.GOOGLE_PLAY == paymentType) {
            LogUtils.i(f214HHHHTHHHHHHt, "submitGoogle payload:" + str3);
            HHHHTHHHHHHt(gPCPaymentClientPurchase, str, str2, str3, submittalFinishedListener);
            return;
        }
        LogUtils.e(f214HHHHTHHHHHHt, "unknown type:" + paymentType.getName());
    }

    public void HHHHTHHHHHHt(String str, HashMap<String, String> hashMap, HashMap<String, String> hashMap2, GPCPaymentClientPurchase gPCPaymentClientPurchase, SubmittalFinishedListener submittalFinishedListener) {
        ModulesManager.serviceFactory().getServiceCall().call(new ServiceRequestAGBuilder(str).body(hashMap2).parameters(hashMap).method(ServiceRequest.RequestMethod.POST).requestFinishListener(new HHHHTHHHHHHt(submittalFinishedListener, gPCPaymentClientPurchase)).build());
    }
}
