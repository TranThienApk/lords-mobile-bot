package android.adservices.topics;

import android.content.Context;
import android.os.OutcomeReceiver;
import java.util.concurrent.Executor;

public final class TopicsManager {
    TopicsManager() {
        throw new RuntimeException("Stub!");
    }

    public static TopicsManager get(Context context) {
        throw new RuntimeException("Stub!");
    }

    public void getTopics(GetTopicsRequest getTopicsRequest, Executor executor, OutcomeReceiver<GetTopicsResponse, Exception> outcomeReceiver) {
        throw new RuntimeException("Stub!");
    }
}
