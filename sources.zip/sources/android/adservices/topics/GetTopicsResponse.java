package android.adservices.topics;

import java.util.List;

public final class GetTopicsResponse {
    GetTopicsResponse() {
        throw new RuntimeException("Stub!");
    }

    public List<Topic> getTopics() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }

    public static final class Builder {
        public Builder(List<Topic> list) {
            throw new RuntimeException("Stub!");
        }

        public GetTopicsResponse build() {
            throw new RuntimeException("Stub!");
        }
    }
}
