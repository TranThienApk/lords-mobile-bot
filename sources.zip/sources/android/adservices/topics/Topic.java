package android.adservices.topics;

import java.util.List;

public final class Topic {
    Topic() {
        throw new RuntimeException("Stub!");
    }

    public long getModelVersion() {
        throw new RuntimeException("Stub!");
    }

    public long getTaxonomyVersion() {
        throw new RuntimeException("Stub!");
    }

    public int getTopicId() {
        throw new RuntimeException("Stub!");
    }

    public boolean equals(Object obj) {
        throw new RuntimeException("Stub!");
    }

    public int hashCode() {
        throw new RuntimeException("Stub!");
    }

    public static final class Builder {
        public Builder(List<Topic> list) {
            throw new RuntimeException("Stub!");
        }

        public Topic build() {
            throw new RuntimeException("Stub!");
        }
    }
}
