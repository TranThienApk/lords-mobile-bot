package android.adservices.topics;

public final class GetTopicsRequest {
    GetTopicsRequest() {
        throw new RuntimeException("Stub!");
    }

    public String getAdsSdkName() {
        throw new RuntimeException("Stub!");
    }

    public boolean shouldRecordObservation() {
        throw new RuntimeException("Stub!");
    }

    public static final class Builder {
        public Builder() {
            throw new RuntimeException("Stub!");
        }

        public Builder setAdsSdkName(String str) {
            throw new RuntimeException("Stub!");
        }

        public Builder setShouldRecordObservation(boolean z) {
            throw new RuntimeException("Stub!");
        }

        public GetTopicsRequest build() {
            throw new RuntimeException("Stub!");
        }
    }
}
