package HHHTHHHHTHt;

import HHHTHHHHTtT.HHHTHHHHTTt;
import android.app.Activity;
import android.content.Intent;
import android.text.TextUtils;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.error.utils.ExceptionUtils;
import com.gpc.operations.migrate.utils.MD5;
import com.gpc.operations.migrate.utils.SDKTask;
import com.gpc.operations.migrate.utils.common.eventcollection.SDKEventHelper;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.pay.bean.GPCGameItem;
import com.gpc.tsh.pay.bean.GPCGatewayPayload;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.GPCPaymentGatewayResult;
import com.gpc.tsh.pay.bean.GPCPaymentPayload;
import com.gpc.tsh.pay.bean.GPCPurchaseFailureType;
import com.gpc.tsh.pay.bean.OrderType;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.error.PaymentErrorCode;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumeFinishListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientInitializeListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientPurchasedListener;
import com.gpc.tsh.pay.flow.listener.IPurchaseStateListener;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.flow.purchase.QueryPurchasesScheduler;
import com.gpc.tsh.pay.flow.purchase.TransactionQuerier;
import com.gpc.tsh.pay.listener.PurchaseRedeliveryListener;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import com.gpc.tsh.pay.utils.HHHTHHHHHtH;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: NewPayment */
public class HHHHTHHHHHHt implements PaymentClientInitializeListener, PaymentClientPurchasedListener, PaymentTransactionStateListener, QueryPurchasesScheduler.GPCQueryPurchasesScheduleResultListener {
    public static final String HHHTHHHHtTt = "NewPayment";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public PaymentType f82HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public Activity f83HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public String f84HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public String f85HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public OrderType f86HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public String f87HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public GPCPaymentPayload f88HHHTHHHHTHt;

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public IPurchaseStateListener f89HHHTHHHHTTt;

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public HHHTHHHHTtH.HHHHTHHHHHHt f90HHHTHHHHTt;

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public PurchaseRedeliveryListener f91HHHTHHHHTtH;

    /* renamed from: HHHTHHHHTtT  reason: collision with root package name */
    public String f92HHHTHHHHTtT;

    /* renamed from: HHTHHHHTtt  reason: collision with root package name */
    public HHHTHHHHTTt f93HHTHHHHTtt;
    public boolean HHTHHHHt = false;
    public TransactionQuerier HHTHHHHtH;

    /* renamed from: HHTHHHHtHH  reason: collision with root package name */
    public QueryPurchasesScheduler f94HHTHHHHtHH;
    public com.gpc.tsh.pay.utils.HHHTHHHHHtH HHTHHHHtHT;
    public AtomicBoolean HHTHHHHtHt = new AtomicBoolean(false);
    public SDKTask HHTHHHHtT = new SDKTask();
    public String HHTHHHHtTH = "";
    public HHHTHHHHTTt.HHHTHHHHHTt HHTHHHHtTT;

    /* renamed from: HHHTHHHHTHt.HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
    /* compiled from: NewPayment */
    public class C0005HHHHTHHHHHHt implements PaymentClientConsumeFinishListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ int f95HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ int f96HHHTHHHHHTt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ List f98HHHTHHHHHtH;

        public C0005HHHHTHHHHHHt(int i, int i2, List list) {
            this.f95HHHHTHHHHHHt = i;
            this.f96HHHTHHHHHTt = i2;
            this.f98HHHTHHHHHtH = list;
        }

        public void onFinish(GPCException gPCException, boolean z) {
            LogUtils.d(HHHHTHHHHHHt.HHHTHHHHtTt, "manager.processTransactionImmediately onFinish:" + z);
            if (z) {
                int i = this.f95HHHHTHHHHHHt + 1;
                if (this.f96HHHTHHHHHTt > i) {
                    HHHHTHHHHHHt.this.HHHHTHHHHHHt((List<GPCPaymentClientPurchase>) this.f98HHHTHHHHHtH, i);
                    return;
                }
                IPurchaseStateListener iPurchaseStateListener = HHHHTHHHHHHt.this.f89HHHTHHHHTTt;
                if (iPurchaseStateListener != null) {
                    iPurchaseStateListener.onGPCPurchasePreparingFinished(GPCException.noneException());
                    return;
                }
                return;
            }
            IPurchaseStateListener iPurchaseStateListener2 = HHHHTHHHHHHt.this.f89HHHTHHHHTTt;
            if (iPurchaseStateListener2 != null) {
                iPurchaseStateListener2.onGPCPurchasePreparingFinished(GPCException.noneException());
            }
        }
    }

    /* compiled from: NewPayment */
    public class HHHTHHHHHTt implements SDKTask.SDKTaskRunnable<HHHTHHHHHt> {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCException f99HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ List f100HHHTHHHHHTt;

        public HHHTHHHHHTt(GPCException gPCException, List list) {
            this.f99HHHHTHHHHHHt = gPCException;
            this.f100HHHTHHHHHTt = list;
        }

        /* renamed from: HHHHTHHHHHHt */
        public HHHTHHHHHt run() throws Exception {
            GPCPaymentClientPurchase gPCPaymentClientPurchase;
            List list;
            if (this.f99HHHHTHHHHHHt.isNone() && (list = this.f100HHHTHHHHHTt) != null && list.size() > 0) {
                LogUtils.d(HHHHTHHHHHHt.HHHTHHHHtTt, "Purchase successful try to post to ");
                HHHHTHHHHHHt.this.HHHTHHHHHtH((GPCPaymentClientPurchase) this.f100HHHTHHHHHTt.get(0));
                if (this.f100HHHTHHHHHTt.size() == 1) {
                    GPCPaymentClientPurchase gPCPaymentClientPurchase2 = (GPCPaymentClientPurchase) this.f100HHHTHHHHHTt.get(0);
                    LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "onPurchased:" + gPCPaymentClientPurchase2);
                    HHHHTHHHHHHt.this.HHHHTHHHHHHt(gPCPaymentClientPurchase2);
                    HHHHTHHHHHHt.this.f93HHTHHHHTtt.HHHTHHHHHtH(gPCPaymentClientPurchase2);
                } else {
                    for (GPCPaymentClientPurchase HHHHTHHHHHHt2 : this.f100HHHTHHHHHTt) {
                        HHHHTHHHHHHt.this.HHHHTHHHHHHt(HHHHTHHHHHHt2);
                    }
                    HHHHTHHHHHHt.this.f93HHTHHHHTtt.HHHHTHHHHHHt((List<GPCPaymentClientPurchase>) this.f100HHHTHHHHHTt);
                }
            } else if (TextUtils.equals(this.f99HHHHTHHHHHHt.getCode(), "-3")) {
                LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "user cancled.");
                HHHHTHHHHHHt.this.HHHHTHHHHHHt(this.f99HHHHTHHHHHHt, GPCPurchaseFailureType.IAB_CANCELED, (GPCPaymentClientPurchase) null);
            } else if (TextUtils.equals(this.f99HHHHTHHHHHHt.getCode(), "-4")) {
                LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "user ANOTHER_OPERATION_RUNNING_NEED_AWAITING.");
                HHHHTHHHHHHt.this.HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.SAMSUNG_PAYMENT_ERROR_FOR_PAY_BUT_ANOTHER_OPERATION_RUNNING, "20", 911106), GPCPurchaseFailureType.IAB_PURCHASE, (GPCPaymentClientPurchase) null);
            } else if (TextUtils.equals(this.f99HHHHTHHHHHHt.getCode(), "-5")) {
                LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "user REPEAT_PURCHASE.");
                String str = "";
                List list2 = this.f100HHHTHHHHHTt;
                if (list2 == null || list2.size() <= 0) {
                    LogUtils.e(HHHHTHHHHHHt.HHHTHHHHtTt, "itemId not found.");
                    if (TextUtils.isEmpty(str)) {
                        str = HHHHTHHHHHHt.this.HHTHHHHtTH;
                    }
                    gPCPaymentClientPurchase = null;
                } else {
                    String sku = ((GPCPaymentClientPurchase) this.f100HHHTHHHHHTt.get(0)).getSku();
                    gPCPaymentClientPurchase = (GPCPaymentClientPurchase) this.f100HHHTHHHHHTt.get(0);
                    str = sku;
                }
                LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "itemId：" + str);
                HHHHTHHHHHHt.this.HHHTHHHHHTt(this.f99HHHHTHHHHHHt, GPCPurchaseFailureType.IAB_PURCHASE, gPCPaymentClientPurchase);
                HHHHTHHHHHHt.this.HHHHTHHHHHHt(this.f99HHHHTHHHHHHt, str);
            } else {
                LogUtils.i(HHHHTHHHHHHt.HHHTHHHHtTt, "user PAYMENT_ERROR_FOR_PURCHASEFLOW_RESULT_FAILURE:" + HHHHTHHHHHHt.this.HHHHTHHHHHHt(this.f99HHHHTHHHHHHt));
                HHHHTHHHHHHt hHHHTHHHHHHt = HHHHTHHHHHHt.this;
                hHHHTHHHHHHt.HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PURCHASEFLOW_RESULT_FAILURE, "20", hHHHTHHHHHHt.HHHHTHHHHHHt(this.f99HHHHTHHHHHHt)), GPCPurchaseFailureType.IAB_PURCHASE, (GPCPaymentClientPurchase) null);
            }
            LogUtils.d(HHHHTHHHHHHt.HHHTHHHHtTt, "out OnIabPurchaseFinishedListener");
            return null;
        }
    }

    /* compiled from: NewPayment */
    public class HHHTHHHHHt {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public GPCException f102HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public GPCPurchaseFailureType f103HHHTHHHHHTt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public GPCPaymentClientPurchase f105HHHTHHHHHtH;

        public HHHTHHHHHt(GPCException gPCException, GPCPurchaseFailureType gPCPurchaseFailureType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
            this.f102HHHHTHHHHHHt = gPCException;
            this.f103HHHTHHHHHTt = gPCPurchaseFailureType;
            this.f105HHHTHHHHHtH = gPCPaymentClientPurchase;
        }
    }

    /* compiled from: NewPayment */
    public class HHHTHHHHHtH implements SDKTask.SDKTaskResultListener<HHHTHHHHHt> {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ GPCException f106HHHHTHHHHHHt;

        public HHHTHHHHHtH(GPCException gPCException) {
            this.f106HHHHTHHHHHHt = gPCException;
        }

        /* renamed from: HHHHTHHHHHHt */
        public void onResult(GPCException gPCException, HHHTHHHHHt hHHTHHHHHt) {
            if (gPCException.isOccurred()) {
                HHHHTHHHHHHt hHHHTHHHHHHt = HHHHTHHHHHHt.this;
                hHHHTHHHHHHt.HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PURCHASEFLOW_RESULT_FAILURE, "20", hHHHTHHHHHHt.HHHHTHHHHHHt(this.f106HHHHTHHHHHHt)), GPCPurchaseFailureType.IAB_PURCHASE, (GPCPaymentClientPurchase) null);
            }
        }
    }

    public HHHHTHHHHHHt(Activity activity, PaymentType paymentType, String str, String str2, HHHTHHHHTTt.HHHTHHHHHTt hHHTHHHHHTt) {
        this.f85HHHTHHHHHtH = str;
        this.f84HHHTHHHHHt = str2;
        this.f82HHHHTHHHHHHt = paymentType;
        this.f83HHHTHHHHHTt = activity;
        this.HHTHHHHtTT = hHHTHHHHHTt;
    }

    public void HHHHTHHHHHHt(IPurchaseStateListener iPurchaseStateListener) {
        this.f89HHHTHHHHTTt = iPurchaseStateListener;
        this.HHTHHHHtH = new TransactionQuerier(this.f83HHHTHHHHHTt, this.f82HHHHTHHHHHHt);
        this.HHTHHHHtHT = new com.gpc.tsh.pay.utils.HHHTHHHHHtH(this.f83HHHTHHHHHTt);
        HHHTHHHHTtH.HHHHTHHHHHHt hHHHTHHHHHHt = new HHHTHHHHTtH.HHHHTHHHHHHt(this.f83HHHTHHHHHTt, this.f82HHHHTHHHHHHt);
        this.f90HHHTHHHHTt = hHHHTHHHHHHt;
        hHHHTHHHHHHt.init(this);
    }

    public void HHHTHHHHHTt() {
        LogUtils.d(HHHTHHHHtTt, "Destroying PaymentClient.");
        if (this.f90HHHTHHHHTt != null) {
            LogUtils.i(HHHTHHHHtTt, "NewPayment destroy:" + this.f90HHHTHHHHTt);
            this.f90HHHTHHHHTt.destroy();
        }
    }

    public String HHHTHHHHHt() {
        return this.f85HHHTHHHHHtH;
    }

    public void HHHTHHHHHtH(GPCException gPCException) {
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.onGPCPurchaseStartingFinished(gPCException);
        }
    }

    public PaymentType HHHTHHHHHtT() {
        return this.f82HHHHTHHHHHHt;
    }

    public String HHHTHHHHHtt() {
        return this.f84HHHTHHHHHt;
    }

    public boolean HHHTHHHHTHt() {
        return this.HHTHHHHtHt.get();
    }

    public void onCommitGatewayFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        HHHHTHHHHHHt(paymentTransactionHandleType, GPCException.exception("911107"), GPCPurchaseFailureType.GPC_GATEWAY, gPCPaymentClientPurchase);
    }

    public void onCommitGatewaySuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState) {
        HHHHTHHHHHHt(gPCPaymentClientPurchase, str, paymentDeliveryState, paymentTransactionHandleType);
    }

    public void onConsumeFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
    }

    public void onConsumeSuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
    }

    public void onInitialized(GPCException gPCException) {
        if (this.HHTHHHHt) {
            HHHTHHHHHTt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_INIT_BUT_DESTORYING, "10", 911105));
            SDKEventHelper.Companion.sdkPayInitFailEvent(this.f82HHHHTHHHHHHt.getName(), gPCException);
            return;
        }
        LogUtils.d(HHHTHHHHtTt, "QueryHelper startSetup Success");
        if (gPCException.isNone()) {
            LogUtils.d(HHHTHHHHtTt, "QueryHelper startSetup Success e.isNone()");
            this.HHTHHHHtHt.set(true);
            HHHTHHHHTTt hHHTHHHHTTt = new HHHTHHHHTTt(this.f83HHHTHHHHHTt, this.f82HHHHTHHHHHHt, this.f85HHHTHHHHHtH, this.f84HHHTHHHHHt);
            this.f93HHTHHHHTtt = hHHTHHHHTTt;
            hHHTHHHHTTt.HHHHTHHHHHHt((PaymentTransactionStateListener) this);
            QueryPurchasesScheduler queryPurchasesScheduler = new QueryPurchasesScheduler(this.f83HHHTHHHHHTt, this.f82HHHHTHHHHHHt);
            this.f94HHTHHHHtHH = queryPurchasesScheduler;
            queryPurchasesScheduler.HHHHTHHHHHHt((QueryPurchasesScheduler.GPCQueryPurchasesScheduleResultListener) this);
            HHHTHHHHHTt(gPCException);
            return;
        }
        SDKEventHelper.Companion.sdkPayInitFailEvent(this.f82HHHHTHHHHHHt.getName(), gPCException);
        HHHTHHHHHTt(gPCException);
        LogUtils.d(HHHTHHHHtTt, "QueryHelper startSetup Success e.isOccurred():" + gPCException.getCode());
    }

    public void onPurchased(GPCException gPCException, List<GPCPaymentClientPurchase> list) {
        this.HHTHHHHtT.excuteForTimeConsuming(new HHHTHHHHHTt(gPCException, list), new HHHTHHHHHtH(gPCException));
    }

    public void onQueryPurchasesScheduleResult(GPCException gPCException, List<GPCPaymentClientPurchase> list) {
        List<String> HHHHTHHHHHHt2;
        if (list != null) {
            LogUtils.i(HHHTHHHHtTt, "onQueryPurchasesScheduleResult:" + list.size());
            for (GPCPaymentClientPurchase next : list) {
                LogUtils.i(HHHTHHHHtTt, "onQueryPurchasesScheduleResult:" + next);
                if (!TextUtils.equals(next.getSku(), this.HHTHHHHtTH) && (HHHHTHHHHHHt2 = HHHTHHHHTTt.HHHHTHHHHHHt.HHHHTHHHHHHt()) != null && HHHHTHHHHHHt2.contains(next.getSku())) {
                    this.f93HHTHHHHTtt.HHHTHHHHHTt(next);
                }
            }
        }
    }

    public void onReceivedQueryInventoryTaskInterval(int i) {
        QueryPurchasesScheduler queryPurchasesScheduler = this.f94HHTHHHHtHH;
        if (queryPurchasesScheduler != null) {
            queryPurchasesScheduler.HHHHTHHHHHHt(i);
        }
    }

    public void onSubItemHasCommited() {
    }

    public void HHHTHHHHHt(String str) {
        this.f84HHHTHHHHHt = str;
    }

    public void HHHTHHHHHtH(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.onGPCPurchaseSuccessFromPlatfrom(gPCPaymentClientPurchase);
        }
    }

    public boolean HHHTHHHHHTt(String str) {
        List<GPCPaymentClientPurchase> HHHTHHHHHTt2 = this.f93HHTHHHHTtt.HHHTHHHHHTt();
        boolean z = false;
        GPCPaymentClientPurchase gPCPaymentClientPurchase = null;
        if (HHHTHHHHHTt2 != null) {
            Iterator<GPCPaymentClientPurchase> it = HHHTHHHHHTt2.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                gPCPaymentClientPurchase = it.next();
                LogUtils.e(HHHTHHHHtTt, "The last  unconsumed product ID:" + gPCPaymentClientPurchase.getSku());
                if (TextUtils.equals(gPCPaymentClientPurchase.getItemType(), "inapp") && gPCPaymentClientPurchase.getSku().equals(str)) {
                    z = true;
                    break;
                }
            }
        }
        if (z) {
            LogUtils.d(HHHTHHHHtTt, "you have by the item just post to :" + str);
            this.f93HHTHHHHTtt.HHHTHHHHHtH(gPCPaymentClientPurchase);
        }
        return z;
    }

    public Activity HHHTHHHHHtH() {
        return this.f83HHHTHHHHHTt;
    }

    public void HHHHTHHHHHHt() {
        LogUtils.d(HHHTHHHHtTt, "destroy.");
        this.HHTHHHHt = true;
        this.f89HHHTHHHHTTt = null;
        this.f91HHHTHHHHTtH = null;
        if (HHHTHHHHTHt()) {
            QueryPurchasesScheduler queryPurchasesScheduler = this.f94HHTHHHHtHH;
            if (queryPurchasesScheduler != null) {
                queryPurchasesScheduler.HHHHTHHHHHHt();
                this.f94HHTHHHHtHH = null;
            }
            this.f93HHTHHHHTtt.HHHHTHHHHHHt();
        }
        this.HHTHHHHtH.HHHHTHHHHHHt();
        HHHTHHHHHTt();
        this.HHTHHHHtHt.set(false);
    }

    public void HHHTHHHHHtH(String str) {
        this.f85HHHTHHHHHtH = str;
    }

    public GPCGameItem HHHTHHHHHTt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        GPCGameItem HHHHTHHHHHHt2 = this.HHTHHHHtTT.HHHHTHHHHHHt(gPCPaymentClientPurchase.getSku());
        return HHHHTHHHHHHt2 == null ? this.HHTHHHHtTT.HHHTHHHHHTt(gPCPaymentClientPurchase.getSku()) : HHHHTHHHHHHt2;
    }

    public void HHHTHHHHHTt(GPCException gPCException) {
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.onGPCPurchasePreparingFinished(gPCException);
        }
    }

    public void HHHHTHHHHHHt(PurchaseRedeliveryListener purchaseRedeliveryListener) {
        this.f91HHHTHHHHTtH = purchaseRedeliveryListener;
    }

    public void HHHTHHHHHTt(GPCException gPCException, GPCPurchaseFailureType gPCPurchaseFailureType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        String str;
        String str2;
        String str3;
        if (gPCPaymentClientPurchase != null) {
            str2 = gPCPaymentClientPurchase.getSku();
            str = gPCPaymentClientPurchase.getOrderId();
        } else {
            str2 = "";
            str = str2;
        }
        if (str2 == null) {
            str3 = "";
        } else {
            str3 = str2;
        }
        try {
            if (gPCException.isOccurred()) {
                gPCException.printReadableUniqueCode();
            }
            SDKEventHelper.Companion.sdkPayFailEvent(this.f82HHHHTHHHHHHt.getName(), str3, str, gPCPurchaseFailureType.name(), gPCException);
        } catch (Exception e) {
            LogUtils.e(HHHTHHHHtTt, "", e);
        }
    }

    public void HHHHTHHHHHHt(String str, String str2, GPCPaymentPayload gPCPaymentPayload) {
        this.f86HHHTHHHHHtT = OrderType.FRAUD_REPAY;
        this.f87HHHTHHHHHtt = str2;
        HHHHTHHHHHHt(str);
    }

    public void HHHHTHHHHHHt(String str, GPCPaymentPayload gPCPaymentPayload) {
        this.f86HHHTHHHHHtT = OrderType.NORMAL;
        this.f87HHHTHHHHHtt = "";
        this.f88HHHTHHHHTHt = gPCPaymentPayload;
        HHHTHHHHTTt hHHTHHHHTTt = this.f93HHTHHHHTtt;
        if (hHHTHHHHTTt != null) {
            hHHTHHHHTTt.HHHHTHHHHHHt(gPCPaymentPayload);
        }
        HHHHTHHHHHHt(str);
    }

    public void HHHHTHHHHHHt(String str) {
        if (!HHHTHHHHTHt()) {
            HHHTHHHHHtH(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_PAYMENT_NOT_AVAILABLE, "10", 911103));
        } else if (str == null || !str.equals(this.HHTHHHHtTH)) {
            if (!HHHTHHHHHTt(str)) {
                LogUtils.d(HHHTHHHHtTt, "try to buy flow " + str);
                try {
                    this.f92HHHTHHHHTtT = "inapp";
                    String generateInAppItemPayload = GPCGatewayPayload.generateInAppItemPayload(this.f84HHHTHHHHHt, this.f86HHHTHHHHHtT, this.f87HHHTHHHHHtt, this.f88HHHTHHHHTHt);
                    this.HHTHHHHtTH = str;
                    HHHTHHHHTtH.HHHHTHHHHHHt hHHHTHHHHHHt = this.f90HHHTHHHHTt;
                    String str2 = this.f92HHHTHHHHTtT;
                    MD5 md5 = new MD5();
                    hHHHTHHHHHHt.purchaseFlow(str, str2, md5.getMD5ofStr("UserId:" + this.f84HHHTHHHHHt), generateInAppItemPayload, this);
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHtTt, "Error launching purchase flow. Another async operation in progress.", e);
                    HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_LAST_TASK_UNCOMPLETE, "10", 911104), GPCPurchaseFailureType.IAB_PURCHASE, (GPCPaymentClientPurchase) null);
                }
            }
            LogUtils.d(HHHTHHHHtTt, "out pay");
        } else {
            LogUtils.i(HHHTHHHHtTt, "buy same item: " + str);
            HHHHTHHHHHHt(ExceptionUtils.instantiatedException(PaymentErrorCode.PAYMENT_ERROR_FOR_BUY_SAME_ITEM, "10"), str);
        }
    }

    public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState, PaymentTransactionHandleType paymentTransactionHandleType) {
        GPCPaymentGatewayResult gPCPaymentGatewayResult = new GPCPaymentGatewayResult();
        gPCPaymentGatewayResult.setDeliveryState(paymentDeliveryState);
        gPCPaymentGatewayResult.setUserId(str);
        if (paymentDeliveryState != null) {
            LogUtils.d(HHHTHHHHtTt, "item purchase state:" + paymentDeliveryState);
            gPCPaymentGatewayResult.setItem(HHHTHHHHHTt(gPCPaymentClientPurchase));
        }
        LogUtils.d(HHHTHHHHtTt, "PaymentTransactionHandleType:" + paymentTransactionHandleType.name());
        if (PaymentTransactionHandleType.Processor == paymentTransactionHandleType) {
            try {
                HHHHTHHHHHHt(GPCException.noneException(), gPCPaymentClientPurchase, gPCPaymentGatewayResult);
            } catch (Exception e) {
                LogUtils.e(HHHTHHHHtTt, "", e);
            }
        }
        try {
            PurchaseRedeliveryListener purchaseRedeliveryListener = this.f91HHHTHHHHTtH;
            if (purchaseRedeliveryListener != null) {
                purchaseRedeliveryListener.onGPCPurchaseFinished(paymentTransactionHandleType, gPCPaymentClientPurchase, gPCPaymentGatewayResult);
            }
        } catch (Exception e2) {
            LogUtils.e(HHHTHHHHtTt, "", e2);
        }
    }

    public void HHHHTHHHHHHt(GPCGameItem gPCGameItem) {
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.onGPCSubscriptionShouldMakeRecurringPaymentsInstead(gPCGameItem);
        }
    }

    public void HHHHTHHHHHHt(GPCException gPCException, GPCPaymentClientPurchase gPCPaymentClientPurchase, GPCPaymentGatewayResult gPCPaymentGatewayResult) {
        this.HHTHHHHtTH = "";
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.onGPCPurchaseFinished(gPCException, gPCPaymentClientPurchase, gPCPaymentGatewayResult);
        }
    }

    public void HHHHTHHHHHHt(GPCException gPCException, GPCPurchaseFailureType gPCPurchaseFailureType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        HHHHTHHHHHHt(PaymentTransactionHandleType.Processor, gPCException, gPCPurchaseFailureType, gPCPaymentClientPurchase);
    }

    public void HHHHTHHHHHHt(PaymentTransactionHandleType paymentTransactionHandleType, GPCException gPCException, GPCPurchaseFailureType gPCPurchaseFailureType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        HHHTHHHHHTt(gPCException, gPCPurchaseFailureType, gPCPaymentClientPurchase);
        LogUtils.d(HHHTHHHHtTt, "PaymentTransactionHandleType:" + paymentTransactionHandleType.name());
        if (PaymentTransactionHandleType.Processor == paymentTransactionHandleType) {
            try {
                this.HHTHHHHtTH = "";
                if (this.f89HHHTHHHHTTt != null) {
                    if (TextUtils.equals(gPCException.getCode(), "-3")) {
                        this.f89HHHTHHHHTTt.onGPCPurchaseFailed(GPCException.noneException(), gPCPurchaseFailureType, gPCPaymentClientPurchase);
                    } else {
                        this.f89HHHTHHHHTTt.onGPCPurchaseFailed(gPCException, gPCPurchaseFailureType, gPCPaymentClientPurchase);
                    }
                }
            } catch (Exception e) {
                LogUtils.e(HHHTHHHHtTt, "", e);
            }
        }
        try {
            PurchaseRedeliveryListener purchaseRedeliveryListener = this.f91HHHTHHHHTtH;
            if (purchaseRedeliveryListener != null) {
                purchaseRedeliveryListener.onGPCPurchaseFailed(paymentTransactionHandleType, gPCException, gPCPurchaseFailureType, gPCPaymentClientPurchase);
            }
        } catch (Exception e2) {
            LogUtils.e(HHHTHHHHtTt, "", e2);
        }
    }

    public void HHHHTHHHHHHt(GPCException gPCException, String str) {
        IPurchaseStateListener iPurchaseStateListener = this.f89HHHTHHHHTTt;
        if (iPurchaseStateListener != null) {
            iPurchaseStateListener.OnGPCPurchaseFailedDueToThePendingPurchaseOfTheSameItem(gPCException, str);
        }
    }

    public boolean HHHHTHHHHHHt(int i, int i2, Intent intent) {
        LogUtils.d("PayActivity", "onActivityResult(" + i + "," + i2);
        this.f90HHHTHHHHTt.onActivityResult(i, i2, intent);
        return false;
    }

    public void HHHHTHHHHHHt(List<GPCPaymentClientPurchase> list, int i) {
        if (list != null && list.size() > 0) {
            int size = list.size();
            GPCPaymentClientPurchase gPCPaymentClientPurchase = list.get(i);
            LogUtils.d(HHHTHHHHtTt, "processTransaction paymentClientPurchase skyu:" + gPCPaymentClientPurchase.getSku());
            HHHHTHHHHHHt(gPCPaymentClientPurchase);
            this.f93HHTHHHHTtt.HHHHTHHHHHHt(gPCPaymentClientPurchase, (PaymentClientConsumeFinishListener) new C0005HHHHTHHHHHHt(i, size, list));
        } else if (this.f89HHHTHHHHTTt != null) {
            LogUtils.d(HHHTHHHHtTt, "manager.processTransactionImmediately purchases null");
            this.f89HHHTHHHHTTt.onGPCPurchasePreparingFinished(GPCException.noneException());
        }
    }

    public int HHHHTHHHHHHt(GPCException gPCException) {
        try {
            return Integer.parseInt(gPCException.getCode());
        } catch (Exception e) {
            e.printStackTrace();
            return -9999;
        }
    }

    public void HHHHTHHHHHHt(GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        this.HHTHHHHtHT.HHHHTHHHHHHt(new HHHTHHHHHtH.HHHHTHHHHHHt(gPCPaymentClientPurchase.getOrderId(), this.f84HHHTHHHHHt, this.f85HHHTHHHHHtH, GPCGatewayPayload.generateInAppItemPayload(this.f84HHHTHHHHHt, this.f86HHHTHHHHHtT, this.f87HHHTHHHHHtt, this.f88HHHTHHHHTHt)));
    }
}
