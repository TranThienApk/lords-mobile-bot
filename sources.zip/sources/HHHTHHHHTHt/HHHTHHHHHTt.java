package HHHTHHHHTHt;

import HHHTHHHHTtH.HHHHTHHHHHHt;
import HHHTHHHHTtT.HHHTHHHHHt;
import android.app.Activity;
import com.gpc.operations.base.CompatProxyManager;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.bridge.GPCBridgeDispatcher;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientInitializeListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientQueryPurchasesListener;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionHandleType;
import com.gpc.tsh.pay.flow.processing.PaymentTransactionStateListener;
import com.gpc.tsh.pay.service.PaymentDeliveryState;
import java.util.Iterator;
import java.util.List;

/* compiled from: PaymentTransactionsCommitter */
public class HHHTHHHHHTt implements PaymentClientInitializeListener, PaymentTransactionStateListener {

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public static final String f108HHHTHHHHHtt = "PaymentTransactionsCommitter";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public PaymentType f109HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public HHHHTHHHHHHt f110HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public String f111HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public HHHTHHHHHt f112HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public String f113HHHTHHHHHtT;

    public HHHTHHHHHTt() {
        Activity activity = GPCBridgeDispatcher.sharedInstance().getActivity();
        if (activity != null) {
            this.f111HHHTHHHHHt = CompatProxyManager.sharedInstance().getProxy().getGameId();
            this.f113HHHTHHHHHtT = CompatProxyManager.sharedInstance().getProxy().getUserId();
            PaymentType paymentType = PaymentType.GOOGLE_PLAY;
            this.f109HHHHTHHHHHHt = paymentType;
            this.f110HHHTHHHHHTt = new HHHHTHHHHHHt(activity, paymentType);
            HHHTHHHHHt hHHTHHHHHt = new HHHTHHHHHt(activity, this.f109HHHHTHHHHHHt, this.f111HHHTHHHHHt, this.f113HHHTHHHHHtT);
            this.f112HHHTHHHHHtH = hHHTHHHHHt;
            hHHTHHHHHt.HHHHTHHHHHHt((PaymentTransactionStateListener) this);
        }
    }

    public void HHHHTHHHHHHt() {
        if (this.f110HHHTHHHHHTt != null) {
            LogUtils.d(f108HHHTHHHHHtt, "PaymentTransactionsCommitter commitAfterQuery");
            this.f110HHHTHHHHHTt.init(this);
        }
    }

    public void HHHTHHHHHTt() {
        LogUtils.d(f108HHHTHHHHHtt, "PaymentTransactionsCommitter destroy");
        if (this.f110HHHTHHHHHTt != null) {
            LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter paymentClient destroy");
            this.f110HHHTHHHHHTt.destroy();
        }
        if (this.f112HHHTHHHHHtH != null) {
            LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter processor destroy");
            this.f112HHHTHHHHHtH.HHHHTHHHHHHt();
        }
    }

    public void onCommitGatewayFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onCommitGatewayFail :" + paymentTransactionHandleType + " " + gPCPaymentClientPurchase);
    }

    public void onCommitGatewaySuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentDeliveryState paymentDeliveryState) {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onCommitGatewaySuccess");
    }

    public void onConsumeFail(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onConsumeFail");
    }

    public void onConsumeSuccess(PaymentTransactionHandleType paymentTransactionHandleType, GPCPaymentClientPurchase gPCPaymentClientPurchase) {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onConsumeSuccess");
    }

    public void onInitialized(GPCException gPCException) {
        LogUtils.d(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onInitialized startSetup finish");
        if (gPCException.isNone()) {
            LogUtils.d(f108HHHTHHHHHtt, "PaymentTransactionsCommitter startSetup Success e.isNone()");
            HHHHTHHHHHHt hHHHTHHHHHHt = this.f110HHHTHHHHHTt;
            if (hHHHTHHHHHHt != null) {
                hHHHTHHHHHHt.queryPurchases(new PaymentClientQueryPurchasesListener() {
                    public final void onQueryPurchasesFinished(GPCException gPCException, List list) {
                        HHHTHHHHHTt.this.HHHHTHHHHHHt(gPCException, list);
                    }
                });
                return;
            }
            return;
        }
        LogUtils.d(f108HHHTHHHHHtt, "PaymentTransactionsCommitter startSetup Success e.isOccurred():" + gPCException.getCode());
    }

    public void onReceivedQueryInventoryTaskInterval(int i) {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onReceivedQueryInventoryTaskInterval :" + i);
    }

    public void onSubItemHasCommited() {
        LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter onSubItemHasCommited");
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void HHHHTHHHHHHt(GPCException gPCException, List list) {
        LogUtils.d(f108HHHTHHHHHtt, "paymentClient.queryPurchases ===================");
        if (list != null && list.size() > 0) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                GPCPaymentClientPurchase gPCPaymentClientPurchase = (GPCPaymentClientPurchase) it.next();
                LogUtils.i(f108HHHTHHHHHtt, "PaymentTransactionsCommitter item:" + gPCPaymentClientPurchase);
                List<String> HHHHTHHHHHHt2 = HHHTHHHHTTt.HHHHTHHHHHHt.HHHHTHHHHHHt();
                if (HHHHTHHHHHHt2 != null && HHHHTHHHHHHt2.contains(gPCPaymentClientPurchase.getSku())) {
                    this.f112HHHTHHHHHtH.HHHTHHHHHTt(gPCPaymentClientPurchase);
                }
            }
        }
    }
}
