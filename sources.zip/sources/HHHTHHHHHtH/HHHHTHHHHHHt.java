package HHHTHHHHHtH;

import com.gpc.operations.migrate.service.helper.HttpReponseCacher;
import com.gpc.operations.migrate.service.network.http.HTTPInterceptor;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponse;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponseLowerCaseHeaders;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponseStringBody;
import com.gpc.operations.migrate.utils.Log;
import com.gpc.operations.migrate.utils.modules.ModulesManager;

/* compiled from: Abstract304CacheInterceptor */
public abstract class HHHHTHHHHHHt implements HTTPInterceptor {
    private static final String TAG = "Abstract304CacheInterceptor";
    public HttpReponseCacher cacher;

    public HHHHTHHHHHHt() {
        String httpResponsCachePath = ModulesManager.pathModule().getHttpResponsCachePath();
        Log.d(TAG, "cachePath:" + httpResponsCachePath);
        this.cacher = new HttpReponseCacher(httpResponsCachePath);
    }

    public abstract String getEtagKey();

    public void interceptHttpNotModified(HTTPResponse hTTPResponse, String str) {
        long currentTimeMillis = System.currentTimeMillis();
        HTTPResponseStringBody hTTPResponseStringBody = new HTTPResponseStringBody();
        String readResponseFromCache = this.cacher.readResponseFromCache(str);
        String readResponseTypeFromCache = this.cacher.readResponseTypeFromCache(str);
        hTTPResponseStringBody.setBodyString(readResponseFromCache);
        hTTPResponseStringBody.setContentType(readResponseTypeFromCache);
        Log.d(TAG, "Get data type from cache:" + readResponseTypeFromCache);
        Log.d(TAG, "Get data from cache:" + readResponseFromCache);
        hTTPResponse.setBody(hTTPResponseStringBody);
        Log.d(TAG, "recovery data from cache elapsed time (ms):" + (System.currentTimeMillis() - currentTimeMillis));
    }

    public void interceptHttpOk(HTTPResponse hTTPResponse, String str) {
        String headerWithLowerCaseKey = new HTTPResponseLowerCaseHeaders(hTTPResponse.getHeaders()).getHeaderWithLowerCaseKey(getEtagKey());
        String string = hTTPResponse.getBody().getString();
        String contentType = hTTPResponse.getBody().getContentType();
        if (str == null || "".equals(str)) {
            Log.w(TAG, "URL is null, ignore cache.");
        } else if (headerWithLowerCaseKey == null || "".equals(headerWithLowerCaseKey)) {
            Log.i(TAG, "response didn`t contain eTag, ignore cache.");
        } else if (string == null || "".equals(string)) {
            Log.w(TAG, "response data is null, ignore cache.");
        } else {
            long currentTimeMillis = System.currentTimeMillis();
            this.cacher.cacheHttpResponse(str, headerWithLowerCaseKey, string, contentType);
            Log.d(TAG, "cache response elapsed time (ms):" + (System.currentTimeMillis() - currentTimeMillis));
        }
    }

    public int priority() {
        return 0;
    }
}
