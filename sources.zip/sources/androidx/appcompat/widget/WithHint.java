package androidx.appcompat.widget;

public interface WithHint {
    CharSequence getHint();
}
