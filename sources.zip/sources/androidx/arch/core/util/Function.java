package androidx.arch.core.util;

public interface Function<I, O> {
    O apply(I i);
}
