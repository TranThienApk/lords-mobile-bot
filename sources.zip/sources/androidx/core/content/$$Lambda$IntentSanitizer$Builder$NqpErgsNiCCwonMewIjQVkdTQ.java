package androidx.core.content;

import android.net.Uri;
import androidx.core.content.IntentSanitizer;
import androidx.core.util.Predicate;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$Builder$NqpErgsN-iCCwonMew-IjQVkdTQ  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$Builder$NqpErgsNiCCwonMewIjQVkdTQ implements Predicate {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$Builder$NqpErgsNiCCwonMewIjQVkdTQ INSTANCE = new $$Lambda$IntentSanitizer$Builder$NqpErgsNiCCwonMewIjQVkdTQ();

    private /* synthetic */ $$Lambda$IntentSanitizer$Builder$NqpErgsNiCCwonMewIjQVkdTQ() {
    }

    public /* synthetic */ Predicate and(Predicate predicate) {
        return Predicate.CC.$default$and(this, predicate);
    }

    public /* synthetic */ Predicate negate() {
        return Predicate.CC.$default$negate(this);
    }

    public /* synthetic */ Predicate or(Predicate predicate) {
        return Predicate.CC.$default$or(this, predicate);
    }

    public final boolean test(Object obj) {
        return IntentSanitizer.Builder.lambda$new$1((Uri) obj);
    }
}
