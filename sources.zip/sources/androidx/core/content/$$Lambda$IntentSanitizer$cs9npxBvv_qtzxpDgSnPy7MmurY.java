package androidx.core.content;

import androidx.core.util.Consumer;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$cs9npxBvv_qtzxpDgSnPy7MmurY  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$cs9npxBvv_qtzxpDgSnPy7MmurY implements Consumer {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$cs9npxBvv_qtzxpDgSnPy7MmurY INSTANCE = new $$Lambda$IntentSanitizer$cs9npxBvv_qtzxpDgSnPy7MmurY();

    private /* synthetic */ $$Lambda$IntentSanitizer$cs9npxBvv_qtzxpDgSnPy7MmurY() {
    }

    public final void accept(Object obj) {
        IntentSanitizer.lambda$sanitizeByFiltering$0((String) obj);
    }
}
