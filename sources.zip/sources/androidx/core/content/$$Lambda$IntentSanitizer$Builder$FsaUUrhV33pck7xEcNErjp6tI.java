package androidx.core.content;

import android.content.ComponentName;
import androidx.core.content.IntentSanitizer;
import androidx.core.util.Predicate;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$Builder$FsaUUrhV33pck7xEcNErjp6-t-I  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$Builder$FsaUUrhV33pck7xEcNErjp6tI implements Predicate {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$Builder$FsaUUrhV33pck7xEcNErjp6tI INSTANCE = new $$Lambda$IntentSanitizer$Builder$FsaUUrhV33pck7xEcNErjp6tI();

    private /* synthetic */ $$Lambda$IntentSanitizer$Builder$FsaUUrhV33pck7xEcNErjp6tI() {
    }

    public /* synthetic */ Predicate and(Predicate predicate) {
        return Predicate.CC.$default$and(this, predicate);
    }

    public /* synthetic */ Predicate negate() {
        return Predicate.CC.$default$negate(this);
    }

    public /* synthetic */ Predicate or(Predicate predicate) {
        return Predicate.CC.$default$or(this, predicate);
    }

    public final boolean test(Object obj) {
        return IntentSanitizer.Builder.lambda$allowAnyComponent$10((ComponentName) obj);
    }
}
