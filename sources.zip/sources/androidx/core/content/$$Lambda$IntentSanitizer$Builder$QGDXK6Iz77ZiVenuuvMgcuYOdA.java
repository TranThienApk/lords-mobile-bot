package androidx.core.content;

import androidx.core.content.IntentSanitizer;
import androidx.core.util.Predicate;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$Builder$QGDXK6Iz77ZiVenuuvMgc-uYOdA  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$Builder$QGDXK6Iz77ZiVenuuvMgcuYOdA implements Predicate {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$Builder$QGDXK6Iz77ZiVenuuvMgcuYOdA INSTANCE = new $$Lambda$IntentSanitizer$Builder$QGDXK6Iz77ZiVenuuvMgcuYOdA();

    private /* synthetic */ $$Lambda$IntentSanitizer$Builder$QGDXK6Iz77ZiVenuuvMgcuYOdA() {
    }

    public /* synthetic */ Predicate and(Predicate predicate) {
        return Predicate.CC.$default$and(this, predicate);
    }

    public /* synthetic */ Predicate negate() {
        return Predicate.CC.$default$negate(this);
    }

    public /* synthetic */ Predicate or(Predicate predicate) {
        return Predicate.CC.$default$or(this, predicate);
    }

    public final boolean test(Object obj) {
        return IntentSanitizer.Builder.lambda$new$3((String) obj);
    }
}
