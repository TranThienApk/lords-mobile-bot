package androidx.core.content;

import androidx.core.util.Consumer;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$NofwxHOZrEEV1MRTpUn9ROuxIY8  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$NofwxHOZrEEV1MRTpUn9ROuxIY8 implements Consumer {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$NofwxHOZrEEV1MRTpUn9ROuxIY8 INSTANCE = new $$Lambda$IntentSanitizer$NofwxHOZrEEV1MRTpUn9ROuxIY8();

    private /* synthetic */ $$Lambda$IntentSanitizer$NofwxHOZrEEV1MRTpUn9ROuxIY8() {
    }

    public final void accept(Object obj) {
        IntentSanitizer.lambda$sanitizeByThrowing$1((String) obj);
    }
}
