package androidx.core.content;

import android.content.UriMatcher;
import android.net.Uri;
import androidx.core.util.Predicate;

public class UriMatcherCompat {
    private UriMatcherCompat() {
    }

    public static Predicate<Uri> asPredicate(UriMatcher uriMatcher) {
        return new Predicate(uriMatcher) {
            public final /* synthetic */ UriMatcher f$0;

            {
                this.f$0 = r1;
            }

            public /* synthetic */ Predicate and(Predicate predicate) {
                return Predicate.CC.$default$and(this, predicate);
            }

            public /* synthetic */ Predicate negate() {
                return Predicate.CC.$default$negate(this);
            }

            public /* synthetic */ Predicate or(Predicate predicate) {
                return Predicate.CC.$default$or(this, predicate);
            }

            public final boolean test(Object obj) {
                return UriMatcherCompat.lambda$asPredicate$0(this.f$0, (Uri) obj);
            }
        };
    }

    static /* synthetic */ boolean lambda$asPredicate$0(UriMatcher uriMatcher, Uri uri) {
        return uriMatcher.match(uri) != -1;
    }
}
