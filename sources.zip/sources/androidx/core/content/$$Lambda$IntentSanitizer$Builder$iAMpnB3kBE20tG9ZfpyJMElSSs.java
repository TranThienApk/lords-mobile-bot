package androidx.core.content;

import android.content.ComponentName;
import androidx.core.content.IntentSanitizer;
import androidx.core.util.Predicate;

/* renamed from: androidx.core.content.-$$Lambda$IntentSanitizer$Builder$iAMpnB3kBE20tG9-ZfpyJMElSSs  reason: invalid class name */
/* compiled from: lambda */
public final /* synthetic */ class $$Lambda$IntentSanitizer$Builder$iAMpnB3kBE20tG9ZfpyJMElSSs implements Predicate {
    public static final /* synthetic */ $$Lambda$IntentSanitizer$Builder$iAMpnB3kBE20tG9ZfpyJMElSSs INSTANCE = new $$Lambda$IntentSanitizer$Builder$iAMpnB3kBE20tG9ZfpyJMElSSs();

    private /* synthetic */ $$Lambda$IntentSanitizer$Builder$iAMpnB3kBE20tG9ZfpyJMElSSs() {
    }

    public /* synthetic */ Predicate and(Predicate predicate) {
        return Predicate.CC.$default$and(this, predicate);
    }

    public /* synthetic */ Predicate negate() {
        return Predicate.CC.$default$negate(this);
    }

    public /* synthetic */ Predicate or(Predicate predicate) {
        return Predicate.CC.$default$or(this, predicate);
    }

    public final boolean test(Object obj) {
        return IntentSanitizer.Builder.lambda$new$5((ComponentName) obj);
    }
}
