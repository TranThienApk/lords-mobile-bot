package HHHTHHHHTtH;

import android.app.Activity;
import android.content.Intent;
import com.gpc.tsh.pay.bean.GPCPaymentClientPurchase;
import com.gpc.tsh.pay.bean.PaymentType;
import com.gpc.tsh.pay.flow.client.IGPCPaymentClient;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientAcknowledgePurchaseListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientConsumePurchaseListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientInitializeListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientPurchasedListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientQueryPurchasesListener;
import com.gpc.tsh.pay.flow.client.listener.PaymentClientQuerySkuDetailsResponseListener;
import java.util.List;

/* compiled from: PaymentClientProxy */
public class HHHHTHHHHHHt implements IGPCPaymentClient {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public IGPCPaymentClient f152HHHHTHHHHHHt;

    public HHHHTHHHHHHt(Activity activity, PaymentType paymentType) {
        this.f152HHHHTHHHHHHt = new HHHTHHHHTt.HHHHTHHHHHHt(activity);
    }

    public IGPCPaymentClient HHHHTHHHHHHt() {
        return this.f152HHHHTHHHHHHt;
    }

    public void acknowledgePurchase(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentClientAcknowledgePurchaseListener paymentClientAcknowledgePurchaseListener) {
        this.f152HHHHTHHHHHHt.acknowledgePurchase(gPCPaymentClientPurchase, str, paymentClientAcknowledgePurchaseListener);
    }

    public void consume(GPCPaymentClientPurchase gPCPaymentClientPurchase, String str, PaymentClientConsumePurchaseListener paymentClientConsumePurchaseListener) {
        this.f152HHHHTHHHHHHt.consume(gPCPaymentClientPurchase, str, paymentClientConsumePurchaseListener);
    }

    public void destroy() {
        this.f152HHHHTHHHHHHt.destroy();
    }

    public void init(PaymentClientInitializeListener paymentClientInitializeListener) {
        this.f152HHHHTHHHHHHt.init(paymentClientInitializeListener);
    }

    public boolean isAvailable(String str, boolean z) {
        return this.f152HHHHTHHHHHHt.isAvailable(str, z);
    }

    public boolean onActivityResult(int i, int i2, Intent intent) {
        return this.f152HHHHTHHHHHHt.onActivityResult(i, i2, intent);
    }

    public void purchaseFlow(String str, String str2, String str3, String str4, PaymentClientPurchasedListener paymentClientPurchasedListener) {
        this.f152HHHHTHHHHHHt.purchaseFlow(str, str2, str3, str4, paymentClientPurchasedListener);
    }

    public void queryPurchases(PaymentClientQueryPurchasesListener paymentClientQueryPurchasesListener) {
        this.f152HHHHTHHHHHHt.queryPurchases(paymentClientQueryPurchasesListener);
    }

    public void querySkuDetails(List<String> list, List<String> list2, PaymentClientQuerySkuDetailsResponseListener paymentClientQuerySkuDetailsResponseListener) {
        this.f152HHHHTHHHHHHt.querySkuDetails(list, list2, paymentClientQuerySkuDetailsResponseListener);
    }
}
