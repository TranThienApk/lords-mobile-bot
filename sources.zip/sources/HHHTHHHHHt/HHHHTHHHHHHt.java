package HHHTHHHHHt;

import com.gpc.operations.migrate.error.GPCException;
import org.json.JSONObject;

/* compiled from: IRequestListener */
public interface HHHHTHHHHHHt {
    void HHHHTHHHHHHt(GPCException gPCException, JSONObject jSONObject, String str);
}
