package HHHHTHHHHHHt;

import android.content.Context;
import com.gpc.operations.helper.GeneralResponse;
import com.gpc.operations.migrate.service.helper.APIGateway_API;
import com.gpc.operations.migrate.service.network.http.HTTPException;
import com.gpc.operations.migrate.service.network.http.request.HTTPRequest;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponse;
import com.gpc.operations.migrate.service.request.api.HTTPServiceCallback;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.service.BaseService;
import com.gpc.operations.service.IMessageStateManager;
import com.gpc.operations.service.OnUpdateResultCallback;
import com.gpc.operations.utils.ExcutorUtils;
import com.gpc.operations.utils.LogUtils;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONObject;

/* compiled from: GameCommunityService */
public class HHHHTHHHHHHt extends BaseService implements IMessageStateManager<Integer> {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f7HHHHTHHHHHHt = "GameCommunityService";

    /* renamed from: HHHHTHHHHHHt.HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
    /* compiled from: GameCommunityService */
    public class C0000HHHHTHHHHHHt implements Runnable {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ String f8HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ String f9HHHTHHHHHTt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ OnUpdateResultCallback f11HHHTHHHHHtH;

        /* renamed from: HHHHTHHHHHHt.HHHHTHHHHHHt$HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
        /* compiled from: GameCommunityService */
        public class C0001HHHHTHHHHHHt implements HTTPServiceCallback {
            public C0001HHHHTHHHHHHt() {
            }

            public void onConnectionError(HTTPRequest hTTPRequest, HTTPException hTTPException) {
                OnUpdateResultCallback onUpdateResultCallback = C0000HHHHTHHHHHHt.this.f11HHHTHHHHHtH;
                if (onUpdateResultCallback != null) {
                    onUpdateResultCallback.onResult(-1);
                }
            }

            public void onResponse(HTTPRequest hTTPRequest, HTTPResponse hTTPResponse) {
                LogUtils.d(HHHHTHHHHHHt.f7HHHHTHHHHHHt, "onResponse");
                LogUtils.d(HHHHTHHHHHHt.f7HHHHTHHHHHHt, "response:" + hTTPResponse);
                try {
                    GeneralResponse generator = GeneralResponse.generator(hTTPResponse.getBody().getString());
                    if (generator.isSuccess()) {
                        JSONObject jSONObject = new JSONObject(generator.getData());
                        if (jSONObject.isNull("new")) {
                            OnUpdateResultCallback onUpdateResultCallback = C0000HHHHTHHHHHHt.this.f11HHHTHHHHHtH;
                            if (onUpdateResultCallback != null) {
                                onUpdateResultCallback.onResult(-1);
                                return;
                            }
                            return;
                        }
                        LogUtils.d(HHHHTHHHHHHt.f7HHHHTHHHHHHt, "data parse success");
                        OnUpdateResultCallback onUpdateResultCallback2 = C0000HHHHTHHHHHHt.this.f11HHHTHHHHHtH;
                        if (onUpdateResultCallback2 != null) {
                            onUpdateResultCallback2.onResult(Integer.valueOf(jSONObject.getInt("new")));
                            return;
                        }
                        return;
                    }
                    LogUtils.e(HHHHTHHHHHHt.f7HHHHTHHHHHHt, "response data: Parse failure.");
                    OnUpdateResultCallback onUpdateResultCallback3 = C0000HHHHTHHHHHHt.this.f11HHHTHHHHHtH;
                    if (onUpdateResultCallback3 != null) {
                        onUpdateResultCallback3.onResult(null);
                    }
                } catch (Exception e) {
                    LogUtils.e(HHHHTHHHHHHt.f7HHHHTHHHHHHt, "", e);
                    OnUpdateResultCallback onUpdateResultCallback4 = C0000HHHHTHHHHHHt.this.f11HHHTHHHHHtH;
                    if (onUpdateResultCallback4 != null) {
                        onUpdateResultCallback4.onResult(null);
                    }
                }
            }
        }

        public C0000HHHHTHHHHHHt(String str, String str2, OnUpdateResultCallback onUpdateResultCallback) {
            this.f8HHHHTHHHHHHt = str;
            this.f9HHHTHHHHHTt = str2;
            this.f11HHHTHHHHHtH = onUpdateResultCallback;
        }

        public void run() {
            new HashMap();
            HashMap hashMap = new HashMap();
            hashMap.put("game_id", this.f8HHHHTHHHHHHt);
            hashMap.put("sso_token", this.f9HHHTHHHHHTt);
            ModulesManager.serviceFactory().getHTTPService().get(APIGateway_API.GAME_COMMUNITY_UNREAD_MESSAGE, hashMap, (Map<String, String>) null, new C0001HHHHTHHHHHHt());
        }
    }

    public HHHHTHHHHHHt(Context context) {
        super(context);
    }

    public void update(String str, String str2, String str3, OnUpdateResultCallback<Integer> onUpdateResultCallback) {
        LogUtils.d(f7HHHHTHHHHHHt, "update:" + str);
        ExcutorUtils.execute(new C0000HHHHTHHHHHHt(str, str3, onUpdateResultCallback));
    }
}
