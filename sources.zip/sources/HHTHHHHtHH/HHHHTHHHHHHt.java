package HHTHHHHtHH;

import com.gpc.tsh.pay.bean.GPCGameItem;
import java.util.List;

/* compiled from: GameItemAndUserLimit */
public class HHHHTHHHHHHt {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public List<GPCGameItem> f218HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public List<GPCGameItem> f219HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public int f220HHHTHHHHHtH;

    public HHHHTHHHHHHt(List<GPCGameItem> list, List<GPCGameItem> list2, int i) {
        this.f218HHHHTHHHHHHt = list;
        this.f219HHHTHHHHHTt = list2;
        this.f220HHHTHHHHHtH = i;
    }

    public List<GPCGameItem> HHHHTHHHHHHt() {
        return this.f219HHHTHHHHHTt;
    }

    public List<GPCGameItem> HHHTHHHHHTt() {
        return this.f218HHHHTHHHHHHt;
    }

    public int HHHTHHHHHtH() {
        return this.f220HHHTHHHHHtH;
    }
}
