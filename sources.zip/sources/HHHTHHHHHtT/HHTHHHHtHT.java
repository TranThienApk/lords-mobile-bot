package HHHTHHHHHtt;

import android.app.Application;
import com.gpc.operations.notification.NotificationConfig;
import com.gpc.tsh.bean.TSHybridAppearance;

/* compiled from: TSHNotification */
public interface HHTHHHHtHT {
    void HHHHTHHHHHHt(Application application, NotificationConfig notificationConfig, TSHybridAppearance tSHybridAppearance);
}
