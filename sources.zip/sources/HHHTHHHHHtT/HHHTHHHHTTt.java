package HHHTHHHHHtT;

import com.gpc.photoselector.model.PhotoModel;
import com.gpc.resourcestorage.OPSResourceUploader;
import java.util.ArrayList;
import java.util.List;

/* compiled from: OPSResourceBaseUploader */
public abstract class HHHTHHHHTTt implements OPSResourceUploader {
    public abstract ArrayList<PhotoModel> HHHHTHHHHHHt(List<PhotoModel> list);

    public abstract void HHHHTHHHHHHt();

    public abstract void HHHHTHHHHHHt(ArrayList<PhotoModel> arrayList);
}
