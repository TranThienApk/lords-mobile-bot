package HHHTHHHHHtt;

import android.content.Context;
import com.gpc.operations.migrate.Configuration;
import com.gpc.operations.migrate.utils.modules.Module;

/* compiled from: TSHSingleTaskModule */
public class HHTHHHHtT implements Module {
    public void onAsyncInit() {
    }

    public void onDestroy() {
        HHTHHHHtTH.HHHTHHHHHtt();
    }

    public void onGameIdChange(String str, String str2) {
    }

    public void onIGXIdChange(String str, String str2) {
    }

    public void onInitFinish() {
    }

    public void onPreInit(Context context, Configuration configuration) {
        HHTHHHHtTH.HHHTHHHHHtt();
    }

    public void onSessionIdChange(String str, String str2) {
    }
}
