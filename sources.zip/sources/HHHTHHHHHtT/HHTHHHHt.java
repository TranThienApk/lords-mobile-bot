package HHHTHHHHHtt;

import com.gpc.operations.notification.NotificationConfig;

/* compiled from: TSHNotificationConfig */
public class HHTHHHHt extends NotificationConfig {
}
