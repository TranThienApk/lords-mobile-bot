package HHHTHHHHHtT;

import android.text.TextUtils;
import com.gpc.operations.database.IDataBase;
import com.gpc.operations.database.dao.bean.DBResource;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.service.network.http.request.HTTPRequestHeadersDelegate;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponseHeaders;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponseLowerCaseHeaders;
import com.gpc.operations.migrate.service.request.general.ILegacyServiceClient;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.utils.Constant;
import com.gpc.operations.utils.LogUtils;
import com.gpc.resourcestorage.OPSImageSizeType;
import com.gpc.resourcestorage.OPSResource;
import com.gpc.resourcestorage.OPSResourceDownloader;
import com.gpc.resourcestorage.OPSResourceTask;
import com.gpc.resourcestorage.bean.OPSResourcePack;
import com.gpc.resourcestorage.bean.OPSResourceStatus;
import com.gpc.resourcestorage.bean.OPSUploadType;
import com.gpc.resourcestorage.listener.ResourceDownloadHadCacheExListener;
import com.gpc.resourcestorage.listener.ResourceDownloadListener;
import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/* compiled from: ResourceDownloadHelper */
public class HHHTHHHHTt implements OPSResourceDownloader {

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public static final String f37HHHTHHHHTt = "x-amz-meta-resource-status";

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public static final String f38HHHTHHHHTtH = "ResourceDownloadHelper";

    /* renamed from: HHHTHHHHTtT  reason: collision with root package name */
    public static final String f39HHHTHHHHTtT = "x-amz-meta-resource-id";

    /* renamed from: HHTHHHHTtt  reason: collision with root package name */
    public static final String f40HHTHHHHTtt = "cache-control";
    public static final String HHTHHHHtH = "statics-global";

    /* renamed from: HHTHHHHtHH  reason: collision with root package name */
    public static final String f41HHTHHHHtHH = "max-age";
    public static final String HHTHHHHtHT = "statics01-global";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public ILegacyServiceClient f42HHHHTHHHHHHt = ModulesManager.serviceFactory().getStaticsService(HHTHHHHtH);

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public ILegacyServiceClient f43HHHTHHHHHTt = ModulesManager.serviceFactory().getStaticsService(HHTHHHHtHT);

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public IDataBase<DBResource> f44HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public OPSResourcePack f45HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public OPSImageSizeType f46HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public String f47HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public String f48HHHTHHHHTHt = ModulesManager.pathModule().getResourceStorageMediaPath();

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public ResourceDownloadHadCacheExListener f49HHHTHHHHTTt;

    /* compiled from: ResourceDownloadHelper */
    public class HHHHTHHHHHHt implements ResourceDownloadHadCacheExListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ ResourceDownloadListener f50HHHHTHHHHHHt;

        public HHHHTHHHHHHt(ResourceDownloadListener resourceDownloadListener) {
            this.f50HHHHTHHHHHHt = resourceDownloadListener;
        }

        public void onDownloadHadCache(OPSResourceTask oPSResourceTask, OPSResource oPSResource) {
            LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "onDownloadHadCache");
        }

        public void onFailure(OPSResourceTask oPSResourceTask, GPCException gPCException) {
            ResourceDownloadListener resourceDownloadListener = this.f50HHHHTHHHHHHt;
            if (resourceDownloadListener != null) {
                resourceDownloadListener.onFailure(oPSResourceTask, gPCException);
            }
        }

        public void onProgress(OPSResourceTask oPSResourceTask) {
            ResourceDownloadListener resourceDownloadListener = this.f50HHHHTHHHHHHt;
            if (resourceDownloadListener != null) {
                resourceDownloadListener.onProgress(oPSResourceTask);
            }
        }

        public void onSuccess(OPSResourceTask oPSResourceTask, OPSResource oPSResource) {
            ResourceDownloadListener resourceDownloadListener = this.f50HHHHTHHHHHHt;
            if (resourceDownloadListener != null) {
                resourceDownloadListener.onSuccess(oPSResourceTask, oPSResource);
            }
        }
    }

    /* compiled from: ResourceDownloadHelper */
    public class HHHTHHHHHTt implements ILegacyServiceClient.HeadersRequestListener {
        public HHHTHHHHHTt() {
        }

        public void onHeadersRequestFinished(GPCException gPCException, HTTPResponseLowerCaseHeaders hTTPResponseLowerCaseHeaders, String str) {
            LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "fileHeadRequest responseString " + str);
            if (gPCException.isOccurred()) {
                try {
                    HHHTHHHHTt.this.f49HHHTHHHHTTt.onFailure(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), GPCException.exception(Constant.ResourceStorage.RESOURCE_DOWNLOAD_FAILED_REMOTE_ERROR, (String) null, (String) null, gPCException));
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e);
                }
            } else if (hTTPResponseLowerCaseHeaders == null || hTTPResponseLowerCaseHeaders.getHeaders().isEmpty()) {
                try {
                    HHHTHHHHTt.this.f49HHHTHHHHTTt.onFailure(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), GPCException.exception(Constant.ResourceStorage.RESOURCE_DOWNLOAD_FAILED_SERVER_DATA_ILLEGAL, (String) null, (String) null, gPCException));
                } catch (Exception e2) {
                    LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e2);
                }
            } else {
                Map<String, String> headers = hTTPResponseLowerCaseHeaders.getHeaders();
                String str2 = headers.get(HHHTHHHHTt.f37HHHTHHHHTt);
                String str3 = headers.get(HHHTHHHHTt.f39HHHTHHHHTtT);
                if (TextUtils.isEmpty(str2) || TextUtils.isEmpty(str3)) {
                    LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "resource status or id is null ");
                    try {
                        HHHTHHHHTt.this.f49HHHTHHHHTTt.onFailure(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), GPCException.exception(Constant.ResourceStorage.RESOURCE_DOWNLOAD_FAILED_REMOTE_ERROR, (String) null, (String) null, gPCException));
                    } catch (Exception e3) {
                        LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e3);
                    }
                } else {
                    LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "download responseHeaders resourceStatus:" + str2);
                    HHHTHHHHTt.this.f45HHHTHHHHHtH.setStatus(str2);
                    HHHTHHHHTt.this.f45HHHTHHHHHtH.setMaxAge(HHHTHHHHTt.this.HHHHTHHHHHHt(headers));
                    HHHTHHHHTt.this.HHHTHHHHHtt();
                    if (OPSResourceStatus.Success.equals(HHHTHHHHTt.this.f45HHHTHHHHHtH.getStatus()) || OPSResourceStatus.UnderReview.equals(HHHTHHHHTt.this.f45HHHTHHHHHtH.getStatus())) {
                        HHHTHHHHTt.this.f45HHHTHHHHHtH.setResourceId(str3);
                        HHHTHHHHTt.this.HHHTHHHHHtH();
                        return;
                    }
                    LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "resource status not pass,game should judge status");
                    try {
                        HHHTHHHHTt.this.f49HHHTHHHHTTt.onSuccess(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResource());
                    } catch (Exception e4) {
                        LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e4);
                    }
                }
            }
        }
    }

    /* compiled from: ResourceDownloadHelper */
    public class HHHTHHHHHt implements ILegacyServiceClient.DownloadRequestListener {
        public HHHTHHHHHt() {
        }

        public void onDownloadProgress(float f) {
            HHHTHHHHTt.this.f45HHHTHHHHHtH.setProgress(f);
            if (HHHTHHHHTt.this.f49HHHTHHHHTTt != null) {
                try {
                    HHHTHHHHTt.this.f49HHHTHHHHTTt.onProgress(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask());
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e);
                }
            }
        }

        public void onDownloadRequestFinished(GPCException gPCException, String str, File file, HTTPResponseHeaders hTTPResponseHeaders) {
            LogUtils.d(HHHTHHHHTt.f38HHHTHHHHTtH, "download responseString:" + str);
            if ("success".equals(str)) {
                HHHTHHHHTt.this.f45HHHTHHHHHtH.setLocalPath(file.getPath());
                HHHTHHHHTt.this.HHHTHHHHHtt();
                try {
                    HHHTHHHHTt.this.f49HHHTHHHHTTt.onSuccess(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResource());
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e);
                }
            } else {
                try {
                    HHHTHHHHTt.this.f49HHHTHHHHTTt.onFailure(HHHTHHHHTt.this.f45HHHTHHHHHtH.getOPSResourceTask(), GPCException.exception(Constant.ResourceStorage.RESOURCE_DOWNLOAD_FAILED_REMOTE_ERROR, (String) null, (String) null, gPCException));
                } catch (Exception e2) {
                    LogUtils.e(HHHTHHHHTt.f38HHHTHHHHTtH, "", e2);
                }
            }
        }
    }

    /* compiled from: ResourceDownloadHelper */
    public class HHHTHHHHHtH implements HTTPRequestHeadersDelegate {
        public HHHTHHHHHtH() {
        }

        public Map<String, String> getHeaders() {
            return null;
        }
    }

    public HHHTHHHHTt(IDataBase<DBResource> iDataBase) {
        this.f44HHHTHHHHHt = iDataBase;
    }

    public final boolean HHHTHHHHHtT() {
        DBResource query = this.f44HHHTHHHHHt.query(new DBResource(this.f45HHHTHHHHHtH));
        if (query == null) {
            return true;
        }
        OPSResourcePack oPSResource = query.getOPSResource();
        this.f45HHHTHHHHHtH = oPSResource;
        boolean z = oPSResource.isValidityPeriod() && !TextUtils.isEmpty(this.f45HHHTHHHHHtH.getLocalPath());
        if (z) {
            z = new File(this.f45HHHTHHHHHtH.getLocalPath()).exists();
            LogUtils.d(f38HHHTHHHHTtH, "file.exists(): " + z);
        }
        LogUtils.d(f38HHHTHHHHTtH, "isNeedRequest resource:" + this.f45HHHTHHHHHtH + " ;result: " + z);
        return !z;
    }

    public final void HHHTHHHHHtt() {
        IDataBase<DBResource> iDataBase = this.f44HHHTHHHHHt;
        if (iDataBase != null) {
            iDataBase.insert(new DBResource(this.f45HHHTHHHHHtH));
        }
    }

    public void setResourceDownloadListener(ResourceDownloadListener resourceDownloadListener) {
        this.f49HHHTHHHHTTt = new HHHHTHHHHHHt(resourceDownloadListener);
    }

    public void start(String str, String str2) {
        start(str, str2, OPSImageSizeType.OPSImageSizeOriginal);
    }

    public final void HHHTHHHHHTt() {
        this.f42HHHHTHHHHHHt.headRequest(this.f47HHHTHHHHHtt, (HashMap<String, String>) null, new HHHTHHHHHTt());
    }

    public final boolean HHHTHHHHHt() {
        LogUtils.i(f38HHHTHHHHTtH, "isNeedRequestEx");
        DBResource query = this.f44HHHTHHHHHt.query(new DBResource(this.f45HHHTHHHHHtH));
        if (query == null) {
            return false;
        }
        OPSResourcePack oPSResource = query.getOPSResource();
        this.f45HHHTHHHHHtH = oPSResource;
        boolean z = !TextUtils.isEmpty(oPSResource.getLocalPath());
        if (z) {
            z = new File(this.f45HHHTHHHHHtH.getLocalPath()).exists();
            LogUtils.d(f38HHHTHHHHTtH, "file.exists(): " + z);
        }
        LogUtils.d(f38HHHTHHHHTtH, "isNeedRequest resource:" + this.f45HHHTHHHHHtH + " ;result: " + z);
        return z;
    }

    public final void HHHTHHHHHtH() {
        DBResource query = this.f44HHHTHHHHHt.query(new DBResource(this.f45HHHTHHHHHtH));
        if (query != null) {
            OPSResourcePack oPSResource = query.getOPSResource();
            this.f45HHHTHHHHHtH.setUniqueIdentifier(oPSResource.getUniqueIdentifier());
            if (!TextUtils.isEmpty(oPSResource.getLocalPath())) {
                String localPath = oPSResource.getLocalPath();
                if (new File(localPath).exists()) {
                    LogUtils.d(f38HHHTHHHHTtH, "findOrDownLoad file.exists");
                    this.f45HHHTHHHHHtH.setProgress(100.0f);
                    this.f45HHHTHHHHHtH.setLocalPath(localPath);
                    try {
                        this.f49HHHTHHHHTTt.onSuccess(this.f45HHHTHHHHHtH.getOPSResourceTask(), this.f45HHHTHHHHHtH.getOPSResource());
                        return;
                    } catch (Exception e) {
                        LogUtils.e(f38HHHTHHHHTtH, "", e);
                        return;
                    }
                }
            }
        }
        HHHHTHHHHHHt();
    }

    public void setResourceDownloadListener(ResourceDownloadHadCacheExListener resourceDownloadHadCacheExListener) {
        this.f49HHHTHHHHTTt = resourceDownloadHadCacheExListener;
    }

    public void start(String str, String str2, OPSImageSizeType oPSImageSizeType) {
        LogUtils.d(f38HHHTHHHHTtH, "start downloadKey:" + str2);
        LogUtils.d(f38HHHTHHHHTtH, "start image size type:" + oPSImageSizeType);
        if (this.f49HHHTHHHHTTt == null) {
            LogUtils.e(f38HHHTHHHHTtH, "listener is null");
        } else if (TextUtils.isEmpty(str2)) {
            LogUtils.e(f38HHHTHHHHTtH, "downloadKey is null");
            try {
                this.f49HHHTHHHHTTt.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.RESOURCE_DOWNLOAD));
            } catch (Exception e) {
                LogUtils.e(f38HHHTHHHHTtH, "", e);
            }
        } else {
            this.f46HHHTHHHHHtT = oPSImageSizeType;
            OPSResourcePack oPSResourcePack = new OPSResourcePack();
            this.f45HHHTHHHHHtH = oPSResourcePack;
            oPSResourcePack.setFileKey(str2 + HHHHTHHHHHHt(oPSImageSizeType));
            this.f45HHHTHHHHHtH.setResourceId(str);
            this.f45HHHTHHHHHtH.setType(OPSUploadType.Image);
            String format = String.format(Locale.US, "%s?_v=%s", new Object[]{str2, System.currentTimeMillis() + ""});
            this.f47HHHTHHHHHtt = format;
            String str3 = File.separator;
            if (!format.startsWith(str3)) {
                this.f47HHHTHHHHHtt = str3 + this.f47HHHTHHHHHtt;
            }
            if (HHHTHHHHHt()) {
                LogUtils.i(f38HHHTHHHHTtH, "isCacheExist ResourceDownloadExListener");
                this.f49HHHTHHHHTTt.onDownloadHadCache(this.f45HHHTHHHHHtH.getOPSResourceTask(), this.f45HHHTHHHHHtH.getOPSResource());
            }
            if (HHHTHHHHHtT()) {
                HHHTHHHHHTt();
                return;
            }
            try {
                this.f45HHHTHHHHHtH.setProgress(100.0f);
                this.f49HHHTHHHHTTt.onSuccess(this.f45HHHTHHHHHtH.getOPSResourceTask(), this.f45HHHTHHHHHtH.getOPSResource());
            } catch (Exception e2) {
                LogUtils.e(f38HHHTHHHHTtH, "", e2);
            }
        }
    }

    public final String HHHHTHHHHHHt(OPSImageSizeType oPSImageSizeType) {
        if (oPSImageSizeType == OPSImageSizeType.OPSImageSizeSmall) {
            return "/-/small";
        }
        if (oPSImageSizeType == OPSImageSizeType.OPSImageSizeMedium) {
            return "/-/medium";
        }
        return oPSImageSizeType == OPSImageSizeType.OPSImageSizeLarge ? "/-/large" : "";
    }

    public final void HHHHTHHHHHHt() {
        ILegacyServiceClient iLegacyServiceClient;
        String replace = this.f45HHHTHHHHHtH.getFileKey().replace(HHHHTHHHHHHt(this.f46HHHTHHHHHtT), "");
        String substring = replace.substring(replace.lastIndexOf("/") + 1);
        LogUtils.d(f38HHHTHHHHTtH, "really downLoadImage fileName:" + substring);
        OPSImageSizeType oPSImageSizeType = this.f46HHHTHHHHHtT;
        if (oPSImageSizeType == OPSImageSizeType.OPSImageSizeSmall) {
            iLegacyServiceClient = this.f43HHHTHHHHHTt;
            substring = "small_" + substring;
            LogUtils.d(f38HHHTHHHHTtH, "OPSImageSizeSmall use service01");
        } else if (oPSImageSizeType == OPSImageSizeType.OPSImageSizeMedium) {
            iLegacyServiceClient = this.f43HHHTHHHHHTt;
            substring = "medium_" + substring;
            LogUtils.d(f38HHHTHHHHTtH, "OPSImageSizeMedium use service01");
        } else if (oPSImageSizeType == OPSImageSizeType.OPSImageSizeLarge) {
            iLegacyServiceClient = this.f43HHHTHHHHHTt;
            substring = "large_" + substring;
            LogUtils.d(f38HHHTHHHHTtH, "OPSImageSizeLarge use service01");
        } else {
            iLegacyServiceClient = this.f42HHHHTHHHHHHt;
            LogUtils.d(f38HHHTHHHHTtH, "downloadImage use service");
        }
        String str = substring;
        ILegacyServiceClient iLegacyServiceClient2 = iLegacyServiceClient;
        String fileKey = this.f45HHHTHHHHHtH.getFileKey();
        String str2 = File.separator;
        if (!fileKey.startsWith(str2)) {
            fileKey = str2 + fileKey;
        }
        iLegacyServiceClient2.downloadFileRequest(fileKey, (HashMap<String, String>) null, str, this.f48HHHTHHHHTHt, new HHHTHHHHHtH(), new HHHTHHHHHt());
    }

    public final String HHHHTHHHHHHt(Map<String, String> map) {
        String[] split;
        String str = map.get(f40HHTHHHHTtt);
        if (TextUtils.isEmpty(str) || (split = str.split("=")) == null || (split.length != 2 && !f41HHTHHHHtHH.equals(split[0]))) {
            return null;
        }
        String str2 = split[1];
        LogUtils.d(f38HHHTHHHHTtH, "getValidityPeriod maxAge= " + str2);
        return str2;
    }
}
