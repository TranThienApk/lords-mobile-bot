package HHHTHHHHHtT;

import android.content.Context;
import com.gpc.operations.migrate.utils.FileHelper;
import com.gpc.operations.migrate.utils.LocalStorage;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.utils.ExcutorUtils;
import com.gpc.operations.utils.LogUtils;
import java.io.File;
import java.util.List;

/* compiled from: OPSResourceCacheHelper */
public class HHHTHHHHTtH {

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public static final String f55HHHTHHHHHt = "OPSResourceCacheHelper";

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public static final String f56HHHTHHHHHtH = "OPSResourceCacheHelper";

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public static final int f57HHHTHHHHHtT = 1000;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public static final String f58HHHTHHHHHtt = "KEY_CACHE_SIZE";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public LocalStorage f59HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public String f60HHHTHHHHHTt = ModulesManager.pathModule().getResourceStorageMediaPath();

    /* compiled from: OPSResourceCacheHelper */
    public class HHHHTHHHHHHt implements Runnable {
        public HHHHTHHHHHHt() {
        }

        public void run() {
            List<File> listFileSortByModifyTime = FileHelper.listFileSortByModifyTime(HHHTHHHHTtH.this.f60HHHTHHHHHTt);
            LogUtils.i("OPSResourceCacheHelper", "cleanCache cacheFileList size = " + listFileSortByModifyTime.size());
            for (File next : listFileSortByModifyTime) {
                LogUtils.d("OPSResourceCacheHelper", "cleanCache delete file = " + next.getAbsolutePath());
                LogUtils.d("OPSResourceCacheHelper", "cleanCache last modified time = " + next.lastModified());
                if (next.exists()) {
                    next.delete();
                }
            }
        }
    }

    /* compiled from: OPSResourceCacheHelper */
    public class HHHTHHHHHTt implements Runnable {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ int f62HHHHTHHHHHHt;

        public HHHTHHHHHTt(int i) {
            this.f62HHHHTHHHHHHt = i;
        }

        public void run() {
            List<File> listFileSortByModifyTime = FileHelper.listFileSortByModifyTime(HHHTHHHHTtH.this.f60HHHTHHHHHTt);
            LogUtils.i("OPSResourceCacheHelper", "clean cacheFileList size = " + listFileSortByModifyTime.size());
            for (int i = 0; i < this.f62HHHHTHHHHHHt; i++) {
                File file = listFileSortByModifyTime.get(i);
                LogUtils.d("OPSResourceCacheHelper", "clean delete file = " + file.getAbsolutePath());
                LogUtils.d("OPSResourceCacheHelper", "clean last modified time = " + file.lastModified());
                if (file.exists()) {
                    file.delete();
                }
            }
        }
    }

    public HHHTHHHHTtH(Context context) {
        this.f59HHHHTHHHHHHt = new LocalStorage(context, "OPSResourceCacheHelper");
        HHHTHHHHHTt();
    }

    public final void HHHTHHHHHTt() {
        LogUtils.i("OPSResourceCacheHelper", "initClean");
        List<File> listFileSortByModifyTime = FileHelper.listFileSortByModifyTime(this.f60HHHTHHHHHTt);
        int intValue = this.f59HHHHTHHHHHHt.readInt(f58HHHTHHHHHtt, 1000).intValue();
        if (!listFileSortByModifyTime.isEmpty() && listFileSortByModifyTime.size() > intValue) {
            int size = listFileSortByModifyTime.size() - intValue;
            LogUtils.i("OPSResourceCacheHelper", "initClean deleteSize = " + size);
            HHHHTHHHHHHt(size);
        }
    }

    public void HHHHTHHHHHHt() {
        LogUtils.i("OPSResourceCacheHelper", "cleanCache");
        ExcutorUtils.execute(new HHHHTHHHHHHt());
    }

    public final void HHHHTHHHHHHt(int i) {
        LogUtils.i("OPSResourceCacheHelper", "cleanCache size = " + i);
        ExcutorUtils.execute(new HHHTHHHHHTt(i));
    }

    public void HHHTHHHHHTt(int i) {
        LogUtils.i("OPSResourceCacheHelper", "setCapacity size = " + i);
        if (i >= 0) {
            this.f59HHHHTHHHHHHt.writeInt(f58HHHTHHHHHtt, Integer.valueOf(i));
        }
    }
}
