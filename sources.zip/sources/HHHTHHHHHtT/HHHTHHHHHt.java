package HHHTHHHHHTt;

import android.content.Context;
import com.google.common.net.HttpHeaders;
import com.gpc.operations.migrate.service.helper.APIGateway_API;
import com.gpc.operations.migrate.service.network.http.HTTPException;
import com.gpc.operations.migrate.service.network.http.request.HTTPRequest;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponse;
import com.gpc.operations.migrate.service.request.api.HTTPServiceCallback;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.service.BaseService;
import com.gpc.operations.service.IMessageStateManager;
import com.gpc.operations.service.OnUpdateResultCallback;
import com.gpc.operations.utils.CookieHelperKt;
import com.gpc.operations.utils.ExcutorUtils;
import com.gpc.operations.utils.LogUtils;
import java.util.HashMap;
import org.json.JSONObject;

/* compiled from: LiveChatService */
public class HHHTHHHHHt extends BaseService implements IMessageStateManager<Integer> {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f14HHHHTHHHHHHt = "LiveChatService";

    /* compiled from: LiveChatService */
    public class HHHHTHHHHHHt implements Runnable {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ String f15HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ String f16HHHTHHHHHTt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ OnUpdateResultCallback f18HHHTHHHHHtH;

        /* renamed from: HHHTHHHHHTt.HHHTHHHHHt$HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
        /* compiled from: LiveChatService */
        public class C0002HHHHTHHHHHHt implements HTTPServiceCallback {
            public C0002HHHHTHHHHHHt() {
            }

            public void onConnectionError(HTTPRequest hTTPRequest, HTTPException hTTPException) {
                OnUpdateResultCallback onUpdateResultCallback = HHHHTHHHHHHt.this.f18HHHTHHHHHtH;
                if (onUpdateResultCallback != null) {
                    onUpdateResultCallback.onResult(-1);
                }
            }

            public void onResponse(HTTPRequest hTTPRequest, HTTPResponse hTTPResponse) {
                LogUtils.d(HHHTHHHHHt.f14HHHHTHHHHHHt, "onResponse");
                LogUtils.d(HHHTHHHHHt.f14HHHHTHHHHHHt, "response:" + hTTPResponse);
                try {
                    JSONObject jSONObject = new JSONObject(hTTPResponse.getBody().getString());
                    if (jSONObject.isNull("data")) {
                        LogUtils.e(HHHTHHHHHt.f14HHHHTHHHHHHt, "response data: data is null.");
                        OnUpdateResultCallback onUpdateResultCallback = HHHHTHHHHHHt.this.f18HHHTHHHHHtH;
                        if (onUpdateResultCallback != null) {
                            onUpdateResultCallback.onResult(-1);
                            return;
                        }
                        return;
                    }
                    JSONObject jSONObject2 = jSONObject.getJSONObject("data");
                    if (jSONObject2.isNull("count")) {
                        LogUtils.e(HHHTHHHHHt.f14HHHHTHHHHHHt, "response data: count is null.");
                        OnUpdateResultCallback onUpdateResultCallback2 = HHHHTHHHHHHt.this.f18HHHTHHHHHtH;
                        if (onUpdateResultCallback2 != null) {
                            onUpdateResultCallback2.onResult(-1);
                            return;
                        }
                        return;
                    }
                    int i = jSONObject2.getInt("count");
                    LogUtils.d(HHHTHHHHHt.f14HHHHTHHHHHHt, "count: " + i);
                    OnUpdateResultCallback onUpdateResultCallback3 = HHHHTHHHHHHt.this.f18HHHTHHHHHtH;
                    if (onUpdateResultCallback3 != null) {
                        onUpdateResultCallback3.onResult(Integer.valueOf(i));
                    }
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHHt.f14HHHHTHHHHHHt, e.getMessage(), e);
                    OnUpdateResultCallback onUpdateResultCallback4 = HHHHTHHHHHHt.this.f18HHHTHHHHHtH;
                    if (onUpdateResultCallback4 != null) {
                        onUpdateResultCallback4.onResult(-1);
                    }
                }
            }
        }

        public HHHHTHHHHHHt(String str, String str2, OnUpdateResultCallback onUpdateResultCallback) {
            this.f15HHHHTHHHHHHt = str;
            this.f16HHHTHHHHHTt = str2;
            this.f18HHHTHHHHHtH = onUpdateResultCallback;
        }

        public void run() {
            HashMap hashMap = new HashMap();
            hashMap.put(HttpHeaders.COOKIE, HHHTHHHHHt.this.getCookie(CookieHelperKt.getLIVE_CHAT_SESSION()));
            hashMap.put("x-gpc-live-chat", "1");
            HashMap hashMap2 = new HashMap();
            hashMap2.put("game_id", this.f15HHHHTHHHHHHt);
            hashMap2.put("sso_token", this.f16HHHTHHHHHTt);
            ModulesManager.serviceFactory().getHTTPService().post(APIGateway_API.GET_LIVE_STATUS, hashMap, hashMap2, new C0002HHHHTHHHHHHt());
        }
    }

    public HHHTHHHHHt(Context context) {
        super(context);
    }

    public void update(String str, String str2, String str3, OnUpdateResultCallback<Integer> onUpdateResultCallback) {
        LogUtils.d(f14HHHHTHHHHHHt, "update:" + str);
        ExcutorUtils.execute(new HHHHTHHHHHHt(str, str3, onUpdateResultCallback));
    }
}
