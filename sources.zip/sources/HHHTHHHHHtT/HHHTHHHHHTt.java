package HHHTHHHHHTt;

import android.content.Context;
import android.content.Intent;
import com.gpc.livechat.bean.LiveChatAppearance;
import com.gpc.livechat.ui.LiveChatWebViewController;
import com.gpc.operations.base.BaseWebActivity;

/* compiled from: LiveChatIntentHelper */
public class HHHTHHHHHTt {
    public static Intent HHHHTHHHHHHt(Context context, LiveChatAppearance liveChatAppearance, int i) {
        Intent intent = new Intent();
        intent.putExtra(LiveChatWebViewController.KEY_LIVECHAT_INTENT_SOURCE, i);
        intent.setClass(context, LiveChatWebViewController.class);
        if (liveChatAppearance != null) {
            if (liveChatAppearance.getBackBtnIcon() != 0) {
                intent.putExtra(BaseWebActivity.KEY_BACK_BTN_ICON, liveChatAppearance.getBackBtnIcon());
            }
            if (liveChatAppearance.getExitBtnIcon() != 0) {
                intent.putExtra(BaseWebActivity.KEY_EXIT_BTN_ICON, liveChatAppearance.getExitBtnIcon());
            }
            if (liveChatAppearance.getHeaderBackgroundColor() != null) {
                intent.putExtra(BaseWebActivity.KEY_HEADER_BACKGROUND_COLOR, liveChatAppearance.getHeaderBackgroundColor());
            }
        }
        return intent;
    }

    public static Intent HHHHTHHHHHHt(Context context, LiveChatAppearance liveChatAppearance) {
        return HHHHTHHHHHHt(context, liveChatAppearance, 0);
    }
}
