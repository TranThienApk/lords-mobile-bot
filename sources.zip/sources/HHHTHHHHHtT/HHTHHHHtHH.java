package HHHTHHHHHtt;

import android.app.ActivityOptions;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import com.gpc.operations.OperationsSDK;
import com.gpc.operations.notification.BaseNotificationFactory;
import com.gpc.operations.notification.NotificationConfig;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.bean.TSHybridAppearance;
import com.gpc.tsh.helper.TSHIntentHelper;

/* compiled from: TSHActivityNotificationImpl */
public class HHTHHHHtHH extends BaseNotificationFactory implements HHTHHHHtHT {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f73HHHHTHHHHHHt = "TSHActivityNotification";

    public void HHHHTHHHHHHt(Application application, NotificationConfig notificationConfig, TSHybridAppearance tSHybridAppearance) {
        Intent intent;
        PendingIntent pendingIntent;
        if (TextUtils.isEmpty(notificationConfig.getTicketId())) {
            LogUtils.e(f73HHHHTHHHHHHt, "getTicketId is null.");
            if (!TextUtils.isEmpty(notificationConfig.getLaunchActivityName())) {
                intent = new Intent();
                intent.setClassName(application, notificationConfig.getLaunchActivityName());
            } else {
                LogUtils.d(f73HHHHTHHHHHHt, "notification show default Activity");
                Class<?> launchActivity = getLaunchActivity(application);
                if (launchActivity == null) {
                    LogUtils.e(f73HHHHTHHHHHHt, "launchActivity is null.");
                    return;
                }
                LogUtils.d(f73HHHHTHHHHHHt, "launchActivity:" + launchActivity.getName());
                intent = new Intent(application, launchActivity);
            }
        } else if (!OperationsSDK.sharedInstance().isSupportTSHSingleTask()) {
            intent = TSHIntentHelper.getTicketPanel(application, notificationConfig.getTicketId(), tSHybridAppearance, 1);
        } else if (HHTHHHHtTH.HHHTHHHHHtH()) {
            intent = TSHIntentHelper.getTicketPanelForSingleTask(application, notificationConfig.getTicketId(), tSHybridAppearance, 1);
        } else {
            intent = TSHIntentHelper.getTicketPanel(application, notificationConfig.getTicketId(), tSHybridAppearance, 1);
        }
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            ActivityOptions makeBasic = ActivityOptions.makeBasic();
            makeBasic.setPendingIntentBackgroundActivityStartMode(1);
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 201326592, makeBasic.toBundle());
        } else if (i >= 23) {
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 201326592);
        } else {
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 134217728);
        }
        NotificationManager notificationManager = (NotificationManager) application.getSystemService("notification");
        if (i >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel(BaseNotificationFactory.NOTIFICATION_CHANNEL_ID, BaseNotificationFactory.NOTIFICATION_CHANNEL_NAME, 4));
        }
        notificationManager.notify(randomIntValue(), notificationBuilder(application, pendingIntent, notificationConfig).build());
    }
}
