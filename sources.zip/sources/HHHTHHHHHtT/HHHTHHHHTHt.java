package HHHTHHHHHtT;

import android.app.Activity;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;
import com.gpc.operations.base.RunningTimeConfiguration;
import com.gpc.operations.database.IDataBase;
import com.gpc.operations.database.dao.bean.DBResource;
import com.gpc.operations.helper.GeneralResponse;
import com.gpc.operations.migrate.error.GPCException;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.service.upload.UploadImageTask;
import com.gpc.operations.service.upload.UploadStateTaskListener;
import com.gpc.operations.service.upload.UploadTask;
import com.gpc.operations.service.upload.bean.UploadFileInfoJ;
import com.gpc.operations.storagev2.bean.StorageUsage;
import com.gpc.operations.utils.Constant;
import com.gpc.operations.utils.ExcutorUtils;
import com.gpc.operations.utils.FileUtils;
import com.gpc.operations.utils.LogUtils;
import com.gpc.photoselector.model.PhotoModel;
import com.gpc.photoselector.util.BitmapManager;
import com.gpc.resourcestorage.OPSResourceTask;
import com.gpc.resourcestorage.bean.OPSResourcePack;
import com.gpc.resourcestorage.bean.OPSUploadScene;
import com.gpc.resourcestorage.bean.OPSUploadType;
import com.gpc.resourcestorage.bean.UploadResultData;
import com.gpc.resourcestorage.listener.ResourceUploadExtListener;
import com.gpc.resourcestorage.listener.ResourceUploadListener;
import com.gpc.resourcestorage.ui.PhotoUploadController;
import com.gpc.resourcestorage.ui.PickerController;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: OPSImageResourceUploader */
public class HHHTHHHHTHt extends HHHTHHHHTTt {
    public static final String HHTHHHHtH = "OPSResourceUploader";

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public ResourceUploadListener f20HHHHTHHHHHHt;

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public OPSUploadScene f21HHHTHHHHHTt;

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public IDataBase<DBResource> f22HHHTHHHHHt;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public Activity f23HHHTHHHHHtH;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public String f24HHHTHHHHHtT;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public String f25HHHTHHHHHtt;

    /* renamed from: HHHTHHHHTHt  reason: collision with root package name */
    public String f26HHHTHHHHTHt;

    /* renamed from: HHHTHHHHTTt  reason: collision with root package name */
    public List<OPSResourceTask> f27HHHTHHHHTTt;

    /* renamed from: HHHTHHHHTt  reason: collision with root package name */
    public Map<String, String> f28HHHTHHHHTt;

    /* renamed from: HHHTHHHHTtH  reason: collision with root package name */
    public boolean f29HHHTHHHHTtH;

    /* renamed from: HHHTHHHHTtT  reason: collision with root package name */
    public long f30HHHTHHHHTtT;

    /* renamed from: HHTHHHHTtt  reason: collision with root package name */
    public String f31HHTHHHHTtt;

    /* renamed from: HHTHHHHtHH  reason: collision with root package name */
    public String f32HHTHHHHtHH;

    /* compiled from: OPSImageResourceUploader */
    public class HHHHTHHHHHHt implements Runnable {
        public HHHHTHHHHHHt() {
        }

        public void run() {
            ArrayList arrayList = new ArrayList();
            try {
                if (new File(HHHTHHHHTHt.this.f31HHTHHHHTtt).exists()) {
                    String str = HHHTHHHHTHt.this.f26HHHTHHHHTHt + (FileUtils.getFileNameWithoutExtension(HHHTHHHHTHt.this.f31HHTHHHHTtt) + "_" + System.currentTimeMillis() + ".jpg");
                    FileUtils.copyFile(HHHTHHHHTHt.this.f31HHTHHHHTtt, str);
                    PhotoModel photoModel = new PhotoModel();
                    photoModel.setInternalFile(true);
                    photoModel.setAbsoluteFileSystemPath(str);
                    arrayList.add(photoModel);
                    HHHTHHHHTHt.this.HHHTHHHHHTt((ArrayList<PhotoModel>) arrayList);
                    return;
                }
                LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "file not exist");
                HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_FILE_NOT_EXIST));
            } catch (Exception e) {
                LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e);
                HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_FILE_NOT_EXIST));
            }
        }
    }

    /* compiled from: OPSImageResourceUploader */
    public static /* synthetic */ class HHHTHHHHHTt {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public static final /* synthetic */ int[] f34HHHHTHHHHHHt;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                com.gpc.resourcestorage.bean.OPSUploadScene[] r0 = com.gpc.resourcestorage.bean.OPSUploadScene.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f34HHHHTHHHHHHt = r0
                com.gpc.resourcestorage.bean.OPSUploadScene r1 = com.gpc.resourcestorage.bean.OPSUploadScene.AvatarUpload     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f34HHHHTHHHHHHt     // Catch:{ NoSuchFieldError -> 0x001d }
                com.gpc.resourcestorage.bean.OPSUploadScene r1 = com.gpc.resourcestorage.bean.OPSUploadScene.ChatImageUpload     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: HHHTHHHHHtT.HHHTHHHHTHt.HHHTHHHHHTt.<clinit>():void");
        }
    }

    /* compiled from: OPSImageResourceUploader */
    public class HHHTHHHHHtH implements UploadStateTaskListener {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public OPSResourcePack f35HHHHTHHHHHHt;

        public HHHTHHHHHtH(OPSResourcePack oPSResourcePack) {
            this.f35HHHHTHHHHHHt = oPSResourcePack;
        }

        public void onFailure(UploadTask uploadTask, GPCException gPCException) {
            LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "onFailure", gPCException);
            HHHTHHHHTHt.this.HHHHTHHHHHHt(uploadTask.path());
            if (HHHTHHHHTHt.this.f20HHHHTHHHHHHt != null) {
                try {
                    HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure(this.f35HHHHTHHHHHHt.getOPSResourceTask(), gPCException);
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e);
                }
            }
        }

        public void onFileException(UploadTask uploadTask, String str) {
            LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "onFileException code:" + str);
            HHHTHHHHTHt.this.HHHHTHHHHHHt(uploadTask.path());
            if (HHHTHHHHTHt.this.f20HHHHTHHHHHHt != null) {
                GPCException exception = GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_FILE_IO);
                exception.underlyingException(GPCException.exception(str));
                try {
                    HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure(this.f35HHHHTHHHHHHt.getOPSResourceTask(), exception);
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e);
                }
            }
        }

        public void onFinished(UploadTask uploadTask, String str) {
            LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "onFinished result: " + str);
            HHHTHHHHTHt.this.HHHHTHHHHHHt(uploadTask.path());
            if (HHHTHHHHTHt.this.f20HHHHTHHHHHHt != null) {
                try {
                    GeneralResponse generator = GeneralResponse.generator(str);
                    if (generator.isSuccess()) {
                        UploadResultData create = UploadResultData.create(new JSONObject(generator.getData()));
                        if (create == null) {
                            LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "upload image error,uploadResult is null");
                            try {
                                HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_REMOTE_DATA));
                            } catch (Exception e) {
                                LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e);
                            }
                        } else {
                            this.f35HHHHTHHHHHHt.setResourceId(create.getResourceId());
                            this.f35HHHHTHHHHHHt.setStatus(create.getStatus());
                            this.f35HHHHTHHHHHHt.setFileKey(create.getKey());
                            HHHTHHHHTHt.this.f22HHHTHHHHHt.update(new DBResource(this.f35HHHHTHHHHHHt));
                            try {
                                HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onSuccess(this.f35HHHHTHHHHHHt.getOPSResourceTask(), this.f35HHHHTHHHHHHt.getOPSResource());
                            } catch (Exception e2) {
                                LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e2);
                            }
                        }
                    } else {
                        LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "upload image error,no success");
                        GPCException exception = GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_BUSINESS);
                        exception.underlyingException(GPCException.exception(String.valueOf(generator.getError().getCode()), generator.getError().getMessage()));
                        if (!(generator.getError().getCode() / 1000 == 201) || !(HHHTHHHHTHt.this.f20HHHHTHHHHHHt instanceof ResourceUploadExtListener)) {
                            try {
                                HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure(this.f35HHHHTHHHHHHt.getOPSResourceTask(), exception);
                            } catch (Exception e3) {
                                LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e3);
                            }
                        } else {
                            JSONObject jSONObject = new JSONObject(generator.getData());
                            ((ResourceUploadExtListener) HHHTHHHHTHt.this.f20HHHHTHHHHHHt).onLimited(this.f35HHHHTHHHHHHt.getOPSResourceTask(), exception, jSONObject.optLong("denies_at"), jSONObject.optString("reason"));
                        }
                    }
                } catch (JSONException e4) {
                    LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "response data: Parse failure.", e4);
                    try {
                        HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onFailure(this.f35HHHHTHHHHHHt.getOPSResourceTask(), GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_REMOTE_DATA));
                    } catch (Exception e5) {
                        LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e5);
                    }
                }
            }
        }

        public void onProgress(UploadTask uploadTask, float f) {
            LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "onProgress: " + f);
            this.f35HHHHTHHHHHHt.setProgress(f);
            if (HHHTHHHHTHt.this.f20HHHHTHHHHHHt != null) {
                try {
                    HHHTHHHHTHt.this.f20HHHHTHHHHHHt.onProgress(this.f35HHHHTHHHHHHt.getOPSResourceTask());
                } catch (Exception e) {
                    LogUtils.e(HHHTHHHHTHt.HHTHHHHtH, "", e);
                }
            }
        }

        public void onStart(UploadTask uploadTask, float f) {
            LogUtils.d(HHHTHHHHTHt.HHTHHHHtH, "onStart");
        }
    }

    public HHHTHHHHTHt(Activity activity, OPSUploadScene oPSUploadScene, String str, IDataBase<DBResource> iDataBase) {
        this.f29HHHTHHHHTtH = true;
        this.f21HHHTHHHHHTt = oPSUploadScene;
        if (oPSUploadScene == OPSUploadScene.AvatarUpload) {
            this.f30HHHTHHHHTtT = 5120;
            this.f32HHTHHHHtHH = StorageUsage.AVATAR;
        } else if (oPSUploadScene == OPSUploadScene.ChatImageUpload) {
            this.f30HHHTHHHHTtT = 10240;
            this.f32HHTHHHHtHH = StorageUsage.CHAT;
        } else {
            this.f30HHHTHHHHTtT = PlaybackStateCompat.ACTION_PLAY_FROM_MEDIA_ID;
            this.f32HHTHHHHtHH = "none";
        }
        this.f23HHHTHHHHHtH = activity;
        this.f22HHHTHHHHHt = iDataBase;
        this.f25HHHTHHHHHtt = str;
        this.f24HHHTHHHHHtT = String.valueOf(hashCode()) + System.currentTimeMillis();
        LogUtils.d(HHTHHHHtH, "OPSImageResourceUploader uploadKey: " + this.f24HHHTHHHHHtT);
        this.f26HHHTHHHHTHt = ModulesManager.pathModule().getResourceStorageMediaPath();
        LogUtils.d(HHTHHHHtH, "OPSImageResourceUploader appDirectory: " + this.f26HHHTHHHHTHt);
    }

    public final void HHHTHHHHHtT() {
        ModulesManager.getResourceStorageModule().addResourceUploader(this.f24HHHTHHHHHtT, this);
        if (TextUtils.isEmpty(this.f25HHHTHHHHHtt)) {
            HHHTHHHHHt();
        } else {
            HHHTHHHHHtH(this.f25HHHTHHHHHtt);
        }
    }

    public void cancelOnFinishFinalSelection() {
        HHHTHHHHHTt(this.f27HHHTHHHHTTt);
        HHHTHHHHHTt();
    }

    public void setMaxSize(long j) {
        LogUtils.d(HHTHHHHtH, "setMaxSize: " + j);
        if (j > 0) {
            this.f30HHHTHHHHTtT = j;
        }
    }

    public void setResourceUploadListener(ResourceUploadListener resourceUploadListener) {
        this.f20HHHHTHHHHHHt = resourceUploadListener;
    }

    public void setShouldUploadOnceSelected(boolean z) {
        LogUtils.d(HHTHHHHtH, "setShouldUploadOnceSelected: " + z);
        this.f29HHHTHHHHTtH = z;
    }

    public void start() {
        if (StorageUsage.BLUEPRINT.equals(this.f32HHTHHHHtHH)) {
            HHHTHHHHHtH();
        } else {
            HHHTHHHHHtT();
        }
    }

    public void uploadOnFinishFinalSelection(List<OPSResourceTask> list) {
        HHHTHHHHHTt(HHHHTHHHHHHt(this.f27HHHTHHHHTTt, list));
        this.f27HHHTHHHHTTt = list;
        if (list == null || list.isEmpty()) {
            LogUtils.i(HHTHHHHtH, "uploadOnFinishFinalSelection tasks is null or empty");
            HHHTHHHHHTt();
            ResourceUploadListener resourceUploadListener = this.f20HHHHTHHHHHHt;
            if (resourceUploadListener != null) {
                resourceUploadListener.onCancel();
                return;
            }
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            HHHTHHHHHTt(HHHHTHHHHHHt(list.get(i)));
        }
    }

    public final void HHHTHHHHHTt(List<OPSResourceTask> list) {
        if (list == null || list.isEmpty()) {
            LogUtils.d(HHTHHHHtH, "deleteResourceFromDB task is null or empty");
            return;
        }
        ArrayList arrayList = new ArrayList();
        for (OPSResourceTask HHHHTHHHHHHt2 : list) {
            arrayList.add(new DBResource(HHHHTHHHHHHt(HHHHTHHHHHHt2)));
        }
        this.f22HHHTHHHHHt.delete(arrayList);
    }

    public final void HHHTHHHHHt() {
        LogUtils.i(HHTHHHHtH, "startUploadController uploadScene:" + this.f21HHHTHHHHHTt + ", isIntentModel:" + RunningTimeConfiguration.getInstance().isIntentModel);
        int i = HHHTHHHHHTt.f34HHHHTHHHHHHt[this.f21HHHTHHHHHTt.ordinal()];
        if (i != 1) {
            if (i != 2) {
                LogUtils.e(HHTHHHHtH, "OPSUploadScene is error");
            } else if (RunningTimeConfiguration.getInstance().isIntentModel) {
                PickerController.HHHTHHHHHTt(this.f23HHHTHHHHHtH, this.f24HHHTHHHHHtT);
            } else {
                PhotoUploadController.HHHTHHHHHTt(this.f23HHHTHHHHHtH, this.f24HHHTHHHHHtT);
            }
        } else if (RunningTimeConfiguration.getInstance().isIntentModel) {
            PickerController.HHHHTHHHHHHt(this.f23HHHTHHHHHtH, this.f24HHHTHHHHHtT);
        } else {
            PhotoUploadController.HHHHTHHHHHHt(this.f23HHHTHHHHHtH, this.f24HHHTHHHHHtT);
        }
    }

    public final void HHHTHHHHHtH() {
        ExcutorUtils.instanceExecutor().execute(new HHHHTHHHHHHt());
    }

    public final void HHHTHHHHHtH(String str) {
        if (TextUtils.isEmpty(str)) {
            LogUtils.e(HHTHHHHtH, "retry uniqueIdentifier is error");
            return;
        }
        PhotoModel HHHTHHHHHTt2 = HHHTHHHHHTt(str);
        if (HHHTHHHHHTt2 == null) {
            this.f20HHHHTHHHHHHt.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_FILE_IO));
            return;
        }
        ArrayList arrayList = new ArrayList();
        OPSResourcePack HHHHTHHHHHHt2 = HHHHTHHHHHHt(HHHTHHHHHTt2);
        arrayList.add(HHHHTHHHHHHt2.getOPSResourceTask());
        this.f27HHHTHHHHTTt = arrayList;
        ResourceUploadListener resourceUploadListener = this.f20HHHHTHHHHHHt;
        if (resourceUploadListener != null) {
            resourceUploadListener.onSelected(arrayList);
        }
        HHHTHHHHHTt(HHHHTHHHHHHt2);
    }

    public final void HHHHTHHHHHHt(String str) {
        List<OPSResourceTask> list = this.f27HHHTHHHHTTt;
        if (list != null && !list.isEmpty()) {
            Iterator<OPSResourceTask> it = this.f27HHHTHHHHTTt.iterator();
            while (true) {
                if (it.hasNext()) {
                    if (it.next().getLocalPath().equals(str)) {
                        it.remove();
                        break;
                    }
                } else {
                    break;
                }
            }
        }
        List<OPSResourceTask> list2 = this.f27HHHTHHHHTTt;
        if (list2 == null || list2.isEmpty()) {
            HHHTHHHHHTt();
        }
    }

    public final void HHHTHHHHHTt() {
        ModulesManager.getResourceStorageModule().removeResourceUploader(this.f24HHHTHHHHHtT);
    }

    public final void HHHTHHHHHTt(ArrayList<PhotoModel> arrayList) {
        if (arrayList == null || arrayList.isEmpty()) {
            ResourceUploadListener resourceUploadListener = this.f20HHHHTHHHHHHt;
            if (resourceUploadListener != null) {
                resourceUploadListener.onCancel();
                return;
            }
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
            OPSResourcePack HHHHTHHHHHHt2 = HHHHTHHHHHHt(arrayList.get(i));
            arrayList2.add(HHHHTHHHHHHt2);
            arrayList3.add(HHHHTHHHHHHt2.getOPSResourceTask());
        }
        this.f27HHHTHHHHTTt = arrayList3;
        ResourceUploadListener resourceUploadListener2 = this.f20HHHHTHHHHHHt;
        if (resourceUploadListener2 != null) {
            resourceUploadListener2.onSelected(arrayList3);
        }
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            HHHTHHHHHTt((OPSResourcePack) arrayList2.get(i2));
        }
    }

    public final List<OPSResourceTask> HHHHTHHHHHHt(List<OPSResourceTask> list, List<OPSResourceTask> list2) {
        if (list == null || list.isEmpty() || list2 == null || list2.isEmpty()) {
            return null;
        }
        HashSet hashSet = new HashSet();
        for (OPSResourceTask id : list2) {
            hashSet.add(id.getId());
        }
        ArrayList arrayList = new ArrayList();
        for (OPSResourceTask next : list) {
            if (!hashSet.contains(next.getId())) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public void HHHHTHHHHHHt(ArrayList<PhotoModel> arrayList) {
        if (arrayList == null || arrayList.isEmpty()) {
            HHHTHHHHHTt();
            ResourceUploadListener resourceUploadListener = this.f20HHHHTHHHHHHt;
            if (resourceUploadListener != null) {
                resourceUploadListener.onCancel();
                return;
            }
            return;
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        for (int i = 0; i < arrayList.size(); i++) {
            OPSResourcePack HHHHTHHHHHHt2 = HHHHTHHHHHHt(arrayList.get(i));
            arrayList2.add(HHHHTHHHHHHt2);
            arrayList3.add(HHHHTHHHHHHt2.getOPSResourceTask());
        }
        this.f27HHHTHHHHTTt = arrayList3;
        ResourceUploadListener resourceUploadListener2 = this.f20HHHHTHHHHHHt;
        if (resourceUploadListener2 != null) {
            resourceUploadListener2.onSelected(arrayList3);
        }
        if (!this.f29HHHTHHHHTtH) {
            LogUtils.i(HHTHHHHtH, "shouldUploadOnceSelected is false, will not upload once selected.");
            return;
        }
        for (int i2 = 0; i2 < arrayList.size(); i2++) {
            HHHTHHHHHTt((OPSResourcePack) arrayList2.get(i2));
        }
    }

    public HHHTHHHHTHt(Activity activity, String str, String str2, IDataBase<DBResource> iDataBase, Map<String, String> map) {
        this(activity, OPSUploadScene.None, str2, iDataBase);
        this.f32HHTHHHHtHH = StorageUsage.BLUEPRINT;
        this.f31HHTHHHHTtt = str;
        LogUtils.d(HHTHHHHtH, "OPSImageResourceUploader filePath: " + str);
        if (map == null) {
            this.f28HHHTHHHHTt = new HashMap();
        } else {
            this.f28HHHTHHHHTt = new HashMap(map);
        }
        this.f28HHHTHHHHTt.put("_uid", TextUtils.isEmpty(str2) ? "" : str2);
        LogUtils.d(HHTHHHHtH, "OPSImageResourceUploader payload: " + this.f28HHHTHHHHTt);
    }

    public final void HHHTHHHHHTt(OPSResourcePack oPSResourcePack) {
        new UploadImageTask(this.f23HHHTHHHHHtH, HHHTHHHHHTt(HHHHTHHHHHHt(oPSResourcePack)), new HHHTHHHHHtH(oPSResourcePack)).excute();
    }

    public final PhotoModel HHHTHHHHHTt(String str) {
        OPSResourcePack oPSResourcePack = new OPSResourcePack();
        oPSResourcePack.setUniqueIdentifier(str);
        OPSResourcePack oPSResource = this.f22HHHTHHHHHt.query(new DBResource(oPSResourcePack)).getOPSResource();
        if (oPSResource == null) {
            return null;
        }
        return HHHHTHHHHHHt(oPSResource);
    }

    public final UploadFileInfoJ HHHTHHHHHTt(PhotoModel photoModel) {
        UploadFileInfoJ uploadFileInfoJ = new UploadFileInfoJ(photoModel);
        uploadFileInfoJ.setModuleName(Constant.Modules.RESOURCE_UPLOAD);
        uploadFileInfoJ.setType(this.f32HHTHHHHtHH);
        uploadFileInfoJ.setMaxUploadSize(this.f30HHHTHHHHTtT);
        uploadFileInfoJ.setPayload(this.f28HHHTHHHHTt);
        return uploadFileInfoJ;
    }

    public void HHHHTHHHHHHt() {
        ResourceUploadListener resourceUploadListener = this.f20HHHHTHHHHHHt;
        if (resourceUploadListener != null) {
            resourceUploadListener.onFailure((OPSResourceTask) null, GPCException.exception(Constant.ResourceStorage.STORAGE_V2_UPLOAD_ERROR_FOR_FILE_IO));
        }
    }

    public ArrayList<PhotoModel> HHHHTHHHHHHt(List<PhotoModel> list) {
        ArrayList<PhotoModel> arrayList = new ArrayList<>();
        for (PhotoModel next : list) {
            String substring = next.getAbsoluteFileSystemPath().substring(next.getAbsoluteFileSystemPath().lastIndexOf("/") + 1);
            if (TextUtils.isEmpty(substring)) {
                substring = next.getName();
            }
            File file = null;
            try {
                file = BitmapManager.copyFileByImageId(next.getFinalUri(), this.f26HHHTHHHHTHt, substring);
            } catch (Exception e) {
                LogUtils.e(HHTHHHHtH, "", e);
            }
            if (file == null) {
                try {
                    file = BitmapManager.copyFileByImageUri(next.getAbsoluteFileSystemPath(), this.f26HHHTHHHHTHt, substring);
                } catch (Exception e2) {
                    LogUtils.e(HHTHHHHtH, "", e2);
                }
            }
            if (file != null) {
                PhotoModel photoModel = new PhotoModel();
                photoModel.setInternalFile(true);
                photoModel.setType("image");
                photoModel.setAbsoluteFileSystemPath(file.getPath());
                arrayList.add(photoModel);
            }
        }
        return arrayList;
    }

    public final OPSResourcePack HHHHTHHHHHHt(PhotoModel photoModel) {
        OPSResourcePack oPSResourcePack = new OPSResourcePack();
        oPSResourcePack.setLocalPath(photoModel.getAbsoluteFileSystemPath());
        oPSResourcePack.setType(OPSUploadType.Image);
        oPSResourcePack.setId(String.valueOf(this.f22HHHTHHHHHt.insert(new DBResource(oPSResourcePack))));
        oPSResourcePack.setUniqueIdentifier(this.f25HHHTHHHHHtt);
        oPSResourcePack.setPayload(this.f28HHHTHHHHTt);
        return oPSResourcePack;
    }

    public final PhotoModel HHHHTHHHHHHt(OPSResourcePack oPSResourcePack) {
        PhotoModel photoModel = new PhotoModel();
        photoModel.setType("image");
        photoModel.setInternalFile(true);
        photoModel.setUri("file://" + oPSResourcePack.getLocalPath());
        photoModel.setAbsoluteFileSystemPath(oPSResourcePack.getLocalPath());
        try {
            File file = new File(oPSResourcePack.getLocalPath());
            photoModel.setName(file.getName());
            photoModel.setSize(file.length());
            photoModel.setId(Long.parseLong(oPSResourcePack.getUniqueIdentifier()));
        } catch (Exception e) {
            LogUtils.e(HHTHHHHtH, "", e);
        }
        return photoModel;
    }

    public final OPSResourcePack HHHHTHHHHHHt(OPSResourceTask oPSResourceTask) {
        OPSResourcePack oPSResourcePack = new OPSResourcePack();
        oPSResourcePack.setLocalPath(oPSResourceTask.getLocalPath());
        oPSResourcePack.setType(oPSResourceTask.getType());
        oPSResourcePack.setUniqueIdentifier(oPSResourceTask.getId());
        return oPSResourcePack;
    }
}
