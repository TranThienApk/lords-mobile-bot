package HHHTHHHHHtt;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import com.gpc.operations.utils.LogUtils;
import com.gpc.tsh.ui.RepaymentWebViewDialogController;
import com.gpc.tsh.ui.TSHybridWebViewSingleTaskController;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/* compiled from: TSHSingleTaskManager */
public class HHTHHHHtTH {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f74HHHHTHHHHHHt = "TSHRepaymentTaskManager";

    /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
    public static List<Activity> f75HHHTHHHHHTt = new ArrayList();

    /* renamed from: HHHTHHHHHt  reason: collision with root package name */
    public static int f76HHHTHHHHHt = -1;

    /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
    public static WeakReference<Activity> f77HHHTHHHHHtH = null;

    /* renamed from: HHHTHHHHHtT  reason: collision with root package name */
    public static WeakReference<RepaymentWebViewDialogController> f78HHHTHHHHHtT = null;

    /* renamed from: HHHTHHHHHtt  reason: collision with root package name */
    public static final Handler f79HHHTHHHHHtt = new Handler();

    /* compiled from: TSHSingleTaskManager */
    public class HHHHTHHHHHHt implements Runnable {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ HHHTHHHHHTt f80HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHtt.HHTHHHHtTH$HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
        /* compiled from: TSHSingleTaskManager */
        public class C0004HHHHTHHHHHHt implements DialogInterface.OnDismissListener {
            public C0004HHHHTHHHHHHt() {
            }

            public void onDismiss(DialogInterface dialogInterface) {
                WeakReference unused = HHTHHHHtTH.f78HHHTHHHHHtT = null;
            }
        }

        public HHHHTHHHHHHt(HHHTHHHHHTt hHHTHHHHHTt) {
            this.f80HHHHTHHHHHHt = hHHTHHHHHTt;
        }

        public void run() {
            HHHTHHHHHTt hHHTHHHHHTt = this.f80HHHHTHHHHHHt;
            if (hHHTHHHHHTt != null) {
                RepaymentWebViewDialogController repaymentWebViewDialogController = null;
                try {
                    repaymentWebViewDialogController = hHHTHHHHHTt.showRepaymentDialog(HHTHHHHtTH.HHHTHHHHHt());
                } catch (Exception e) {
                    LogUtils.e(HHTHHHHtTH.f74HHHHTHHHHHHt, "RepaymentWebViewDialogController sLatestActivity is null!");
                    LogUtils.e(HHTHHHHtTH.f74HHHHTHHHHHHt, e.getMessage());
                }
                if (repaymentWebViewDialogController == null) {
                    LogUtils.e(HHTHHHHtTH.f74HHHHTHHHHHHt, "RepaymentWebViewDialogController dialog is null!");
                    return;
                }
                repaymentWebViewDialogController.setOnDismissListener(new C0004HHHHTHHHHHHt());
                WeakReference unused = HHTHHHHtTH.f78HHHTHHHHHtT = new WeakReference(repaymentWebViewDialogController);
            }
        }
    }

    /* compiled from: TSHSingleTaskManager */
    public interface HHHTHHHHHTt {
        RepaymentWebViewDialogController showRepaymentDialog(Activity activity);
    }

    public static boolean HHHTHHHHHTt(Activity activity) {
        int i = f76HHHTHHHHHt;
        if (i > 0) {
            return HHHHTHHHHHHt(activity, i);
        }
        LogUtils.i(f74HHHHTHHHHHHt, "[existMainTask] sMainTaskId is null.");
        return false;
    }

    public static void HHHTHHHHHt(Activity activity) {
        LogUtils.i(f74HHHHTHHHHHHt, "[moveMainTaskToFront]");
        ActivityManager activityManager = (ActivityManager) activity.getSystemService("activity");
        if (Build.VERSION.SDK_INT >= 21) {
            for (ActivityManager.AppTask next : activityManager.getAppTasks()) {
                if (next.getTaskInfo().id == f76HHHTHHHHHt) {
                    next.moveToFront();
                }
            }
        }
    }

    public static boolean HHHTHHHHHtH(Activity activity) {
        return HHHHTHHHHHHt(activity, activity.getTaskId());
    }

    public static void HHHTHHHHHtT(Activity activity) {
        LogUtils.i(f74HHHHTHHHHHHt, "[moveMainTaskToFront]");
        Activity HHHTHHHHHt2 = HHHTHHHHHt();
        if (HHHTHHHHHt2 == null) {
            LogUtils.i(f74HHHHTHHHHHHt, "[moveMainTaskToFront] latestActivity is null.");
            return;
        }
        LogUtils.i(f74HHHHTHHHHHHt, "[moveMainTaskToFront] latestActivity name is :" + HHHTHHHHHt2.getComponentName());
        Intent intent = new Intent(activity, HHHTHHHHHt().getClass());
        intent.addFlags(67108864);
        intent.addFlags(536870912);
        activity.startActivity(intent);
    }

    public static void HHHTHHHHHtt() {
        if (HHHTHHHHHtH()) {
            f77HHHTHHHHHtH.get().finish();
            HHHTHHHHHTt();
        }
    }

    public static void HHHTHHHHTHt() {
        WeakReference<RepaymentWebViewDialogController> weakReference = f78HHHTHHHHHtT;
        if (weakReference != null && weakReference.get() != null) {
            f78HHHTHHHHHtT.get().show();
        }
    }

    public static boolean HHHTHHHHHtH() {
        WeakReference<Activity> weakReference = f77HHHTHHHHHtH;
        if (weakReference != null && weakReference.get() != null) {
            return HHHHTHHHHHHt(f77HHHTHHHHHtH.get(), f77HHHTHHHHHtH.get().getTaskId());
        }
        LogUtils.i(f74HHHHTHHHHHHt, "[existTSHTask] existTSHTask is null.");
        return false;
    }

    public static void HHHHTHHHHHHt(Activity activity) {
        if (HHHTHHHHHTt(activity)) {
            HHHTHHHHHtT(activity);
        }
        activity.finish();
        HHHTHHHHHTt();
    }

    public static void HHHTHHHHHTt() {
        try {
            f76HHHTHHHHHt = -1;
            f78HHHTHHHHHtT = null;
            f77HHHTHHHHHtH = null;
        } catch (Exception e) {
            LogUtils.e(f74HHHHTHHHHHHt, e.getMessage());
        }
    }

    public static Activity HHHTHHHHHt() {
        for (int size = f75HHHTHHHHHTt.size() - 1; size >= 0; size--) {
            WeakReference<Activity> weakReference = f77HHHTHHHHHtH;
            if (weakReference == null || weakReference.get() == null) {
                return f75HHHTHHHHHTt.get(size);
            }
            if (f75HHHTHHHHHTt.get(size).getTaskId() != f77HHHTHHHHHtH.get().getTaskId()) {
                return f75HHHTHHHHHTt.get(size);
            }
        }
        return null;
    }

    public static void HHHHTHHHHHHt(Activity activity, HHHTHHHHHTt hHHTHHHHHTt) {
        if (HHHTHHHHHTt(activity)) {
            LogUtils.i(f74HHHHTHHHHHHt, "[showRepayAfterMovedTaskToBack] existMainTask");
            HHHTHHHHHtT(activity);
            WeakReference<RepaymentWebViewDialogController> weakReference = f78HHHTHHHHHtT;
            if (!(weakReference == null || weakReference.get() == null)) {
                if (f75HHHTHHHHHTt.contains(f78HHHTHHHHHtT.get().getHostActivity())) {
                    f78HHHTHHHHHtT.get().show();
                    return;
                }
            }
            f79HHHTHHHHHtt.postDelayed(new HHHHTHHHHHHt(hHHTHHHHHTt), 500);
            return;
        }
        activity.finish();
    }

    public static void HHHTHHHHHtT() {
        WeakReference<RepaymentWebViewDialogController> weakReference = f78HHHTHHHHHtT;
        if (weakReference != null && weakReference.get() != null) {
            f78HHHTHHHHHtT.get().hide();
        }
    }

    public static boolean HHHHTHHHHHHt(Activity activity, int i) {
        try {
            LogUtils.i(f74HHHHTHHHHHHt, "[existTask]");
            if (i <= 0) {
                LogUtils.i(f74HHHHTHHHHHHt, "[existTask] task id is null.");
                return false;
            }
            ActivityManager activityManager = (ActivityManager) activity.getSystemService("activity");
            if (Build.VERSION.SDK_INT >= 21) {
                List<ActivityManager.AppTask> appTasks = activityManager.getAppTasks();
                LogUtils.i(f74HHHHTHHHHHHt, "[existTask] task total size :" + appTasks.size());
                for (ActivityManager.AppTask next : appTasks) {
                    LogUtils.i(f74HHHHTHHHHHHt, "[existTask] task id:" + next.getTaskInfo().id);
                    if (Build.VERSION.SDK_INT >= 23) {
                        LogUtils.i(f74HHHHTHHHHHHt, "[existTask] task num activity:" + next.getTaskInfo().numActivities);
                    }
                    if (next.getTaskInfo().id == i) {
                        LogUtils.i(f74HHHHTHHHHHHt, "[existTask] exist task,task id is:" + i);
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            Log.e(f74HHHHTHHHHHHt, e.getMessage());
            return false;
        }
    }

    public static void HHHHTHHHHHHt(Activity activity, Integer num, Integer num2, String str, String str2, HashMap<String, String> hashMap) {
        f76HHHTHHHHHt = activity.getTaskId();
        LogUtils.i(f74HHHHTHHHHHHt, "[startTask] main task id:" + activity.getTaskId());
        TSHybridWebViewSingleTaskController.Companion.showPanel(activity, num, num2, str, str2, hashMap);
    }

    public static void HHHHTHHHHHHt(Activity activity, Intent intent) {
        f76HHHTHHHHHt = activity.getTaskId();
        LogUtils.i(f74HHHHTHHHHHHt, "[startTask] main task id:" + activity.getTaskId());
        activity.startActivity(intent);
    }

    public static void HHHHTHHHHHHt(int i, int i2, Intent intent) {
        WeakReference<RepaymentWebViewDialogController> weakReference = f78HHHTHHHHHtT;
        if (weakReference != null && weakReference.get() != null) {
            f78HHHTHHHHHtT.get().onActivityResult(i, i2, intent);
        }
    }

    public static void HHHHTHHHHHHt(int i, String[] strArr, int[] iArr) {
        WeakReference<RepaymentWebViewDialogController> weakReference = f78HHHTHHHHHtT;
        if (weakReference != null && weakReference.get() != null) {
            f78HHHTHHHHHtT.get().onRequestPermissionsResult(i, strArr, iArr);
        }
    }
}
