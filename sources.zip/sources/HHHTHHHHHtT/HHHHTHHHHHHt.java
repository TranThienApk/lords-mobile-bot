package HHHTHHHHHTt;

import android.app.ActivityOptions;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.text.TextUtils;
import com.gpc.livechat.bean.LiveChatAppearance;
import com.gpc.operations.notification.BaseNotificationFactory;
import com.gpc.operations.notification.NotificationConfig;
import com.gpc.operations.utils.LogUtils;

/* compiled from: LiveChatActivityNotificationImpl */
public class HHHHTHHHHHHt extends BaseNotificationFactory implements HHHTHHHHHtH {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f13HHHHTHHHHHHt = "LiveChatActivityNotification";

    public void HHHHTHHHHHHt(Application application, NotificationConfig notificationConfig, LiveChatAppearance liveChatAppearance) {
        Intent intent;
        PendingIntent pendingIntent;
        if (!TextUtils.isEmpty(notificationConfig.getLaunchActivityName())) {
            intent = new Intent();
            intent.setClassName(application, notificationConfig.getLaunchActivityName());
        } else {
            LogUtils.d(f13HHHHTHHHHHHt, "notification show default Activity");
            intent = HHHTHHHHHTt.HHHHTHHHHHHt(application, liveChatAppearance, 1);
        }
        int i = Build.VERSION.SDK_INT;
        if (i >= 34) {
            ActivityOptions makeBasic = ActivityOptions.makeBasic();
            makeBasic.setPendingIntentBackgroundActivityStartMode(1);
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 201326592, makeBasic.toBundle());
        } else if (i >= 23) {
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 201326592);
        } else {
            pendingIntent = PendingIntent.getActivity(application, BaseNotificationFactory.NOTIFICATION_REQUEST_CODE, intent, 134217728);
        }
        NotificationManager notificationManager = (NotificationManager) application.getSystemService("notification");
        if (i >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel(BaseNotificationFactory.NOTIFICATION_CHANNEL_ID, BaseNotificationFactory.NOTIFICATION_CHANNEL_NAME, 4));
        }
        notificationManager.notify(randomIntValue(), notificationBuilder(application, pendingIntent, notificationConfig).build());
    }
}
