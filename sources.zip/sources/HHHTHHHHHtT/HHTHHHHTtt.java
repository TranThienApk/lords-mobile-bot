package HHHTHHHHHtt;

import android.content.Context;
import com.gpc.operations.migrate.service.helper.APIGateway_API;
import com.gpc.operations.migrate.service.network.http.HTTPException;
import com.gpc.operations.migrate.service.network.http.request.HTTPRequest;
import com.gpc.operations.migrate.service.network.http.response.HTTPResponse;
import com.gpc.operations.migrate.service.request.api.HTTPServiceCallback;
import com.gpc.operations.migrate.utils.modules.ModulesManager;
import com.gpc.operations.service.BaseService;
import com.gpc.operations.service.IMessageStateManager;
import com.gpc.operations.service.OnUpdateResultCallback;
import com.gpc.operations.utils.ExcutorUtils;
import com.gpc.operations.utils.LogUtils;
import java.util.HashMap;
import org.json.JSONObject;

/* compiled from: MessageService */
public class HHTHHHHTtt extends BaseService implements IMessageStateManager<Integer> {

    /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
    public static final String f64HHHHTHHHHHHt = "MessageService";

    /* compiled from: MessageService */
    public class HHHHTHHHHHHt implements Runnable {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ String f65HHHHTHHHHHHt;

        /* renamed from: HHHTHHHHHTt  reason: collision with root package name */
        public final /* synthetic */ String f66HHHTHHHHHTt;

        /* renamed from: HHHTHHHHHtH  reason: collision with root package name */
        public final /* synthetic */ OnUpdateResultCallback f68HHHTHHHHHtH;

        /* renamed from: HHHTHHHHHtt.HHTHHHHTtt$HHHHTHHHHHHt$HHHHTHHHHHHt  reason: collision with other inner class name */
        /* compiled from: MessageService */
        public class C0003HHHHTHHHHHHt implements HHHTHHHHHtH {
            public C0003HHHHTHHHHHHt() {
            }

            public void HHHHTHHHHHHt(int i) {
                LogUtils.i(HHTHHHHTtt.f64HHHHTHHHHHHt, "onUnreadMessageCount:" + i);
                HHHHTHHHHHHt.this.f68HHHTHHHHHtH.onResult(Integer.valueOf(i));
            }
        }

        public HHHHTHHHHHHt(String str, String str2, OnUpdateResultCallback onUpdateResultCallback) {
            this.f65HHHHTHHHHHHt = str;
            this.f66HHHTHHHHHTt = str2;
            this.f68HHHTHHHHHtH = onUpdateResultCallback;
        }

        public final void run() {
            new HHTHHHHTtt(HHTHHHHTtt.this.context).HHHHTHHHHHHt(this.f65HHHHTHHHHHHt, this.f66HHHTHHHHHTt, new C0003HHHHTHHHHHHt());
        }
    }

    /* compiled from: MessageService */
    public class HHHTHHHHHTt implements HTTPServiceCallback {

        /* renamed from: HHHHTHHHHHHt  reason: collision with root package name */
        public final /* synthetic */ HHHTHHHHHtH f70HHHHTHHHHHHt;

        public HHHTHHHHHTt(HHHTHHHHHtH hHHTHHHHHtH) {
            this.f70HHHHTHHHHHHt = hHHTHHHHHtH;
        }

        public void onConnectionError(HTTPRequest hTTPRequest, HTTPException hTTPException) {
            this.f70HHHHTHHHHHHt.HHHHTHHHHHHt(-1);
        }

        public void onResponse(HTTPRequest hTTPRequest, HTTPResponse hTTPResponse) {
            LogUtils.d(HHTHHHHTtt.f64HHHHTHHHHHHt, "onResponse:" + hTTPResponse.getCode());
            if (hTTPResponse.isSuccess()) {
                try {
                    String string = hTTPResponse.getBody().getString();
                    LogUtils.d(HHTHHHHTtt.f64HHHHTHHHHHHt, "response:" + string);
                    this.f70HHHHTHHHHHHt.HHHHTHHHHHHt(HHTHHHHTtt.this.HHHHTHHHHHHt(string));
                } catch (Exception e) {
                    LogUtils.e(HHTHHHHTtt.f64HHHHTHHHHHHt, "", e);
                    this.f70HHHHTHHHHHHt.HHHHTHHHHHHt(-1);
                }
            } else {
                this.f70HHHHTHHHHHHt.HHHHTHHHHHHt(-1);
            }
        }
    }

    /* compiled from: MessageService */
    public interface HHHTHHHHHtH {
        void HHHHTHHHHHHt(int i);
    }

    public HHTHHHHTtt(Context context) {
        super(context);
    }

    public void update(String str, String str2, String str3, OnUpdateResultCallback<Integer> onUpdateResultCallback) {
        LogUtils.i(f64HHHHTHHHHHHt, "getUnreadMessageCount:" + str);
        ExcutorUtils.instanceExecutor().execute(new HHHHTHHHHHHt(str, str3, onUpdateResultCallback));
    }

    public final void HHHHTHHHHHHt(String str, String str2, HHHTHHHHHtH hHHTHHHHHtH) {
        HashMap hashMap = new HashMap();
        hashMap.put("x-gpc-ticket-hybrid", "1");
        HashMap hashMap2 = new HashMap();
        hashMap2.put("gid", str);
        hashMap2.put("sso_token", str2);
        ModulesManager.serviceFactory().getHTTPService().get(APIGateway_API.UNREAD_MESSAGE_COUNT, hashMap2, hashMap, new HHHTHHHHHTt(hHHTHHHHHtH));
    }

    public final int HHHHTHHHHHHt(String str) {
        int i = -1;
        try {
            LogUtils.i(f64HHHHTHHHHHHt, "response:" + str);
            i = new JSONObject(str).getJSONObject("data").getJSONObject("support").getInt("unread");
            LogUtils.i(f64HHHHTHHHHHHt, "count:" + i);
            return i;
        } catch (Exception e) {
            LogUtils.e(f64HHHHTHHHHHHt, "", e);
            return i;
        }
    }
}
