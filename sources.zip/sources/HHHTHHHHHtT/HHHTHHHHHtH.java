package HHHTHHHHHTt;

import android.app.Application;
import com.gpc.livechat.bean.LiveChatAppearance;
import com.gpc.operations.notification.NotificationConfig;

/* compiled from: LiveChatNotification */
public interface HHHTHHHHHtH {
    void HHHHTHHHHHHt(Application application, NotificationConfig notificationConfig, LiveChatAppearance liveChatAppearance);
}
